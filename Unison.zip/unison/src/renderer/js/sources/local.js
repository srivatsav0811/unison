// Offline music player: plays files from the local library through the Unison engine.

export class LocalPlayer extends EventTarget {
  constructor(engine, { mediaUrl }) {
    super();
    this.engine = engine;
    this.mediaUrl = mediaUrl;
    this.audio = new Audio();
    this.audio.preload = 'auto';
    this.node = engine.master.createMediaElementSource(this.audio);
    this.node.connect(engine.input);
    this.original = [];
    this.queue = [];
    this.index = -1;
    this.shuffle = false;
    this.repeat = 'off';
    this.errors = 0;
    const emit = () => this.dispatchEvent(new CustomEvent('change'));
    for (const ev of ['play', 'pause', 'loadedmetadata', 'durationchange', 'seeked', 'emptied']) this.audio.addEventListener(ev, emit);
    this.audio.addEventListener('playing', () => {
      this.errors = 0;
      emit();
    });
    this.audio.addEventListener('ended', () => this.next(true));
    this.audio.addEventListener('error', () => {
      const t = this.track;
      this.dispatchEvent(new CustomEvent('error', { detail: { track: t, code: this.audio.error && this.audio.error.code } }));
      this.errors++;
      if (this.errors < 5 && this.queue.length > 1) setTimeout(() => this.next(true), 900);
    });
  }

  get track() {
    return this.queue[this.index] || null;
  }

  get playing() {
    return !this.audio.paused && !this.audio.ended;
  }

  srcFor(t) {
    return t.src || this.mediaUrl(t.id);
  }

  playList(tracks, startIndex = 0) {
    if (!tracks || !tracks.length) return;
    this.original = tracks.slice();
    const start = tracks[startIndex] || tracks[0];
    this.queue = this.shuffle ? [start, ...shuffled(tracks.filter((t) => t !== start))] : tracks.slice();
    this.index = this.queue.indexOf(start);
    this.load(true);
  }

  load(autoplay = true) {
    const t = this.track;
    if (!t) return;
    this.audio.src = this.srcFor(t);
    if (autoplay) this.play();
    this.dispatchEvent(new CustomEvent('track', { detail: t }));
    this.dispatchEvent(new CustomEvent('change'));
  }

  async play() {
    if (!this.track) return;
    await this.engine.resume();
    try {
      await this.audio.play();
    } catch (_) {}
  }

  pause() {
    this.audio.pause();
  }

  toggle() {
    if (this.playing) this.pause();
    else this.play();
  }

  next(auto = false) {
    if (!this.queue.length) return;
    if (auto && this.repeat === 'one') {
      this.audio.currentTime = 0;
      this.play();
      return;
    }
    if (this.index + 1 < this.queue.length) this.index++;
    else if (this.repeat === 'all' || !auto) {
      if (this.shuffle) this.queue = shuffled(this.original);
      this.index = 0;
    } else {
      this.pause();
      this.dispatchEvent(new CustomEvent('change'));
      return;
    }
    this.load(true);
  }

  prev() {
    if (!this.queue.length) return;
    if (this.audio.currentTime > 3 || this.index === 0) {
      this.audio.currentTime = 0;
      this.play();
      return;
    }
    this.index--;
    this.load(true);
  }

  seek(sec) {
    if (Number.isFinite(sec) && this.audio.duration) this.audio.currentTime = Math.max(0, Math.min(this.audio.duration - 0.05, sec));
  }

  setShuffle(on) {
    this.shuffle = on;
    const cur = this.track;
    if (!cur) return;
    if (on) this.queue = [cur, ...shuffled(this.original.filter((t) => t !== cur))];
    else this.queue = this.original.slice();
    this.index = this.queue.indexOf(cur);
    this.dispatchEvent(new CustomEvent('change'));
  }

  setRepeat(mode) {
    this.repeat = mode;
    this.dispatchEvent(new CustomEvent('change'));
  }

  playNext(track) {
    if (!this.track) {
      this.playList([track]);
      return;
    }
    this.queue.splice(this.index + 1, 0, track);
    this.original.push(track);
    this.dispatchEvent(new CustomEvent('change'));
  }

  addToQueue(track) {
    if (!this.track) {
      this.playList([track]);
      return;
    }
    this.queue.push(track);
    this.original.push(track);
    this.dispatchEvent(new CustomEvent('change'));
  }

  upNext(n = 5) {
    return this.queue.slice(this.index + 1, this.index + 1 + n);
  }

  state() {
    const t = this.track;
    const a = this.audio;
    return {
      source: 'local',
      active: !!t,
      id: t ? t.id : null,
      title: t ? t.title : '',
      artist: t ? t.artist : '',
      album: t ? t.album : '',
      cover: t ? t.cover : null,
      duration: Number.isFinite(a.duration) ? a.duration : t ? t.duration || 0 : 0,
      position: a.currentTime || 0,
      at: performance.now(),
      playing: this.playing,
      shuffle: this.shuffle,
      repeat: this.repeat,
      canSeek: true,
      canShuffle: true,
      canRepeat: true,
      canNext: this.queue.length > 0,
      canPrev: this.queue.length > 0,
    };
  }
}

function shuffled(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
