// Remote-control sources:
//  - AppleMacController: the Music app on macOS (AppleScript bridge)
//  - WinMediaController: any app that shows up in the Windows media flyout
//    (Apple Music for Windows, Spotify, browsers...), via System Media Transport Controls.

class Poller extends EventTarget {
  constructor(interval = 1000) {
    super();
    this.interval = interval;
    this.timer = null;
    this.error = null;
  }
  start() {
    this.stop();
    const loop = async () => {
      try {
        await this.poll();
      } catch (_) {}
      this.timer = setTimeout(loop, document.hidden ? 4000 : this.interval);
    };
    loop();
  }
  stop() {
    clearTimeout(this.timer);
    this.timer = null;
  }
  changed() {
    this.dispatchEvent(new CustomEvent('change'));
  }
  after(ms = 300) {
    setTimeout(() => this.poll().catch(() => {}), ms);
  }
}

export class AppleMacController extends Poller {
  constructor(bridge) {
    super(1000);
    this.b = bridge;
    this.s = null;
    this.at = 0;
    this.art = null;
    this._artId = null;
  }

  async call(cmd, arg) {
    const r = await this.b.apple.call(cmd, arg);
    if (!r || !r.ok) {
      this.error = r;
      const e = new Error((r && r.error) || 'Music did not respond');
      e.code = r && r.code;
      throw e;
    }
    this.error = null;
    return r.data;
  }

  async poll() {
    const s = await this.call('state');
    this.s = s;
    this.at = performance.now();
    const id = s && s.track && s.track.id;
    if (id && id !== this._artId) {
      this._artId = id;
      this.art = null;
      this.call('art', id)
        .then((u) => {
          if (this._artId === id) {
            this.art = u;
            this.changed();
          }
        })
        .catch(() => {});
    }
    this.changed();
  }

  state() {
    const s = this.s;
    const t = s && s.track;
    return {
      source: 'apple',
      active: !!t,
      running: !!(s && s.running),
      title: t ? t.title : '',
      artist: t ? t.artist : '',
      album: t ? t.album : '',
      art: this.art,
      duration: t ? t.duration || 0 : 0,
      position: s ? s.position || 0 : 0,
      at: this.at,
      playing: !!(s && s.state === 'playing'),
      shuffle: !!(s && s.shuffle),
      repeat: s ? s.repeat || 'off' : 'off',
      canSeek: true,
      canShuffle: true,
      canRepeat: true,
      canNext: true,
      canPrev: true,
    };
  }

  _opt(patch) {
    if (this.s) Object.assign(this.s, patch);
    this.at = performance.now();
    this.changed();
    this.after(400);
  }

  async toggle() {
    const playing = this.s && this.s.state === 'playing';
    this._opt({ state: playing ? 'paused' : 'playing' });
    await this.call('playpause');
  }
  async play() {
    this._opt({ state: 'playing' });
    await this.call('play');
  }
  async pause() {
    this._opt({ state: 'paused' });
    await this.call('pause');
  }
  async next() {
    await this.call('next');
    this.after();
  }
  async prev() {
    const pos = this.s ? this.s.position || 0 : 0;
    await this.call(pos > 3 ? 'restart' : 'prev');
    this.after();
  }
  async seek(sec) {
    this._opt({ position: sec });
    await this.call('seek', sec);
  }
  async setShuffle(on) {
    this._opt({ shuffle: on });
    await this.call('shuffle', on ? 'true' : 'false');
  }
  async setRepeat(mode) {
    this._opt({ repeat: mode });
    await this.call('repeat', mode);
  }
  search(q) {
    return this.call('search', q);
  }
  playlists() {
    return this.call('playlists');
  }
  async playTrack(id) {
    await this.call('playTrack', id);
    this.after(500);
  }
  async playPlaylist(id) {
    await this.call('playPlaylist', id);
    this.after(500);
  }
}

export class WinMediaController extends Poller {
  /** @param prefer substring of the app id, e.g. 'AppleMusic', 'Spotify' or '' for "whatever is playing" */
  constructor(bridge, prefer = '', label = 'System') {
    super(1000);
    this.b = bridge;
    this.prefer = prefer;
    this.label = label;
    this.s = null;
    this.at = 0;
    this.art = null;
    this._key = null;
  }

  async call(cmd, value, prefer = this.prefer) {
    const r = await this.b.winmedia.call({ cmd, prefer, value });
    if (!r || r.ok === false) {
      this.error = r;
      throw new Error((r && r.error) || 'Windows media controls did not respond');
    }
    this.error = null;
    return r;
  }

  async poll() {
    let s = await this.call('state');
    if (!s.active && this.prefer === 'AppleMusic') s = await this.call('state', undefined, 'iTunes');
    this.s = s;
    this.at = performance.now();
    const key = s.active ? `${s.app}|${s.title}|${s.artist}|${s.album}` : null;
    if (key && key !== this._key) {
      this._key = key;
      this.art = null;
      // thumbnails often arrive a moment after the track changes
      setTimeout(() => this._loadArt(key), 700);
    }
    this.changed();
  }

  async _loadArt(key) {
    try {
      const r = await this.call('art');
      if (this._key === key && r.art && r.art.data) {
        this.art = `data:${r.art.mime || 'image/jpeg'};base64,${r.art.data}`;
        this.changed();
      }
    } catch (_) {}
  }

  state() {
    const s = this.s;
    const active = !!(s && s.active);
    const playing = active && s.status === 4;
    let position = active ? s.position || 0 : 0;
    if (playing && s.updated > 0) position += Math.max(0, (Date.now() - s.updated) / 1000);
    if (active && s.duration > 0) position = Math.min(position, s.duration);
    return {
      source: this.prefer === 'AppleMusic' ? 'apple' : this.prefer === 'Spotify' ? 'spotify' : 'system',
      active,
      app: active ? prettyApp(s.app) : '',
      title: active ? s.title : '',
      artist: active ? s.artist : '',
      album: active ? s.album : '',
      art: this.art,
      duration: active ? s.duration || 0 : 0,
      position,
      at: this.at,
      playing,
      shuffle: !!(s && s.shuffle),
      repeat: s ? ['off', 'one', 'all'][s.repeat] || 'off' : 'off',
      canSeek: !!(s && s.canSeek),
      canShuffle: !!(s && s.canShuffle),
      canRepeat: !!(s && s.canRepeat),
      canNext: !s || s.canNext !== false,
      canPrev: !s || s.canPrev !== false,
    };
  }

  _opt(patch) {
    if (this.s) Object.assign(this.s, patch);
    this.at = performance.now();
    this.changed();
    this.after(450);
  }

  async toggle() {
    this._opt({ status: this.s && this.s.status === 4 ? 5 : 4 });
    await this.call('playpause');
  }
  async play() {
    this._opt({ status: 4 });
    await this.call('play');
  }
  async pause() {
    this._opt({ status: 5 });
    await this.call('pause');
  }
  async next() {
    await this.call('next');
    this.after(500);
  }
  async prev() {
    await this.call('prev');
    this.after(500);
  }
  async seek(sec) {
    this._opt({ position: sec, updated: Date.now() });
    await this.call('seek', sec);
  }
  async setShuffle(on) {
    this._opt({ shuffle: on });
    await this.call('shuffle', !!on);
  }
  async setRepeat(mode) {
    const v = { off: 0, one: 1, all: 2 }[mode] ?? 0;
    this._opt({ repeat: v });
    await this.call('repeat', v);
  }
  sessions() {
    return this.call('sessions');
  }
}

export function prettyApp(aumid = '') {
  const a = aumid.toLowerCase();
  if (a.includes('applemusic') || a.includes('itunes')) return 'Apple Music';
  if (a.includes('spotify')) return 'Spotify';
  if (a.includes('chrome')) return 'Chrome';
  if (a.includes('msedge') || a.includes('edge')) return 'Edge';
  if (a.includes('firefox')) return 'Firefox';
  if (a.includes('vlc')) return 'VLC';
  if (a.includes('zunemusic') || a.includes('media')) return 'Media Player';
  const base = aumid.split('!')[0].split('_')[0].split('.').pop();
  return base || 'App';
}
