// Spotify remote control through the Web API (the Spotify app on this computer does the
// streaming; Unison captures its sound and spreads it across the speakers).

export class SpotifyController extends EventTarget {
  constructor(bridge, hostname = '') {
    super();
    this.b = bridge;
    this.hostname = (hostname || '').toLowerCase();
    this.status = { connected: false, configured: false };
    this.data = null;
    this.at = 0;
    this.art = null;
    this._artFor = null;
    this.timer = null;
    this.interval = 1500;
    this.lastError = null;
  }

  async refreshStatus() {
    try {
      this.status = await this.b.spotify.status();
    } catch (_) {}
    this.dispatchEvent(new CustomEvent('status'));
    return this.status;
  }

  async connect(clientId) {
    this.status = await this.b.spotify.connect(clientId);
    this.dispatchEvent(new CustomEvent('status'));
    this.poll();
    return this.status;
  }

  cancel() {
    return this.b.spotify.cancel();
  }

  async disconnect() {
    this.status = await this.b.spotify.disconnect();
    this.data = null;
    this.dispatchEvent(new CustomEvent('status'));
    this.dispatchEvent(new CustomEvent('change'));
  }

  async api(method, path, opts) {
    const r = await this.b.spotify.api(method, path, opts);
    if (!r.ok && r.status === 401 && r.code === 'not_connected') {
      this.status = { ...this.status, connected: false };
      this.dispatchEvent(new CustomEvent('status'));
    }
    if (!r.ok) this.lastError = r;
    return r;
  }

  start(interval = 1500) {
    this.interval = interval;
    this.stop();
    const loop = async () => {
      await this.poll();
      this.timer = setTimeout(loop, document.hidden ? Math.max(4000, this.interval) : this.interval);
    };
    loop();
  }

  stop() {
    clearTimeout(this.timer);
    this.timer = null;
  }

  async poll() {
    if (!this.status.connected) return;
    const r = await this.api('GET', '/me/player', { query: { additional_types: 'episode' } });
    if (r.ok) {
      this.data = r.status === 204 || !r.data ? null : r.data;
      this.at = performance.now();
      const img = this._image();
      if (img && img !== this._artFor) {
        this._artFor = img;
        this.b.art.fetch(img).then((u) => {
          if (this._artFor === img) {
            this.art = u;
            this.dispatchEvent(new CustomEvent('change'));
          }
        });
      }
      if (!img) this.art = null;
      this.dispatchEvent(new CustomEvent('change'));
    } else if (r.code === 'offline') {
      this.dispatchEvent(new CustomEvent('offline'));
    }
  }

  _image() {
    const it = this.data && this.data.item;
    if (!it) return null;
    const imgs = (it.album && it.album.images) || (it.show && it.show.images) || it.images || [];
    return imgs.length ? imgs[0].url : null;
  }

  state() {
    const d = this.data;
    const it = d && d.item;
    const playing = !!(d && d.is_playing);
    return {
      source: 'spotify',
      active: !!it,
      id: it ? it.id : null,
      uri: it ? it.uri : null,
      title: it ? it.name : '',
      artist: it ? (it.artists ? it.artists.map((a) => a.name).join(', ') : it.show ? it.show.name : '') : '',
      album: it ? (it.album ? it.album.name : it.show ? it.show.publisher || '' : '') : '',
      art: this.art,
      duration: it ? (it.duration_ms || 0) / 1000 : 0,
      position: d ? (d.progress_ms || 0) / 1000 : 0,
      at: this.at,
      playing,
      shuffle: !!(d && d.shuffle_state),
      repeat: d ? { off: 'off', context: 'all', track: 'one' }[d.repeat_state] || 'off' : 'off',
      device: d && d.device ? d.device : null,
      canSeek: true,
      canShuffle: true,
      canRepeat: true,
      canNext: true,
      canPrev: true,
    };
  }

  _optimistic(patch) {
    if (!this.data) return;
    Object.assign(this.data, patch);
    this.at = performance.now();
    this.dispatchEvent(new CustomEvent('change'));
    setTimeout(() => this.poll(), 450);
  }

  async _check(r) {
    if (r.ok) return r;
    const reason = r.reason || (r.data && r.data.error && r.data.error.reason);
    let msg = r.error;
    if (reason === 'NO_ACTIVE_DEVICE' || r.status === 404) msg = 'No active Spotify player. Open the Spotify app on this computer (or press play there once), then try again.';
    else if (reason === 'PREMIUM_REQUIRED') msg = 'Spotify only allows playback control for Premium accounts.';
    else if (r.code === 'offline') msg = 'You are offline — Spotify needs the internet. Your local library still works.';
    const err = new Error(msg);
    err.reason = reason;
    err.status = r.status;
    throw err;
  }

  async toggle() {
    const playing = this.data && this.data.is_playing;
    this._optimistic({ is_playing: !playing });
    return this._check(await this.api('PUT', playing ? '/me/player/pause' : '/me/player/play'));
  }

  async play() {
    this._optimistic({ is_playing: true });
    return this._check(await this.api('PUT', '/me/player/play'));
  }

  async pause() {
    this._optimistic({ is_playing: false });
    return this._check(await this.api('PUT', '/me/player/pause'));
  }

  async next() {
    const r = await this._check(await this.api('POST', '/me/player/next'));
    setTimeout(() => this.poll(), 350);
    return r;
  }

  async prev() {
    const r = await this._check(await this.api('POST', '/me/player/previous'));
    setTimeout(() => this.poll(), 350);
    return r;
  }

  async seek(sec) {
    this._optimistic({ progress_ms: Math.round(sec * 1000) });
    return this._check(await this.api('PUT', '/me/player/seek', { query: { position_ms: Math.round(sec * 1000) } }));
  }

  async setShuffle(on) {
    this._optimistic({ shuffle_state: on });
    return this._check(await this.api('PUT', '/me/player/shuffle', { query: { state: on } }));
  }

  async setRepeat(mode) {
    const state = { off: 'off', all: 'context', one: 'track' }[mode] || 'off';
    this._optimistic({ repeat_state: state });
    return this._check(await this.api('PUT', '/me/player/repeat', { query: { state } }));
  }

  async devices() {
    const r = await this.api('GET', '/me/player/devices');
    return r.ok && r.data ? r.data.devices || [] : [];
  }

  /** Prefer: the active device, else this computer's Spotify app, else any computer. */
  async targetDevice() {
    const list = await this.devices();
    const active = list.find((d) => d.is_active);
    if (active) return active;
    const mine = list.find((d) => d.type === 'Computer' && this.hostname && d.name.toLowerCase() === this.hostname);
    return mine || list.find((d) => d.type === 'Computer') || list[0] || null;
  }

  async transfer(deviceId, play = true) {
    return this._check(await this.api('PUT', '/me/player', { body: { device_ids: [deviceId], play } }));
  }

  /** body: { uris } or { context_uri, offset } */
  async playItems(body) {
    const dev = await this.targetDevice();
    const query = dev && !dev.is_active ? { device_id: dev.id } : undefined;
    const r = await this._check(await this.api('PUT', '/me/player/play', { query, body }));
    setTimeout(() => this.poll(), 500);
    return r;
  }

  async search(q) {
    const r = await this.api('GET', '/search', { query: { q, type: 'track,playlist,album,artist', limit: 10 } });
    if (!r.ok) await this._check(r);
    return r.data || {};
  }

  async playlists() {
    const r = await this.api('GET', '/me/playlists', { query: { limit: 50 } });
    return r.ok && r.data ? (r.data.items || []).filter(Boolean) : [];
  }

  async liked() {
    const r = await this.api('GET', '/me/tracks', { query: { limit: 50 } });
    return r.ok && r.data ? (r.data.items || []).map((x) => x.track || x.item).filter(Boolean) : [];
  }

  async recent() {
    const r = await this.api('GET', '/me/player/recently-played', { query: { limit: 20 } });
    return r.ok && r.data ? (r.data.items || []).map((x) => x.track).filter(Boolean) : [];
  }

  async playlistItems(id) {
    const r = await this.api('GET', `/playlists/${encodeURIComponent(id)}/items`, { query: { limit: 100 } });
    if (!r.ok) return null;
    return (r.data.items || []).map((x) => x.item || x.track).filter(Boolean);
  }

  async queue() {
    const r = await this.api('GET', '/me/player/queue');
    return r.ok && r.data ? (r.data.queue || []).slice(0, 5) : [];
  }
}
