// Generates a short original synthwave loop offline, so Unison always has something to play
// (for trying speakers, calibration by ear and the browser demo) without any files or internet.

let cached = null;

export function testTune() {
  if (!cached) cached = render();
  return cached;
}

async function render() {
  const sr = 44100;
  const bpm = 118;
  const beat = 60 / bpm;
  const bars = 16;
  const dur = bars * 4 * beat + 1.5;
  const ctx = new OfflineAudioContext(2, Math.ceil(dur * sr), sr);
  const master = ctx.createDynamicsCompressor();
  master.threshold.value = -14;
  master.ratio.value = 3;
  const out = ctx.createGain();
  out.gain.value = 0.9;
  master.connect(out).connect(ctx.destination);

  // shared reverb-ish delay bus
  const dl = ctx.createDelay(1);
  dl.delayTime.value = beat * 0.75;
  const fb = ctx.createGain();
  fb.gain.value = 0.32;
  const dlf = ctx.createBiquadFilter();
  dlf.type = 'lowpass';
  dlf.frequency.value = 3500;
  dl.connect(dlf).connect(fb).connect(dl);
  const wet = ctx.createGain();
  wet.gain.value = 0.28;
  dlf.connect(wet).connect(master);

  const noiseBuf = ctx.createBuffer(1, sr, sr);
  const nd = noiseBuf.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
  // A minor: Am - F - C - G
  const prog = [
    [57, 60, 64],
    [53, 57, 60],
    [48, 52, 55],
    [55, 59, 62],
  ];

  const kick = (t) => {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.frequency.setValueAtTime(130, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    g.gain.setValueAtTime(1.0, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.32);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + 0.35);
  };
  const clap = (t) => {
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 1700;
    f.Q.value = 0.8;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.55, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    s.connect(f).connect(g);
    g.connect(master);
    g.connect(dl);
    s.start(t);
    s.stop(t + 0.25);
  };
  const hat = (t, v) => {
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = 'highpass';
    f.frequency.value = 8000;
    const g = ctx.createGain();
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    const p = ctx.createStereoPanner();
    p.pan.value = 0.3;
    s.connect(f).connect(g).connect(p).connect(master);
    s.start(t, Math.random() * 0.5);
    s.stop(t + 0.06);
  };
  const bass = (t, m, len) => {
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.value = mtof(m);
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.Q.value = 6;
    f.frequency.setValueAtTime(900, t);
    f.frequency.exponentialRampToValueAtTime(180, t + len);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.32, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.01, t + len);
    o.connect(f).connect(g).connect(master);
    o.start(t);
    o.stop(t + len + 0.02);
  };
  const pad = (t, notes, len) => {
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.07, t + 0.6);
    g.gain.setValueAtTime(0.07, t + len - 0.4);
    g.gain.linearRampToValueAtTime(0.0001, t + len);
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 2200;
    g.connect(f).connect(master);
    f.connect(dl);
    notes.forEach((m, i) => {
      for (const det of [-8, 7]) {
        const o = ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.value = mtof(m + 12);
        o.detune.value = det;
        const p = ctx.createStereoPanner();
        p.pan.value = (i - 1) * 0.5 + det / 40;
        o.connect(p).connect(g);
        o.start(t);
        o.stop(t + len + 0.05);
      }
    });
  };
  const pluck = (t, m) => {
    const o = ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.value = mtof(m);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.16, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    const p = ctx.createStereoPanner();
    p.pan.value = Math.sin(t * 3) * 0.6;
    o.connect(g).connect(p);
    p.connect(master);
    p.connect(dl);
    o.start(t);
    o.stop(t + 0.3);
  };

  for (let bar = 0; bar < bars; bar++) {
    const chord = prog[Math.floor(bar / 2) % 4];
    const t0 = bar * 4 * beat;
    const intro = bar < 2;
    if (bar % 2 === 0) pad(t0, chord, 8 * beat);
    for (let b = 0; b < 4; b++) {
      const t = t0 + b * beat;
      if (!intro) kick(t);
      if (!intro && (b === 1 || b === 3)) clap(t);
      hat(t + beat / 2, 0.18);
      if (bar >= 4) hat(t, 0.08);
      if (!intro) {
        bass(t, chord[0] - 12, beat * 0.45);
        bass(t + beat / 2, chord[0] - (b % 2 ? 0 : 12), beat * 0.4);
      }
    }
    if (bar >= 4) {
      const arp = [chord[0], chord[1], chord[2], chord[1] + 12, chord[2] + 12, chord[1] + 12, chord[2], chord[1]];
      for (let s = 0; s < 16; s++) pluck(t0 + s * (beat / 4), arp[s % arp.length] + 12);
    }
  }

  const buf = await ctx.startRendering();
  const blob = new Blob([encodeWav(buf)], { type: 'audio/wav' });
  return {
    id: 'unison-test-tune',
    title: 'Unison Test Tune',
    artist: 'Unison',
    album: 'Built-in',
    duration: buf.duration,
    src: URL.createObjectURL(blob),
    builtIn: true,
  };
}

function encodeWav(buf) {
  const ch = buf.numberOfChannels;
  const len = buf.length;
  const sr = buf.sampleRate;
  const bytes = 44 + len * ch * 2;
  const ab = new ArrayBuffer(bytes);
  const v = new DataView(ab);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF');
  v.setUint32(4, bytes - 8, true);
  w(8, 'WAVE');
  w(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, ch, true);
  v.setUint32(24, sr, true);
  v.setUint32(28, sr * ch * 2, true);
  v.setUint16(32, ch * 2, true);
  v.setUint16(34, 16, true);
  w(36, 'data');
  v.setUint32(40, len * ch * 2, true);
  const chans = [...Array(ch)].map((_, i) => buf.getChannelData(i));
  let o = 44;
  for (let i = 0; i < len; i++) {
    for (let c = 0; c < ch; c++) {
      const s = Math.max(-1, Math.min(1, chans[c][i]));
      v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      o += 2;
    }
  }
  return ab;
}
