// System-audio capture: brings Spotify / Apple Music / any app into Unison.
//
// Windows: built-in WASAPI loopback of the default output (no install). With
//          "mute while capturing" the laptop speakers go silent while Unison re-plays
//          the sound on your Bluetooth speakers.
// macOS / Windows alt: a virtual audio device (BlackHole on Mac, VB-CABLE on Windows) set as
//          the system output, captured here like a microphone.

const RAW = { echoCancellation: false, noiseSuppression: false, autoGainControl: false };

export async function startCapture({ method, deviceId }) {
  if (method === 'loopback') {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: { ...RAW, suppressLocalAudioPlayback: false },
      systemAudio: 'include',
    });
    for (const t of stream.getVideoTracks()) {
      t.stop();
      stream.removeTrack(t);
    }
    if (!stream.getAudioTracks().length) throw new Error('Windows did not provide a system-audio track.');
    return stream;
  }
  if (!deviceId) throw Object.assign(new Error('No virtual audio device selected.'), { code: 'no-device' });
  return navigator.mediaDevices.getUserMedia({
    audio: { ...RAW, deviceId: { exact: deviceId }, channelCount: 2, sampleRate: 48000 },
  });
}

export function stopStream(stream) {
  if (stream) stream.getTracks().forEach((t) => t.stop());
}

export function describeCaptureError(err, platform) {
  const name = err && (err.name || err.code);
  if (name === 'NotAllowedError') {
    return platform === 'darwin'
      ? 'macOS blocked audio access. Allow Unison under System Settings → Privacy & Security → Microphone.'
      : 'Windows blocked audio access. Turn on "Let desktop apps access your microphone" in Settings → Privacy → Microphone.';
  }
  if (name === 'NotReadableError') return 'The audio device is busy or unavailable. Close apps that use it exclusively and try again.';
  if (name === 'OverconstrainedError' || name === 'NotFoundError' || name === 'no-device') {
    return platform === 'darwin'
      ? 'No virtual audio device found. Install the free BlackHole 2ch driver and pick it in Settings → Audio capture.'
      : 'The selected capture device was not found. Pick another one in Settings → Audio capture.';
  }
  return (err && err.message) || 'Could not capture system audio.';
}
