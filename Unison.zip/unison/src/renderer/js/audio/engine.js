// Unison audio engine.
//
// Program audio (local file, system capture, test sounds) is mixed in one "master"
// AudioContext that has no physical output. Every speaker gets its own AudioContext bound
// to that speaker's device with setSinkId().
//
// PRECISION engine (default): the master writes into a SharedArrayBuffer ring; each speaker
// reads it through an AudioWorklet at a position computed from a wall-clock mapping of both
// audio clocks (getOutputTimestamp + regression). This gives
//   * per-speaker delay compensation with sub-millisecond resolution,
//   * automatic drift correction between Bluetooth clocks (no slow echo build-up),
//   * the smallest safe buffer, adapted live from measured headroom.
// COMPATIBILITY engine (fallback): MediaStream fan-out + DelayNode per speaker.

import { ClockFit } from './dsp.js';

const WORKLET_URL = new URL('./worklets.js', import.meta.url).href;
const RING = 1 << 18; // 5.4 s at 48 kHz

export const LATENCY_MODES = {
  ultra: { label: 'Ultra', safety: 0.006 },
  auto: { label: 'Auto', safety: 0.012 },
  balanced: { label: 'Balanced', safety: 0.03 },
  safe: { label: 'Safe', safety: 0.08 },
};

export const MATRIX = {
  stereo: [1, 0, 0, 1],
  mono: [0.5, 0.5, 0.5, 0.5],
  left: [1, 0, 1, 0],
  right: [0, 1, 0, 1],
  swap: [0, 1, 1, 0],
};

export function precisionSupported() {
  try {
    if (typeof SharedArrayBuffer === 'undefined') return false;
    // eslint-disable-next-line no-new
    new SharedArrayBuffer(8);
    return true;
  } catch (_) {
    return false;
  }
}

const volCurve = (v) => (v <= 0 ? 0 : Math.pow(Math.min(v, 1.5), 2));

export class Engine extends EventTarget {
  constructor({ sampleRate = 48000, mode = 'precision', latencyMode = 'auto' } = {}) {
    super();
    this.sampleRate = sampleRate;
    this.mode = mode === 'precision' && precisionSupported() ? 'precision' : 'compat';
    this.latencyMode = LATENCY_MODES[latencyMode] ? latencyMode : 'auto';
    this.speakers = new Map();
    this.soloId = null;
    this.base = 0.06;
    this.calibrating = false;
    this.lastCal = null; // { lmax, base }
    this._goodSince = performance.now();
    this._lastAdapt = 0;
  }

  async init() {
    const sr = this.sampleRate;
    const m = new AudioContext({ latencyHint: 'interactive', sampleRate: sr });
    this.master = m;
    this.masterSinkless = false;
    if (typeof m.setSinkId === 'function') {
      try {
        await m.setSinkId({ type: 'none' });
        this.masterSinkless = true;
      } catch (_) {}
    }
    await m.audioWorklet.addModule(WORKLET_URL);

    this.input = m.createGain();
    this.programMute = m.createGain();
    this.volume = m.createGain();
    this.fx = m.createGain();
    this.bus = m.createGain();
    this.silent = m.createGain();
    this.silent.gain.value = 0;
    this.silent.connect(m.destination);
    this.analyser = m.createAnalyser();
    this.analyser.fftSize = 2048;
    this.analyser.smoothingTimeConstant = 0.72;
    this.input.connect(this.analyser);
    this.analyser.connect(this.silent);
    this.input.connect(this.programMute).connect(this.volume).connect(this.bus);
    this.fx.connect(this.bus);
    this.fx.connect(this.analyser);

    if (this.mode === 'precision') {
      this.ringSab = new SharedArrayBuffer(RING * 4 * 2);
      this.ctrlSab = new SharedArrayBuffer(16);
      this.writer = new AudioWorkletNode(m, 'unison-writer', {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1],
        channelCount: 2,
        channelCountMode: 'explicit',
        channelInterpretation: 'speakers',
        processorOptions: { sab: this.ringSab, ctrl: this.ctrlSab, size: RING },
      });
      this.bus.connect(this.writer).connect(this.silent);
    } else {
      this.msd = m.createMediaStreamDestination();
      this.msd.channelCount = 2;
      this.bus.connect(this.msd);
      this.bus.connect(this.silent);
    }

    this.recorder = new AudioWorkletNode(m, 'unison-recorder', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1] });
    this.recorder.connect(this.silent);
    this.recorder.port.onmessage = (e) => this._onRecorder(e.data);
    this.micLevel = 0;

    this.masterFit = new ClockFit(sr);
    this.setMasterVolume(0.8);
    this._clockTimer = setInterval(() => this._clockTick(), 250);
    if (this.mode === 'compat') this._meterTimer = setInterval(() => this._pollCompatMeters(), 50);
    if (m.state !== 'running') {
      try {
        await m.resume();
      } catch (_) {}
    }
    return this;
  }

  get safety() {
    return LATENCY_MODES[this.latencyMode].safety;
  }

  resume() {
    const all = [this.master, ...[...this.speakers.values()].map((s) => s.ctx)].filter(Boolean);
    return Promise.all(all.map((c) => (c.state === 'running' ? null : c.resume().catch(() => {}))));
  }

  // ---------------------------------------------------------------- program controls
  setMasterVolume(v) {
    this.masterVolume = v;
    this.volume.gain.setTargetAtTime(volCurve(v), this.master.currentTime, 0.03);
  }

  setProgramMuted(muted) {
    this.programMute.gain.setTargetAtTime(muted ? 0 : 1, this.master.currentTime, 0.02);
  }

  setLatencyMode(mode) {
    if (!LATENCY_MODES[mode]) return;
    this.latencyMode = mode;
    this._goodSince = performance.now();
    // re-evaluate soon; initial guess from reported device latencies
    this.base = Math.max(this.base, this._initialBase());
  }

  /** Play a Float32 buffer through all (un-soloed) speakers, bypassing master volume. */
  playFx(samples, { when = 0, gain = 0.8 } = {}) {
    const m = this.master;
    const buf = m.createBuffer(1, samples.length, this.sampleRate);
    buf.copyToChannel(samples, 0);
    const src = m.createBufferSource();
    src.buffer = buf;
    const g = m.createGain();
    g.gain.value = gain;
    src.connect(g).connect(this.fx);
    const t = when || m.currentTime + 0.05;
    src.start(t);
    src.onended = () => {
      try {
        g.disconnect();
      } catch (_) {}
    };
    return t;
  }

  // ---------------------------------------------------------------- speakers
  async addSpeaker(id, deviceId, settings = {}) {
    if (this.speakers.has(id)) return this.speakers.get(id);
    const Out = this.mode === 'precision' ? PrecisionOutput : CompatOutput;
    const sp = new Out(this, id, deviceId);
    sp.volume = settings.volume ?? 1;
    sp.enabled = settings.enabled ?? true;
    sp.delay = settings.delay ?? 0;
    sp.trim = settings.trim ?? 0;
    sp.channel = settings.channel || 'stereo';
    this.speakers.set(id, sp);
    try {
      await sp.start();
    } catch (err) {
      this.speakers.delete(id);
      sp.close();
      throw err;
    }
    sp.applyMatrix();
    this._applyGains();
    if (this.mode === 'precision') {
      this.base = Math.max(this.base, this._initialBase());
      this._clockTick();
    }
    this.dispatchEvent(new CustomEvent('speakers'));
    return sp;
  }

  async removeSpeaker(id) {
    const sp = this.speakers.get(id);
    if (!sp) return;
    this.speakers.delete(id);
    await sp.fadeAndClose();
    if (this.soloId === id) this.soloId = null;
    this.dispatchEvent(new CustomEvent('speakers'));
  }

  setSpeaker(id, patch) {
    const sp = this.speakers.get(id);
    if (!sp) return;
    if ('volume' in patch) sp.volume = patch.volume;
    if ('enabled' in patch) sp.enabled = patch.enabled;
    if ('delay' in patch) sp.delay = Math.max(0, patch.delay);
    if ('trim' in patch) sp.trim = patch.trim;
    if ('channel' in patch) {
      sp.channel = patch.channel;
      sp.applyMatrix();
    }
    if ('delay' in patch || 'trim' in patch) sp.applyDelay();
    this._applyGains();
  }

  solo(id) {
    this.soloId = id;
    this._applyGains();
  }

  _applyGains() {
    for (const sp of this.speakers.values()) {
      const audible = sp.enabled && (!this.soloId || this.soloId === sp.id);
      sp.applyGain(audible ? volCurve(sp.volume) : 0);
    }
  }

  /** total extra delay applied to a speaker (seconds) */
  effectiveDelay(sp) {
    return Math.max(0, (this.calibrating ? 0 : sp.delay) + (this.calibrating ? 0 : sp.trim));
  }

  _initialBase() {
    let maxOut = 0;
    for (const sp of this.speakers.values()) maxOut = Math.max(maxOut, sp.reportedLatency());
    return Math.min(0.5, maxOut + this.safety + 0.02);
  }

  // ---------------------------------------------------------------- clock mapping
  _sampleTs(ctx) {
    let ts = null;
    try {
      ts = ctx.getOutputTimestamp();
    } catch (_) {}
    if (ts && ts.performanceTime > 0 && ts.contextTime > 0) return { p: ts.performanceTime / 1000, f: ts.contextTime * this.sampleRate };
    if (ctx.state === 'running') return { p: performance.now() / 1000, f: ctx.currentTime * this.sampleRate };
    return null;
  }

  _clockTick() {
    if (this.mode !== 'precision' || !this.master) return;
    const ms = this._sampleTs(this.master);
    if (!ms) return;
    const r = this.masterFit.add(ms.p, ms.f);
    if (Math.abs(r) > 0.03) {
      this.masterFit.reset();
      this.masterFit.add(ms.p, ms.f);
    }
    const am = this.masterFit.a;
    const bm = this.masterFit.b;
    for (const sp of this.speakers.values()) {
      if (!sp.ctx || sp.ctx.state !== 'running') continue;
      const s = this._sampleTs(sp.ctx);
      if (!s) continue;
      const res = sp.fit.add(s.p, s.f);
      if (Math.abs(res) > 0.03) {
        sp.fit.reset();
        sp.fit.add(s.p, s.f);
      }
      const ai = sp.fit.a;
      const bi = sp.fit.b;
      const d = this.base + this.effectiveDelay(sp);
      const alpha = am / ai;
      const beta = bm - (am * bi) / ai - am * d;
      sp.postMap(alpha, beta);
    }
  }

  /** Called with reader stats; adapts the shared buffer to the smallest safe size. */
  _adapt(sp) {
    if (this.mode !== 'precision' || this.calibrating) return;
    const now = performance.now();
    const st = sp.stats;
    if (!st || !st.live || !sp.enabled) return;
    const safety = this.safety;
    if (st.under > 0 || st.minHead < safety * 0.5) {
      if (now - this._lastAdapt > 400) {
        const need = safety - Math.min(st.minHead, 0) + 0.01;
        this.base = Math.min(0.6, this.base + Math.min(0.08, Math.max(0.01, need)));
        this._lastAdapt = now;
        this._goodSince = now;
        this.dispatchEvent(new CustomEvent('latency', { detail: { base: this.base, reason: 'underrun' } }));
      }
      return;
    }
    // shrink slowly after 20 s of comfortable headroom on every speaker
    let minHead = Infinity;
    for (const s of this.speakers.values()) if (s.stats && s.stats.live && s.enabled) minHead = Math.min(minHead, s.stats.minHead);
    if (minHead === Infinity) return;
    if (minHead > safety + 0.02) {
      if (now - this._goodSince > 20000 && now - this._lastAdapt > 5000) {
        const step = Math.min(0.004, minHead - safety - 0.01);
        this.base = Math.max(0.005, this.base - step);
        this._lastAdapt = now;
        this.dispatchEvent(new CustomEvent('latency', { detail: { base: this.base, reason: 'tighten' } }));
      }
    } else {
      this._goodSince = now;
    }
  }

  /** Best estimate of how long after the master the listener actually hears sound. */
  heardLatency() {
    if (this.mode === 'precision') {
      if (this.lastCal) return Math.max(0, this.lastCal.lmax - this.lastCal.base + this.base - 0.015);
      const anyBt = [...this.speakers.values()].some((s) => s.kind === 'bluetooth');
      return this.base + (anyBt ? 0.15 : 0.03);
    }
    if (this.lastCal) return Math.max(0, this.lastCal.lmax - 0.015);
    return 0.15;
  }

  report() {
    return {
      mode: this.mode,
      base: this.mode === 'precision' ? this.base : 0,
      sampleRate: this.sampleRate,
      masterSinkless: this.masterSinkless,
      speakers: [...this.speakers.values()].map((sp) => ({
        id: sp.id,
        outputLatency: sp.reportedLatency(),
        delay: sp.delay,
        trim: sp.trim,
        ppm: sp.fit ? sp.fit.ppm() - this.masterFit.ppm() : 0,
        head: sp.stats ? sp.stats.minHead : null,
        under: sp.stats ? sp.stats.under : 0,
        running: sp.ctx ? sp.ctx.state === 'running' : false,
      })),
    };
  }

  // ---------------------------------------------------------------- calibration plumbing
  /** Resolves once every clock mapping has a few seconds of history (stable enough to measure). */
  async clocksSettled(minSpan = 3, timeoutMs = 6000) {
    if (this.mode !== 'precision') return;
    const t0 = performance.now();
    const ready = () => this.masterFit.span() >= minSpan && [...this.speakers.values()].every((s) => !s.fit || s.fit.span() >= minSpan);
    while (!ready() && performance.now() - t0 < timeoutMs) await new Promise((r) => setTimeout(r, 200));
  }

  beginCalibration() {
    this.calibrating = true;
    this._savedBase = this.base;
    this.masterFit.lockSlope(true);
    for (const sp of this.speakers.values()) sp.fit && sp.fit.lockSlope(true);
    for (const sp of this.speakers.values()) sp.applyDelay();
    this.setProgramMuted(true);
    this._clockTick();
  }

  endCalibration() {
    this.calibrating = false;
    this.masterFit.lockSlope(false);
    for (const sp of this.speakers.values()) sp.fit && sp.fit.lockSlope(false);
    for (const sp of this.speakers.values()) sp.applyDelay();
    this.solo(null);
    this.setProgramMuted(false);
    this._goodSince = performance.now();
    this._clockTick();
  }

  connectMic(stream) {
    if (this.micStream === stream && this.micSource) return;
    this.disconnectMic();
    this.micSource = this.master.createMediaStreamSource(stream);
    this.micSource.connect(this.recorder);
    this.micStream = stream;
  }

  disconnectMic() {
    if (this.micSource) {
      try {
        this.micSource.disconnect();
      } catch (_) {}
    }
    this.micSource = null;
    if (this.micStream) this.micStream.getTracks().forEach((t) => t.stop());
    this.micStream = null;
  }

  /** Record `seconds` of mic input. Resolves { startFrame, data }. */
  record(seconds) {
    return new Promise((resolve) => {
      const chunks = [];
      this._recSink = (msg) => {
        if (msg.type === 'chunk') chunks.push(msg);
        if (msg.type === 'stopped') {
          this._recSink = null;
          if (!chunks.length) {
            resolve({ startFrame: 0, data: new Float32Array(0) });
            return;
          }
          const start = chunks[0].frame;
          const end = chunks[chunks.length - 1].frame + chunks[chunks.length - 1].data.length;
          const data = new Float32Array(end - start);
          for (const c of chunks) data.set(c.data, c.frame - start);
          resolve({ startFrame: start, data });
        }
      };
      this.recorder.port.postMessage('start');
      setTimeout(() => this.recorder.port.postMessage('stop'), seconds * 1000);
    });
  }

  _onRecorder(msg) {
    if (msg.type === 'level') {
      this.micLevel = msg.rms;
      return;
    }
    if (this._recSink) this._recSink(msg);
  }

  _pollCompatMeters() {
    for (const sp of this.speakers.values()) sp.pollLevel && sp.pollLevel();
  }

  async close() {
    clearInterval(this._clockTimer);
    clearInterval(this._meterTimer);
    for (const sp of this.speakers.values()) sp.close();
    this.speakers.clear();
    this.disconnectMic();
    try {
      await this.master.close();
    } catch (_) {}
  }
}

// ======================================================================================
class BaseOutput {
  constructor(engine, id, deviceId) {
    this.engine = engine;
    this.id = id;
    this.deviceId = deviceId;
    this.level = { rms: 0, peak: 0 };
    this.stats = null;
    this.fit = null;
    this.kind = 'other';
  }

  async _makeContext() {
    const e = this.engine;
    const ctx = new AudioContext({ latencyHint: 'interactive', sampleRate: e.sampleRate });
    this.ctx = ctx;
    if (this.deviceId === 'none') await ctx.setSinkId({ type: 'none' });
    else if (this.deviceId && this.deviceId !== 'default') {
      if (typeof ctx.setSinkId !== 'function') throw new Error('This system cannot pick audio outputs (AudioContext.setSinkId missing).');
      await ctx.setSinkId(this.deviceId);
    }
    if (ctx.state !== 'running') {
      try {
        await ctx.resume();
      } catch (_) {}
    }
    return ctx;
  }

  reportedLatency() {
    if (!this.ctx) return 0;
    const ol = Number.isFinite(this.ctx.outputLatency) ? this.ctx.outputLatency : 0;
    return (this.ctx.baseLatency || 0) + ol;
  }

  async fadeAndClose() {
    this.applyGain(0);
    await new Promise((r) => setTimeout(r, 120));
    this.close();
  }

  close() {
    try {
      this.ctx && this.ctx.close();
    } catch (_) {}
    this.ctx = null;
  }
}

class PrecisionOutput extends BaseOutput {
  async start() {
    const e = this.engine;
    const ctx = await this._makeContext();
    await ctx.audioWorklet.addModule(WORKLET_URL);
    this.node = new AudioWorkletNode(ctx, 'unison-reader', {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
      processorOptions: { sab: e.ringSab, ctrl: e.ctrlSab, size: RING },
    });
    this.node.connect(ctx.destination);
    this.node.port.onmessage = (ev) => {
      const d = ev.data;
      if (d.type === 'level') this.level = d;
      else if (d.type === 'stats') {
        this.stats = d;
        e._adapt(this);
      }
    };
    this.fit = new ClockFit(e.sampleRate);
  }

  postMap(alpha, beta) {
    if (this.node) this.node.port.postMessage({ type: 'map', alpha, beta });
  }

  applyGain(g) {
    if (this.node) this.node.port.postMessage({ type: 'gain', value: g });
  }

  applyMatrix() {
    if (this.node) this.node.port.postMessage({ type: 'matrix', m: MATRIX[this.channel] || MATRIX.stereo });
  }

  applyDelay() {
    // the delay is folded into the clock mapping
    this.engine._clockTick();
  }
}

class CompatOutput extends BaseOutput {
  async start() {
    const e = this.engine;
    const ctx = await this._makeContext();
    this.src = ctx.createMediaStreamSource(e.msd.stream);
    this.delayNode = ctx.createDelay(4);
    this.split = ctx.createChannelSplitter(2);
    this.merge = ctx.createChannelMerger(2);
    this.mx = [0, 1, 2, 3].map(() => ctx.createGain());
    this.gainNode = ctx.createGain();
    this.gainNode.gain.value = 0;
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this._buf = new Float32Array(512);
    this.src.connect(this.delayNode).connect(this.split);
    // outL = m0*L + m1*R ; outR = m2*L + m3*R
    this.split.connect(this.mx[0], 0);
    this.split.connect(this.mx[1], 1);
    this.split.connect(this.mx[2], 0);
    this.split.connect(this.mx[3], 1);
    this.mx[0].connect(this.merge, 0, 0);
    this.mx[1].connect(this.merge, 0, 0);
    this.mx[2].connect(this.merge, 0, 1);
    this.mx[3].connect(this.merge, 0, 1);
    this.merge.connect(this.gainNode).connect(this.analyser).connect(ctx.destination);
    this.applyDelay();
  }

  postMap() {}

  applyGain(g) {
    if (this.gainNode) this.gainNode.gain.setTargetAtTime(g, this.ctx.currentTime, 0.015);
  }

  applyMatrix() {
    if (!this.mx) return;
    const m = MATRIX[this.channel] || MATRIX.stereo;
    this.mx.forEach((g, i) => g.gain.setValueAtTime(m[i], this.ctx.currentTime));
  }

  applyDelay() {
    if (!this.delayNode) return;
    const d = Math.min(3.9, this.engine.effectiveDelay(this));
    this.delayNode.delayTime.setTargetAtTime(d, this.ctx.currentTime, 0.02);
  }

  pollLevel() {
    if (!this.analyser) return;
    this.analyser.getFloatTimeDomainData(this._buf);
    let s = 0;
    let pk = 0;
    for (let i = 0; i < this._buf.length; i++) {
      const v = this._buf[i];
      s += v * v;
      if (Math.abs(v) > pk) pk = Math.abs(v);
    }
    this.level = { rms: Math.sqrt(s / this._buf.length), peak: pk };
  }
}
