// Audio device discovery + friendly naming/classification.

const RX = {
  handsFree: /hands[- ]?free|\bag audio\b|headset \(/i,
  virtual: /cable (input|output)|vb-audio|voicemeeter|blackhole|soundflower|loopback audio|virtual|steam streaming|nvidia broadcast|obs|zoomaudio|teams audio/i,
  hdmi: /hdmi|displayport|display audio|nvidia high definition|amd high definition|intel\(r\) display|nvidia output/i,
  builtin:
    /realtek|conexant|internal speakers|built-?in|macbook|imac|mac mini|mac studio|cirrus|synaptics|smart sound|high definition audio device|laptop|idt high|sound blaster audigy/i,
  bluetooth:
    /bluetooth|a2dp|airpods|beats|jbl|bose|sony|srs-|marshall|boat|stone ?\d|soundcore|anker|ultimate ears|\bue\b|wonderboom|megaboom|boom ?\d|harman|skullcandy|tribit|zebronics|mivi|portronics|\bnoise\b|realme|oneplus|redmi|xiaomi|mi portable|galaxy buds|sennheiser|jabra|beoplay|bang|edifier|infinity|philips|xboom|buds|pods|soundbar|sound bar|stereo\)$/i,
  usb: /usb|dac|focusrite|scarlett|audient|behringer|motu|steinberg|fiio|presonus|creative/i,
};

export function classify(label = '') {
  if (RX.virtual.test(label)) return 'virtual';
  if (RX.hdmi.test(label)) return 'hdmi';
  if (RX.handsFree.test(label)) return 'bluetooth';
  if (RX.bluetooth.test(label)) return 'bluetooth';
  if (RX.builtin.test(label)) return 'builtin';
  if (RX.usb.test(label)) return 'usb';
  return 'other';
}

export function prettyName(label = '') {
  const m = /^(?:speakers?|headphones|headset|earphones?|output|line out|digital audio)\s*\((.+)\)\s*$/i.exec(label.trim());
  let name = m ? m[1] : label.trim();
  name = name
    .replace(/\s+(stereo|hands-free.*|ag audio)$/i, '')
    .replace(/\((R|TM)\)|®|™/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  const kind = classify(label);
  if (kind === 'builtin') return { name: 'This computer', detail: name };
  return { name: name || 'Speaker', detail: label };
}

export async function listDevices() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return { outputs: [], inputs: [], defaultOutputLabel: '' };
  const all = await navigator.mediaDevices.enumerateDevices();
  const rawOut = all.filter((d) => d.kind === 'audiooutput');
  const rawIn = all.filter((d) => d.kind === 'audioinput');
  const defOut = rawOut.find((d) => d.deviceId === 'default');
  const defIn = rawIn.find((d) => d.deviceId === 'default');
  const strip = (l) => (l || '').replace(/^(default|communications)\s*-\s*/i, '');
  const defaultOutputLabel = strip(defOut && defOut.label);
  const defaultInputLabel = strip(defIn && defIn.label);
  const map = (d, isDefaultLabel) => {
    const label = d.label || '';
    const pn = prettyName(label);
    return {
      id: d.deviceId,
      label,
      name: pn.name,
      detail: pn.detail,
      kind: classify(label),
      handsFree: RX.handsFree.test(label),
      isDefault: !!label && label === isDefaultLabel,
      groupId: d.groupId,
    };
  };
  const outputs = rawOut.filter((d) => d.deviceId !== 'default' && d.deviceId !== 'communications' && d.deviceId !== '').map((d) => map(d, defaultOutputLabel));
  const inputs = rawIn.filter((d) => d.deviceId !== 'default' && d.deviceId !== 'communications' && d.deviceId !== '').map((d) => map(d, defaultInputLabel));
  // If the browser hides ids (no permission yet) keep the default entries so the UI can explain.
  return {
    outputs,
    inputs,
    defaultOutputLabel,
    defaultInputLabel,
    hasDefaultEntry: !!defOut,
    labelsHidden: all.length > 0 && all.every((d) => !d.label),
  };
}

/** Pick the best microphone for calibration: built-in first, never a Bluetooth headset/virtual device. */
export function pickCalibrationMic(inputs, preferredLabel) {
  if (preferredLabel) {
    const p = inputs.find((d) => d.label === preferredLabel);
    if (p) return p;
  }
  const good = inputs.filter((d) => d.kind !== 'virtual' && d.kind !== 'bluetooth' && !d.handsFree);
  return good.find((d) => d.kind === 'builtin') || good.find((d) => /microphone|mic/i.test(d.label)) || good[0] || inputs[0] || null;
}

/** Find a virtual capture device (VB-CABLE output, BlackHole...) */
export function pickVirtualInput(inputs, preferredLabel) {
  if (preferredLabel) {
    const p = inputs.find((d) => d.label === preferredLabel);
    if (p) return p;
  }
  return inputs.find((d) => /blackhole/i.test(d.label)) || inputs.find((d) => /cable output/i.test(d.label)) || inputs.find((d) => d.kind === 'virtual') || null;
}

export const KIND_LABEL = {
  bluetooth: 'Bluetooth',
  builtin: 'Built-in',
  usb: 'USB / wired',
  hdmi: 'HDMI / display',
  virtual: 'Virtual',
  other: 'Audio output',
};
