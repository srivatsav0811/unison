/* global sampleRate, currentFrame, registerProcessor, AudioWorkletProcessor */
// Audio-thread processors for Unison's precision engine.
//
//  unison-writer   (master context)  writes the program into a shared ring buffer,
//                                    indexed by the master context's frame counter.
//  unison-reader   (one per speaker)  reads the ring at a clock-mapped, delay-compensated
//                                    position with cubic interpolation and smooth drift
//                                    correction; also applies gain, channel matrix, meters.
//  unison-recorder (master context)  timestamps microphone input for calibration.

const XF_LEN = 480; // crossfade length (frames) used when the read head must jump

class UnisonWriter extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const o = options.processorOptions;
    this.size = o.size;
    this.mask = o.size - 1;
    this.L = new Float32Array(o.sab, 0, o.size);
    this.R = new Float32Array(o.sab, o.size * 4, o.size);
    this.ctrl = new BigInt64Array(o.ctrl);
  }

  process(inputs) {
    const inp = inputs[0];
    const l = inp && inp[0];
    const r = inp && (inp[1] || inp[0]);
    const n = l ? l.length : 128;
    const f = currentFrame;
    const mask = this.mask;
    const L = this.L;
    const R = this.R;
    if (l) {
      for (let i = 0; i < n; i++) {
        const idx = (f + i) & mask;
        L[idx] = l[i];
        R[idx] = r[i];
      }
    } else {
      for (let i = 0; i < n; i++) {
        const idx = (f + i) & mask;
        L[idx] = 0;
        R[idx] = 0;
      }
    }
    Atomics.store(this.ctrl, 0, BigInt(f + n));
    return true;
  }
}

class UnisonReader extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const o = options.processorOptions;
    this.size = o.size;
    this.mask = o.size - 1;
    this.L = new Float32Array(o.sab, 0, o.size);
    this.R = new Float32Array(o.sab, o.size * 4, o.size);
    this.ctrl = new BigInt64Array(o.ctrl);
    this.alpha = 1;
    this.beta = 0;
    this.have = false;
    this.pos = 0;
    this.oldPos = 0;
    this.xf = 0;
    this.locked = false;
    this.gain = 0;
    this.targetGain = 1;
    this.gk = 1 - Math.exp(-1 / (0.012 * sampleRate));
    this.m = [1, 0, 0, 1];
    this.jumpFrames = 0.012 * sampleRate;
    this.tc = 1.2 * sampleRate;
    this.maxAdj = 0.0015;
    this.under = 0;
    this.minHead = Infinity;
    this.jumps = 0;
    this.lastErr = 0;
    this.rate = 1;
    this.sumSq = 0;
    this.peak = 0;
    this.levelFrames = 0;
    this.statFrames = 0;
    this.port.onmessage = (e) => {
      const d = e.data;
      if (d.type === 'map') {
        this.alpha = d.alpha;
        this.beta = d.beta;
        this.have = true;
      } else if (d.type === 'gain') {
        this.targetGain = Math.max(0, d.value);
        if (d.instant) this.gain = this.targetGain;
      } else if (d.type === 'matrix') {
        this.m = d.m;
      } else if (d.type === 'relock') {
        this.locked = false;
      }
    };
  }

  // cubic Hermite read; returns false when the position is outside the valid window
  read(p, latest, out) {
    const i = Math.floor(p);
    if (i + 2 >= latest || i - 1 <= latest - this.size) {
      out[0] = 0;
      out[1] = 0;
      return false;
    }
    const t = p - i;
    const mask = this.mask;
    const i0 = (i - 1) & mask;
    const i1 = i & mask;
    const i2 = (i + 1) & mask;
    const i3 = (i + 2) & mask;
    out[0] = hermite(this.L[i0], this.L[i1], this.L[i2], this.L[i3], t);
    out[1] = hermite(this.R[i0], this.R[i1], this.R[i2], this.R[i3], t);
    return true;
  }

  process(_inputs, outputs) {
    const out = outputs[0];
    const oL = out[0];
    const oR = out[1] || out[0];
    const n = oL.length;
    if (!this.have) {
      oL.fill(0);
      oR.fill(0);
      return true;
    }
    const latest = Number(Atomics.load(this.ctrl, 0));
    const target = this.alpha * currentFrame + this.beta;
    if (!this.locked) {
      this.pos = target;
      this.locked = true;
      this.gain = 0; // fade in
    }
    const err = target - this.pos;
    this.lastErr = err;
    let rate = this.alpha;
    if (Math.abs(err) > this.jumpFrames) {
      // big change (delay edit, clock glitch): crossfade to the new position
      this.oldPos = this.pos;
      this.pos = target;
      this.xf = XF_LEN;
      this.jumps++;
    } else {
      const adj = Math.max(-this.maxAdj, Math.min(this.maxAdj, err / this.tc));
      rate = this.alpha * (1 + adj);
    }
    this.rate = rate;
    const a = [0, 0];
    const b = [0, 0];
    const m = this.m;
    let under = 0;
    for (let i = 0; i < n; i++) {
      let okA = this.read(this.pos, latest, a);
      if (this.xf > 0) {
        this.read(this.oldPos, latest, b);
        const g = 1 - this.xf / XF_LEN;
        a[0] = a[0] * g + b[0] * (1 - g);
        a[1] = a[1] * g + b[1] * (1 - g);
        this.oldPos += rate;
        this.xf--;
        okA = true;
      }
      if (!okA && latest > 0) under++;
      this.gain += (this.targetGain - this.gain) * this.gk;
      const l = (m[0] * a[0] + m[1] * a[1]) * this.gain;
      const r = (m[2] * a[0] + m[3] * a[1]) * this.gain;
      oL[i] = l;
      oR[i] = r;
      const s = l * l + r * r;
      this.sumSq += s;
      const pk = Math.max(Math.abs(l), Math.abs(r));
      if (pk > this.peak) this.peak = pk;
      this.pos += rate;
    }
    if (under) this.under += under;
    if (latest > 0) {
      this.live = true;
      const head = latest - this.pos;
      if (head < this.minHead) this.minHead = head;
    }

    this.levelFrames += n;
    if (this.levelFrames >= 2048) {
      this.port.postMessage({ type: 'level', rms: Math.sqrt(this.sumSq / (this.levelFrames * 2)), peak: this.peak });
      this.levelFrames = 0;
      this.sumSq = 0;
      this.peak = 0;
    }
    this.statFrames += n;
    if (this.statFrames >= sampleRate / 2) {
      this.port.postMessage({
        type: 'stats',
        live: !!this.live && this.minHead !== Infinity,
        under: this.under,
        minHead: this.minHead / sampleRate,
        err: this.lastErr / sampleRate,
        rate: this.rate,
        jumps: this.jumps,
      });
      this.statFrames = 0;
      this.under = 0;
      this.minHead = Infinity;
    }
    return true;
  }
}

function hermite(y0, y1, y2, y3, t) {
  const c0 = y1;
  const c1 = 0.5 * (y2 - y0);
  const c2 = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3;
  const c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);
  return ((c3 * t + c2) * t + c1) * t + c0;
}

class UnisonRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.on = false;
    this.buf = new Float32Array(4096);
    this.len = 0;
    this.start = 0;
    this.sumSq = 0;
    this.meterFrames = 0;
    this.port.onmessage = (e) => {
      if (e.data === 'start') {
        this.on = true;
        this.len = 0;
      } else if (e.data === 'stop') {
        this.flush();
        this.on = false;
        this.port.postMessage({ type: 'stopped' });
      }
    };
  }

  flush() {
    if (this.len) {
      this.port.postMessage({ type: 'chunk', frame: this.start, data: this.buf.slice(0, this.len) });
      this.len = 0;
    }
  }

  process(inputs) {
    const inp = inputs[0];
    const n = inp && inp[0] ? inp[0].length : 128;
    // level meter (always on, cheap) so the UI can show the mic is alive
    if (inp && inp[0]) {
      const ch = inp[0];
      for (let i = 0; i < n; i++) this.sumSq += ch[i] * ch[i];
    }
    this.meterFrames += n;
    if (this.meterFrames >= 2048) {
      this.port.postMessage({ type: 'level', rms: Math.sqrt(this.sumSq / this.meterFrames) });
      this.sumSq = 0;
      this.meterFrames = 0;
    }
    if (!this.on) return true;
    if (this.len === 0) this.start = currentFrame;
    const chans = inp ? inp.length : 0;
    for (let i = 0; i < n; i++) {
      let v = 0;
      for (let c = 0; c < chans; c++) v += inp[c][i];
      this.buf[this.len++] = chans ? v / chans : 0;
      if (this.len === this.buf.length) {
        this.port.postMessage({ type: 'chunk', frame: this.start, data: this.buf });
        this.buf = new Float32Array(4096);
        this.len = 0;
        this.start = currentFrame + i + 1;
      }
    }
    return true;
  }
}

registerProcessor('unison-writer', UnisonWriter);
registerProcessor('unison-reader', UnisonReader);
registerProcessor('unison-recorder', UnisonRecorder);
