// Acoustic sync calibration.
//
// For each speaker in turn: solo it, play a short chirp train through the real program path,
// record the microphone in the same (master) clock domain and find each chirp's arrival with a
// matched filter. The loop latency of every speaker is then known to ~0.1 ms; each speaker is
// delayed by (slowest - its own) so every sound reaches the listening spot at the same time.

import { makeChirp, matchedEnvelope, findArrival, median } from './dsp.js';

const REPS = 3;
const GAP = 0.9; // seconds between chirps (must exceed the slowest speaker's latency)
const LEAD = 0.3;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function openMic(deviceId) {
  const constraints = {
    audio: {
      deviceId: deviceId ? { exact: deviceId } : undefined,
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
      channelCount: 1,
    },
  };
  return navigator.mediaDevices.getUserMedia(constraints);
}

/**
 * @param {import('./engine.js').Engine} engine
 * @param {string[]} ids speaker ids to measure
 * @param {object} opts { micStream, level, onProgress(evt), shouldStop() }
 */
export async function calibrate(engine, ids, { micStream, level = 0.7, onProgress = () => {}, shouldStop = () => false } = {}) {
  const sr = engine.sampleRate;
  const chirp = makeChirp(sr);
  engine.connectMic(micStream);
  onProgress({ phase: 'prepare' });
  await engine.clocksSettled();
  engine.beginCalibration();
  const results = {};
  try {
    await sleep(700); // let delay changes settle
    for (let k = 0; k < ids.length; k++) {
      if (shouldStop()) throw new Error('cancelled');
      const id = ids[k];
      onProgress({ phase: 'measure', id, index: k, total: ids.length });
      engine.solo(id);
      await sleep(250);
      results[id] = await measureOne(engine, chirp, level, sr);
      onProgress({ phase: 'result', id, index: k, total: ids.length, result: results[id] });
    }
  } finally {
    engine.solo(null);
  }

  const ok = ids.filter((id) => results[id] && results[id].ok);
  let delays = {};
  let lmax = 0;
  if (ok.length) {
    lmax = Math.max(...ok.map((id) => results[id].latency));
    for (const id of ok) delays[id] = lmax - results[id].latency;
  }
  const before = ok.length > 1 ? lmax - Math.min(...ok.map((id) => results[id].latency)) : 0;
  const summary = {
    at: Date.now(),
    engine: engine.mode,
    base: engine.base,
    lmax,
    spreadBefore: before,
    results,
    delays,
  };
  engine.lastCal = ok.length ? { lmax, base: engine.base } : engine.lastCal;
  return summary;
}

async function measureOne(engine, chirp, level, sr) {
  const m = engine.master;
  const t0 = m.currentTime + LEAD;
  const emits = [];
  const recPromise = engine.record(LEAD + REPS * GAP + 0.25);
  for (let r = 0; r < REPS; r++) {
    const when = t0 + r * GAP;
    engine.playFx(chirp, { when, gain: level });
    emits.push(when * sr);
  }
  const { startFrame, data } = await recPromise;
  if (!data.length) return { ok: false, reason: 'no-mic', latency: 0, snr: 0 };
  const env = matchedEnvelope(data, chirp);
  const lat = [];
  const snrs = [];
  for (const e of emits) {
    const from = e - startFrame;
    const hit = findArrival(env, from, from + GAP * sr * 0.95);
    if (!hit) continue;
    lat.push((hit.index - from) / sr);
    snrs.push(hit.snr);
  }
  if (!lat.length) return { ok: false, reason: 'silent', latency: 0, snr: 0 };
  const latency = median(lat);
  const spread = Math.max(...lat) - Math.min(...lat);
  const snr = Math.min(...snrs);
  let peakLevel = 0;
  for (let i = 0; i < data.length; i++) if (Math.abs(data[i]) > peakLevel) peakLevel = Math.abs(data[i]);
  let reason = null;
  if (snr < 6) reason = peakLevel < 0.01 ? 'silent' : 'noisy';
  else if (spread > 0.006) reason = 'unstable';
  return { ok: !reason, reason, latency, spread, snr, samples: lat, peakLevel };
}

/** Plays one chirp through every speaker at once and reports how tightly the arrivals line up. */
export async function verifySync(engine, { micStream, level = 0.7 } = {}) {
  const sr = engine.sampleRate;
  const chirp = makeChirp(sr);
  engine.connectMic(micStream);
  engine.setProgramMuted(true);
  try {
    await sleep(300);
    const m = engine.master;
    const when = m.currentTime + LEAD;
    const rec = engine.record(LEAD + 1.0);
    engine.playFx(chirp, { when, gain: level });
    const { startFrame, data } = await rec;
    const env = matchedEnvelope(data, chirp);
    const from = when * sr - startFrame;
    const to = Math.min(env.length, from + 0.95 * sr);
    const hit = findArrival(env, from, to, 0.3);
    if (!hit) return null;
    // secondary peaks (other speakers arriving at a different time) within +-150 ms
    const k0 = Math.round(hit.index);
    let secondary = 0;
    let secondaryAt = 0;
    for (let i = Math.max(Math.floor(from), k0 - 0.15 * sr); i < Math.min(to, k0 + 0.15 * sr); i++) {
      if (Math.abs(i - k0) < 0.002 * sr) continue;
      if (env[i] > secondary) {
        secondary = env[i];
        secondaryAt = i;
      }
    }
    return {
      latency: (hit.index - from) / sr,
      secondaryRatio: secondary / hit.max,
      secondaryOffset: (secondaryAt - k0) / sr,
      snr: hit.snr,
    };
  } finally {
    engine.setProgramMuted(false);
  }
}
