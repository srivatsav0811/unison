// Pure DSP helpers (no DOM / Web Audio): chirp design, FFT, matched filtering,
// arrival detection and robust clock fitting. Shared by the app and the Node tests.

export function makeChirp(sampleRate, duration = 0.05, f0 = 1000, f1 = 7000) {
  const n = Math.round(sampleRate * duration);
  const out = new Float32Array(n);
  const k = (f1 - f0) / duration;
  for (let i = 0; i < n; i++) {
    const t = i / sampleRate;
    // Tukey-ish window: fast fade in/out keeps the chirp click-free but broadband
    const edge = Math.min(1, i / (n * 0.1), (n - 1 - i) / (n * 0.1));
    const w = 0.5 - 0.5 * Math.cos(Math.PI * Math.max(0, edge));
    out[i] = w * Math.sin(2 * Math.PI * (f0 * t + 0.5 * k * t * t));
  }
  return out;
}

export function nextPow2(n) {
  let p = 1;
  while (p < n) p <<= 1;
  return p;
}

/** In-place iterative radix-2 FFT. re/im: Float64Array of power-of-two length. */
export function fft(re, im, inverse = false) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      let t = re[i];
      re[i] = re[j];
      re[j] = t;
      t = im[i];
      im[i] = im[j];
      im[j] = t;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = ((inverse ? 2 : -2) * Math.PI) / len;
    const wr = Math.cos(ang);
    const wi = Math.sin(ang);
    const half = len >> 1;
    for (let i = 0; i < n; i += len) {
      let cr = 1;
      let ci = 0;
      for (let j = 0; j < half; j++) {
        const a = i + j;
        const b = a + half;
        const xr = re[b] * cr - im[b] * ci;
        const xi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - xr;
        im[b] = im[a] - xi;
        re[a] += xr;
        im[a] += xi;
        const ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
  if (inverse) {
    for (let i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

/**
 * Matched filter: envelope of the cross-correlation of `signal` with `template`.
 * Uses the analytic signal (negative frequencies removed) so the envelope is smooth
 * instead of ringing at the chirp's carrier frequency.
 * Returns Float32Array env where env[k] ~ match strength of template starting at k.
 */
export function matchedEnvelope(signal, template) {
  const n = nextPow2(signal.length + template.length);
  const ar = new Float64Array(n);
  const ai = new Float64Array(n);
  const br = new Float64Array(n);
  const bi = new Float64Array(n);
  for (let i = 0; i < signal.length; i++) ar[i] = signal[i];
  for (let i = 0; i < template.length; i++) br[i] = template[i];
  fft(ar, ai);
  fft(br, bi);
  // C = A * conj(B), keep only positive frequencies (x2) -> analytic correlation
  const half = n >> 1;
  for (let k = 0; k < n; k++) {
    let cr = ar[k] * br[k] + ai[k] * bi[k];
    let ci = ai[k] * br[k] - ar[k] * bi[k];
    if (k === 0 || k === half) {
      // DC / Nyquist kept once
    } else if (k < half) {
      cr *= 2;
      ci *= 2;
    } else {
      cr = 0;
      ci = 0;
    }
    ar[k] = cr;
    ai[k] = ci;
  }
  fft(ar, ai, true);
  const len = signal.length;
  const env = new Float32Array(len);
  for (let i = 0; i < len; i++) env[i] = Math.hypot(ar[i], ai[i]);
  return env;
}

function median(arr) {
  if (!arr.length) return NaN;
  const a = Float64Array.from(arr).sort();
  const m = a.length >> 1;
  return a.length % 2 ? a[m] : 0.5 * (a[m - 1] + a[m]);
}
export { median };

/**
 * Find the direct-path arrival inside env[from, to).
 * Picks the EARLIEST peak that reaches `ratio` of the strongest peak (room reflections
 * arrive later and are sometimes louder than the direct sound).
 * Returns { index (fractional), peak, snr } or null.
 */
export function findArrival(env, from, to, ratio = 0.55) {
  from = Math.max(0, Math.floor(from));
  to = Math.min(env.length, Math.floor(to));
  if (to - from < 8) return null;
  let max = 0;
  let maxIdx = from;
  for (let i = from; i < to; i++) {
    if (env[i] > max) {
      max = env[i];
      maxIdx = i;
    }
  }
  if (max <= 0) return null;
  // noise floor: median of the window, excluding +-5ms around the max
  const sample = [];
  const step = Math.max(1, Math.floor((to - from) / 4000));
  for (let i = from; i < to; i += step) sample.push(env[i]);
  const floor = median(sample) || 1e-12;
  const thr = Math.max(max * ratio, floor * 4);
  let first = maxIdx;
  for (let i = from; i < maxIdx; i++) {
    if (env[i] >= thr) {
      first = i;
      break;
    }
  }
  // climb to the local maximum of that first lobe
  let k = first;
  while (k + 1 < to && env[k + 1] >= env[k]) k++;
  // parabolic interpolation for sub-sample precision
  let idx = k;
  if (k > from && k + 1 < to) {
    const a = env[k - 1];
    const b = env[k];
    const c = env[k + 1];
    const d = a - 2 * b + c;
    if (d !== 0) idx = k + (0.5 * (a - c)) / d;
  }
  return { index: idx, peak: env[k], max, snr: max / floor };
}

/**
 * Robust linear clock fit y = a*x + b over a sliding window.
 * x: seconds (performance clock), y: frames of an audio clock.
 * Until the window spans `minSpan` seconds the slope is pinned to `nominal`
 * (short windows give noisy slopes), then it is a least-squares fit clamped to +-maxPpm.
 */
export class ClockFit {
  constructor(nominal, { size = 48, minSpan = 2, fullSpan = 10, maxPpm = 400 } = {}) {
    this.nominal = nominal;
    this.size = size;
    this.minSpan = minSpan;
    this.fullSpan = fullSpan;
    this.maxPpm = maxPpm;
    this.xs = [];
    this.ys = [];
    this.a = nominal;
    this.b = 0;
    this.valid = false;
    this.locked = null; // fixed slope while calibrating
  }

  reset() {
    this.xs.length = 0;
    this.ys.length = 0;
    this.valid = false;
  }

  /** Freeze the slope (keeps the mapping steady during measurements); intercept still tracks. */
  lockSlope(on) {
    this.locked = on ? this.a : null;
  }

  span() {
    return this.xs.length > 1 ? this.xs[this.xs.length - 1] - this.xs[0] : 0;
  }

  /** Returns residual (seconds) of the new point against the previous fit. */
  add(x, y) {
    let residual = 0;
    if (this.valid) residual = (y - (this.a * x + this.b)) / this.nominal;
    this.xs.push(x);
    this.ys.push(y);
    if (this.xs.length > this.size) {
      this.xs.shift();
      this.ys.shift();
    }
    this._fit();
    return residual;
  }

  _fit() {
    const n = this.xs.length;
    if (!n) return;
    let mx = 0;
    let my = 0;
    for (let i = 0; i < n; i++) {
      mx += this.xs[i];
      my += this.ys[i];
    }
    mx /= n;
    my /= n;
    let a = this.nominal;
    if (this.locked != null) {
      a = this.locked;
    } else {
      const span = this.span();
      if (n >= 4 && span > this.minSpan) {
        let sxx = 0;
        let sxy = 0;
        for (let i = 0; i < n; i++) {
          const dx = this.xs[i] - mx;
          sxx += dx * dx;
          sxy += dx * (this.ys[i] - my);
        }
        if (sxx > 0) {
          const lim = this.nominal * this.maxPpm * 1e-6;
          const fitted = Math.min(this.nominal + lim, Math.max(this.nominal - lim, sxy / sxx));
          // trust the fitted slope gradually as the window grows (no step changes)
          const w = Math.min(1, (span - this.minSpan) / (this.fullSpan - this.minSpan));
          const target = this.nominal + w * (fitted - this.nominal);
          // and never let the slope jump: at most 5 ppm per update
          const maxStep = this.nominal * 5e-6;
          a = this.valid ? this.a + Math.max(-maxStep, Math.min(maxStep, target - this.a)) : target;
        }
      } else if (this.valid) {
        a = this.a;
      }
    }
    this.a = a;
    this.b = my - a * mx;
    this.valid = true;
  }

  frameAt(x) {
    return this.a * x + this.b;
  }

  timeAt(frame) {
    return (frame - this.b) / this.a;
  }

  ppm() {
    return (this.a / this.nominal - 1) * 1e6;
  }
}

/** Short musical "identify" chime (three rising notes). */
export function makeChime(sampleRate, notes = [659.25, 830.61, 987.77], noteDur = 0.16) {
  const n = Math.round(sampleRate * noteDur * notes.length + sampleRate * 0.35);
  const out = new Float32Array(n);
  notes.forEach((f, idx) => {
    const start = Math.round(idx * noteDur * sampleRate);
    for (let i = 0; start + i < n; i++) {
      const t = i / sampleRate;
      const env = Math.min(1, t / 0.005) * Math.exp(-t * 6);
      out[start + i] += 0.35 * env * (Math.sin(2 * Math.PI * f * t) + 0.3 * Math.sin(4 * Math.PI * f * t));
    }
  });
  return out;
}

/** Click train for the by-ear sync test. */
export function makeClicks(sampleRate, count = 8, interval = 0.5) {
  const n = Math.round(sampleRate * (count * interval + 0.2));
  const out = new Float32Array(n);
  for (let c = 0; c < count; c++) {
    const start = Math.round(c * interval * sampleRate);
    const accent = c % 4 === 0 ? 1 : 0.6;
    for (let i = 0; i < sampleRate * 0.03 && start + i < n; i++) {
      const t = i / sampleRate;
      out[start + i] += accent * 0.6 * Math.exp(-t * 180) * Math.sin(2 * Math.PI * 2200 * t);
    }
  }
  return out;
}
