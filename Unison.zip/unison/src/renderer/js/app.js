// Unison — renderer entry point: boots the engine, owns app state, routes views.
import { bridge, isDesktop, platform, isMac, isWin } from './platform.js';
import { Engine, precisionSupported } from './audio/engine.js';
import { startCapture as openCapture, stopStream, describeCaptureError } from './audio/capture.js';
import { pickVirtualInput } from './audio/devices.js';
import { SpeakerManager } from './speakers.js';
import { LocalPlayer } from './sources/local.js';
import { SpotifyController } from './sources/spotify.js';
import { AppleMacController, WinMediaController } from './sources/remote.js';
import { testTune } from './sources/testtune.js';
import { Background } from './ui/background.js';
import { AudioFeatures } from './ui/features.js';
import { paletteFromImage, defaultPalette, toCss } from './ui/palette.js';
import { icons } from './ui/icons.js';
import { $, $$, html, raw, esc, toast, fmtTime, debounce, installSpecular, installTilt, installRipple, installRangeFill, syncRange, setReduceMotion, generatedCover, lvl } from './ui/dom.js';
import * as nowView from './views/now.js';
import * as speakersView from './views/speakers.js';
import * as libraryView from './views/library.js';
import * as spotifyView from './views/spotify.js';
import * as appleView from './views/apple.js';
import * as settingsView from './views/settings.js';

const VIEWS = {
  now: { mod: nowView, label: 'Now Playing', icon: icons.nowPlaying },
  speakers: { mod: speakersView, label: 'Speakers', icon: icons.speakers },
  library: { mod: libraryView, label: 'Library', icon: icons.library },
  spotify: { mod: spotifyView, label: 'Spotify', icon: icons.spotify },
  apple: { mod: appleView, label: 'Apple Music', icon: icons.apple },
  settings: { mod: settingsView, label: 'Settings', icon: icons.settings },
};

const SOURCES = {
  local: { label: 'My Music', icon: icons.library, hint: 'Songs on this computer — works offline' },
  spotify: { label: 'Spotify', icon: icons.spotify, hint: 'Control Spotify, hear it on every speaker' },
  apple: { label: 'Apple Music', icon: icons.apple, hint: 'Control Apple Music, hear it on every speaker' },
  system: { label: 'Any app', icon: icons.system, hint: 'Everything this computer plays (YouTube, games...)' },
};

// ------------------------------------------------------------------------------------------
const bus = new EventTarget();
const ctx = {
  bridge,
  platform,
  isDesktop,
  isMac,
  isWin,
  icons,
  VIEWS,
  SOURCES,
  settings: {},
  info: {},
  engine: null,
  speakers: null,
  local: null,
  spotify: null,
  controller: null,
  source: 'local',
  view: 'now',
  online: navigator.onLine,
  library: { tracks: [], folders: [], byId: new Map(), scanning: null },
  capture: { stream: null, node: null, error: null, starting: false },
  palette: defaultPalette(),
  artUrl: null,
  on: (ev, fn) => {
    const h = (e) => fn(e.detail);
    bus.addEventListener(ev, h);
    return () => bus.removeEventListener(ev, h);
  },
  emit: (ev, detail) => bus.dispatchEvent(new CustomEvent(ev, { detail })),
  toast,
};
window.__unison = ctx; // handy for debugging from DevTools

ctx._appleCall = async (cmd, arg) => {
  const r = await bridge.apple.call(cmd, arg);
  if (!r || !r.ok) throw Object.assign(new Error((r && r.error) || 'Music did not respond'), { code: r && r.code });
  return r.data;
};

ctx.saveSettings = async (patch) => {
  ctx.settings = await bridge.settings.set(patch);
  ctx.emit('settings');
  return ctx.settings;
};

// ------------------------------------------------------------------------------------------ boot
async function boot() {
  ctx.settings = await bridge.settings.get();
  ctx.info = await bridge.info();
  document.documentElement.dataset.platform = platform;
  document.documentElement.classList.toggle('desktop', isDesktop);
  applyLook();
  renderShell();
  installSpecular();
  installTilt();
  installRipple();
  installRangeFill();

  ctx.bg = new Background($('#bg'));
  ctx.bg.setQuality(ctx.settings.visuals || 'high');

  const engineOpts = { sampleRate: ctx.settings.sampleRate || 48000, mode: ctx.settings.engine || 'precision', latencyMode: ctx.settings.latencyMode || 'auto' };
  try {
    ctx.engine = await new Engine(engineOpts).init();
  } catch (err) {
    console.error(err);
    if (engineOpts.mode === 'precision') {
      // e.g. shared memory unavailable: fall back to the simpler engine instead of failing
      try {
        ctx.engine = await new Engine({ ...engineOpts, mode: 'compat' }).init();
        toast('Started the Compatibility audio engine (Precision engine unavailable on this system).', { kind: 'warn', timeout: 8000 });
      } catch (err2) {
        err = err2;
      }
    }
    if (!ctx.engine) {
      toast(`Audio engine failed to start: ${err.message}`, { kind: 'error', timeout: 0 });
      return;
    }
  }
  ctx.engine.setMasterVolume(ctx.settings.masterVolume ?? 0.8);
  if (ctx.settings.calibration && ctx.settings.calibration.lmax) ctx.engine.lastCal = { lmax: ctx.settings.calibration.lmax, base: ctx.settings.calibration.base };
  ctx.features = new AudioFeatures(ctx.engine.analyser, ctx.engine.sampleRate);
  ctx.engine.addEventListener('latency', () => ctx.emit('engine'));

  ctx.speakers = new SpeakerManager(ctx.engine, bridge, ctx.settings.speakers);
  ctx.speakers.addEventListener('change', () => ctx.emit('speakers'));
  ctx.speakers.addEventListener('tweak', () => ctx.emit('speakers-tweak'));
  ctx.speakers.addEventListener('auto-added', (e) =>
    toast(`Found ${e.detail.join(', ')} — added to your speaker party. Calibrate once for perfect sync.`, {
      kind: 'ok',
      timeout: 9000,
      action: { label: 'Calibrate', run: () => speakersView.openCalibration(ctx) },
    })
  );
  ctx.speakers.addEventListener('new-device', (e) =>
    toast(`${e.detail.name} connected.`, { timeout: 10000, action: { label: 'Add to party', run: () => ctx.speakers.activate(e.detail.key) } })
  );
  if (new URLSearchParams(location.search).has('demo')) installDemoSpeakers(ctx.speakers);
  await ctx.speakers.refresh();
  if (navigator.mediaDevices) navigator.mediaDevices.addEventListener('devicechange', debounce(() => ctx.speakers.refresh(), 700));

  ctx.local = new LocalPlayer(ctx.engine, { mediaUrl: (id) => `app://unison/media/${id}` });
  ctx.local.shuffle = !!(ctx.settings.local && ctx.settings.local.shuffle);
  ctx.local.repeat = (ctx.settings.local && ctx.settings.local.repeat) || 'off';
  ctx.local.addEventListener('change', () => ctx.source === 'local' && ctx.emit('now'));
  ctx.local.addEventListener('track', (e) => {
    if (ctx.source !== 'local') setSource('local');
    const t = e.detail;
    if (t && !t.builtIn) bridge.settings.set({ local: { lastTrack: t.id } });
  });
  ctx.local.addEventListener('error', (e) => {
    const t = e.detail.track;
    toast(`Can't play "${t ? t.title : 'this file'}" — its format isn't supported (e.g. ALAC/WMA). Skipping.`, { kind: 'warn' });
  });

  ctx.spotify = new SpotifyController(bridge, ctx.info.hostname);
  ctx.spotify.addEventListener('change', () => ctx.source === 'spotify' && ctx.controller === ctx.spotify && ctx.emit('now'));
  ctx.spotify.addEventListener('status', () => {
    ctx.emit('spotify');
    if (ctx.source === 'spotify') attachController('spotify');
  });
  ctx.spotify.refreshStatus();

  await loadLibrary();
  bridge.library.onProgress((p) => {
    ctx.library.scanning = p.done ? null : p;
    ctx.emit('library-progress', p);
    if (p.done) loadLibrary();
  });

  window.addEventListener('online', () => setOnline(true));
  window.addEventListener('offline', () => setOnline(false));
  setOnline(navigator.onLine);

  await setSource(ctx.settings.source || 'local', { restoring: true });
  navigate(location.hash.slice(1) || 'now');
  window.addEventListener('hashchange', () => navigate(location.hash.slice(1) || 'now', { fromHash: true }));
  installKeys();
  installDrop();

  ctx.on('now', onNowChanged);
  ctx.on('speakers', () => {
    renderPartyWidget();
    renderStatus();
  });
  ctx.on('engine', renderStatus);
  ctx.on('capture', renderStatus);
  ctx.on('settings', renderStatus);
  onNowChanged();
  renderPartyWidget();
  renderStatus();
  requestAnimationFrame(frame);
  setInterval(() => ctx.features.setDelay(ctx.engine.heardLatency()), 1000);
  setInterval(() => renderStatus(), 3000);

  // unlock audio on the first interaction (browsers)
  const unlock = () => ctx.engine.resume();
  window.addEventListener('pointerdown', unlock, { once: true });
  window.addEventListener('keydown', unlock, { once: true });

  document.documentElement.classList.add('ready');
  // render the built-in test tune in the background so it starts instantly later
  setTimeout(() => testTune(), 2500);
  if (ctx.settings.firstRun && isDesktop) setTimeout(() => settingsView.openGuide(ctx), 700);
}

function applyLook() {
  const s = ctx.settings;
  document.documentElement.classList.toggle('no-glass', s.glass === false);
  const reduce = s.reduceMotion || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.documentElement.classList.toggle('reduce-motion', !!reduce);
  setReduceMotion(!!reduce);
  if (ctx.bg) ctx.bg.setQuality(s.visuals || 'high');
}
ctx.applyLook = applyLook;

function setOnline(v) {
  ctx.online = v;
  document.documentElement.classList.toggle('offline', !v);
  ctx.emit('online', v);
  renderStatus();
}

// ------------------------------------------------------------------------------------------ shell
function renderShell() {
  const app = $('#app');
  app.innerHTML = String(html`
    <header class="titlebar">
      <div class="brand" aria-label="Unison">
        <span class="brand-mark">${raw(icons.wave)}<i></i><i></i><i></i><i></i></span>
        <span class="brand-name">Unison</span>
      </div>
      <div class="seg source-switch" role="tablist" aria-label="Music source">
        ${Object.entries(SOURCES).map(
          ([k, s]) => html`<button role="tab" data-source="${k}" title="${s.hint}"><span class="ico">${raw(s.icon)}</span><span>${s.label}</span></button>`
        )}
        <span class="seg-glider"></span>
      </div>
      <div class="status-pills" id="status-pills"></div>
    </header>
    <nav class="sidebar glass" aria-label="Main">
      <div class="nav">
        ${Object.entries(VIEWS).map(
          ([k, v]) => html`<a class="nav-item" href="#${k}" data-view="${k}"><span class="ico">${raw(v.icon)}</span><span>${v.label}</span><span class="nav-glow"></span></a>`
        )}
      </div>
      <div class="party glass-lite" id="party"></div>
    </nav>
    <main class="views" id="view" tabindex="-1"></main>
    <footer class="playerbar glass" id="playerbar"></footer>
  `);
  $$('.source-switch button').forEach((b) => (b.onclick = () => setSource(b.dataset.source, { user: true })));
  renderPlayerBar();
}

function renderStatus() {
  const el = $('#status-pills');
  if (!el || !ctx.engine) return;
  const e = ctx.engine;
  const n = e.speakers.size;
  const ms = Math.round(e.heardLatency() * 1000);
  const pills = [];
  pills.push(
    `<button class="pill" data-go="speakers" title="Engine: ${e.mode === 'precision' ? 'Precision (drift-corrected ring buffer)' : 'Compatibility'} · buffer ${Math.round(
      (e.mode === 'precision' ? e.base : 0) * 1000
    )} ms"><span class="dot ${n ? 'on' : ''}"></span>${n} speaker${n === 1 ? '' : 's'}${n ? ` · ~${ms} ms` : ''}</button>`
  );
  if (ctx.source !== 'local') {
    const c = ctx.capture;
    const cls = c.stream ? 'on' : c.error ? 'bad' : 'warn';
    const label = c.stream ? 'Capturing audio' : c.error ? 'Capture off' : 'Starting capture…';
    pills.push(`<button class="pill" data-go="settings" title="${esc(c.error || 'System audio is being routed through Unison')}"><span class="dot ${cls}"></span>${label}</button>`);
  }
  if (!ctx.online) pills.push(`<span class="pill offline-pill">${icons.wifiOff}<span>Offline</span></span>`);
  el.innerHTML = pills.join('');
  $$('[data-go]', el).forEach((b) => (b.onclick = () => navigate(b.dataset.go)));
}
ctx.renderStatus = renderStatus;

function renderPartyWidget() {
  const el = $('#party');
  if (!el || !ctx.speakers) return;
  const list = ctx.speakers.list().filter((s) => s.active || s.wanted);
  const cal = ctx.settings.calibration;
  el.innerHTML = String(html`
    <div class="party-head"><span>Speaker party</span><button class="icon-btn sm" data-act="refresh" title="Refresh devices">${raw(icons.refresh)}</button></div>
    <div class="party-orbs">
      ${list.length
        ? list.slice(0, 8).map((s) => html`<span class="orb ${s.active ? '' : 'off'}" data-key="${s.key}" title="${s.name}"><i></i></span>`)
        : html`<span class="party-empty">No speakers yet</span>`}
    </div>
    <div class="party-sync">${raw(icons.sync)}<span>${cal ? `Synced ${new Date(cal.at).toLocaleDateString() === new Date().toLocaleDateString() ? 'today' : new Date(cal.at).toLocaleDateString()}` : 'Not calibrated yet'}</span></div>
    <button class="btn btn-primary btn-block" data-act="calibrate">${raw(icons.target)}<span>Calibrate sync</span></button>
  `);
  el.querySelector('[data-act=refresh]').onclick = () => ctx.speakers.refresh().then(() => toast('Device list refreshed', { kind: 'ok', timeout: 1600 }));
  el.querySelector('[data-act=calibrate]').onclick = () => speakersView.openCalibration(ctx);
}

// ------------------------------------------------------------------------------------------ player bar
function renderPlayerBar() {
  const el = $('#playerbar');
  el.innerHTML = String(html`
    <div class="pb-track">
      <div class="pb-art" data-tilt="18"><img alt="" id="pb-art" /></div>
      <div class="pb-meta"><div class="pb-title" id="pb-title">Nothing playing</div><div class="pb-artist" id="pb-artist">Pick a song or a source</div></div>
    </div>
    <div class="pb-center">
      ${raw(transportHTML('sm'))}
      <div class="progress-row">
        <span class="time" data-t="pos">0:00</span>
        <input type="range" class="range progress" min="0" max="1000" value="0" step="1" aria-label="Seek" />
        <span class="time" data-t="dur">0:00</span>
      </div>
    </div>
    <div class="pb-right">
      <button class="icon-btn" data-act="speakers" title="Speakers">${raw(icons.speakers)}<span class="badge" id="pb-spk">0</span></button>
      <div class="vol">
        <button class="icon-btn" data-act="mute" title="Mute">${raw(icons.volume)}</button>
        <input type="range" class="range volume" min="0" max="100" value="80" aria-label="Master volume" />
      </div>
    </div>`);
  bindTransport(el);
  el.querySelector('[data-act=speakers]').onclick = () => navigate('speakers');
}

export function transportHTML(size = '') {
  return `<div class="transport ${size}">
    <button class="icon-btn t-shuffle" data-t="shuffle" title="Shuffle">${icons.shuffle}</button>
    <button class="icon-btn t-prev" data-t="prev" title="Previous">${icons.prev}</button>
    <button class="play-btn ${size}" data-t="toggle" title="Play / pause"><span class="pb-ring"></span><span class="pb-ico">${icons.play}</span></button>
    <button class="icon-btn t-next" data-t="next" title="Next">${icons.next}</button>
    <button class="icon-btn t-repeat" data-t="repeat" title="Repeat">${icons.repeat}</button>
  </div>`;
}
ctx.transportHTML = transportHTML;

/** Wire transport/progress/volume controls inside `root` (used by player bar + Now view). */
function bindTransport(root) {
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-t]');
    if (!b || b.tagName === 'SPAN') return;
    const act = b.dataset.t;
    if (act === 'toggle') ctx.toggle();
    else if (act === 'next') ctx.next();
    else if (act === 'prev') ctx.prev();
    else if (act === 'shuffle') ctx.setShuffle(!ctx.nowState().shuffle);
    else if (act === 'repeat') {
      const r = ctx.nowState().repeat;
      ctx.setRepeat(r === 'off' ? 'all' : r === 'all' ? 'one' : 'off');
    }
  });
  const prog = root.querySelector('input.progress');
  if (prog) {
    prog.addEventListener('pointerdown', () => (prog.dataset.drag = '1'));
    prog.addEventListener('input', () => {
      const st = ctx.nowState();
      const t = (prog.value / 1000) * (st.duration || 0);
      const lab = root.querySelector('[data-t=pos]');
      if (lab) lab.textContent = fmtTime(t);
    });
    prog.addEventListener('change', () => {
      const st = ctx.nowState();
      ctx.seek((prog.value / 1000) * (st.duration || 0));
      delete prog.dataset.drag;
    });
  }
  const vol = root.querySelector('input.volume');
  if (vol) {
    vol.value = Math.round((ctx.settings.masterVolume ?? 0.8) * 100);
    syncRange(vol);
    vol.addEventListener('input', () => ctx.setVolume(vol.value / 100));
  }
  const mute = root.querySelector('[data-act=mute]');
  if (mute) mute.onclick = () => ctx.toggleMute();
}
ctx.bindTransport = bindTransport;

// ------------------------------------------------------------------------------------------ routing
function navigate(view, { fromHash = false } = {}) {
  if (!VIEWS[view]) view = 'now';
  const prev = ctx.view;
  const host = $('#view');
  if (prev && VIEWS[prev] && VIEWS[prev].mod.unmount) VIEWS[prev].mod.unmount(ctx);
  ctx.view = view;
  if (!fromHash && location.hash.slice(1) !== view) history.replaceState(null, '', `#${view}`);
  $$('.nav-item').forEach((a) => a.classList.toggle('active', a.dataset.view === view));
  document.documentElement.dataset.view = view;
  const swap = () => {
    host.innerHTML = '';
    const section = document.createElement('section');
    section.className = `view view-${view}`;
    host.appendChild(section);
    VIEWS[view].mod.mount(section, ctx);
    host.scrollTop = 0;
  };
  swap();
}
ctx.navigate = navigate;

// ------------------------------------------------------------------------------------------ sources
function remoteFor(src) {
  ctx._remotes = ctx._remotes || {};
  const R = ctx._remotes;
  if (src === 'spotify') {
    if (ctx.spotify.status.connected || !isWin) return ctx.spotify;
    return (R.winSpotify = R.winSpotify || new WinMediaController(bridge, 'Spotify', 'Spotify'));
  }
  if (src === 'apple') {
    if (isMac) return (R.apple = R.apple || new AppleMacController(bridge));
    if (isWin) return (R.winApple = R.winApple || new WinMediaController(bridge, 'AppleMusic', 'Apple Music'));
    return null;
  }
  if (src === 'system') {
    if (isWin) return (R.winSys = R.winSys || new WinMediaController(bridge, '', 'System'));
    return null;
  }
  return null;
}

function attachController(src) {
  if (ctx.controller && ctx.controller !== ctx.local && ctx.controller.stop) ctx.controller.stop();
  if (ctx._ctrlOff) ctx._ctrlOff();
  ctx._ctrlOff = null;
  if (src === 'local') {
    ctx.controller = ctx.local;
  } else {
    const c = remoteFor(src);
    ctx.controller = c;
    if (c) {
      const h = () => ctx.source === src && ctx.emit('now');
      c.addEventListener('change', h);
      ctx._ctrlOff = () => c.removeEventListener('change', h);
      if (c.start) c.start(src === 'spotify' ? 1500 : undefined);
    }
  }
  ctx.emit('now');
}

async function setSource(src, { user = false, restoring = false } = {}) {
  if (!SOURCES[src]) src = 'local';
  const changed = src !== ctx.source || !ctx.controller;
  ctx.source = src;
  $$('.source-switch button').forEach((b) => b.classList.toggle('active', b.dataset.source === src));
  moveGlider();
  document.documentElement.dataset.source = src;
  if (!changed) return;
  if (!restoring || src !== ctx.settings.source) bridge.settings.set({ source: src });
  attachController(src);
  if (src === 'local') {
    await stopSystemCapture();
  } else {
    if (ctx.local && ctx.local.playing) ctx.local.pause();
    await startSystemCapture({ quiet: restoring });
  }
  ctx.emit('source', src);
  renderStatus();
  if (user && src === 'spotify' && !ctx.spotify.status.connected && ctx.view !== 'spotify') {
    toast(isWin ? 'Spotify: play/pause works now. Connect your account for search and playlists.' : 'Connect your Spotify account to control it from Unison.', {
      action: { label: 'Connect', run: () => navigate('spotify') },
    });
  }
}
ctx.setSource = setSource;

function moveGlider() {
  const seg = $('.source-switch');
  if (!seg) return;
  const act = seg.querySelector('button.active');
  const g = seg.querySelector('.seg-glider');
  if (!act || !g) return;
  g.style.width = `${act.offsetWidth}px`;
  g.style.transform = `translateX(${act.offsetLeft}px)`;
}
window.addEventListener('resize', debounce(moveGlider, 100));

async function startSystemCapture({ quiet = false } = {}) {
  const c = ctx.capture;
  if (c.stream || c.starting) return;
  c.starting = true;
  c.error = null;
  ctx.emit('capture');
  const mode = ctx.settings.captureMode;
  const method = mode === 'device' || (!isWin && isDesktop) ? 'device' : 'loopback';
  let deviceId;
  try {
    if (method === 'device') {
      const dev = pickVirtualInput(ctx.speakers.devices.inputs, ctx.settings.captureDeviceLabel);
      if (!dev) throw Object.assign(new Error('no device'), { code: 'no-device' });
      deviceId = dev.id;
    }
    const stream = await openCapture({ method, deviceId });
    c.stream = stream;
    c.node = ctx.engine.master.createMediaStreamSource(stream);
    c.node.connect(ctx.engine.input);
    c.method = method;
    const tr = stream.getAudioTracks()[0];
    if (tr) {
      tr.addEventListener('ended', () => {
        if (c.stream === stream) {
          stopSystemCapture();
          c.error = 'System audio capture stopped.';
          ctx.emit('capture');
        }
      });
    }
  } catch (err) {
    c.error = describeCaptureError(err, platform);
    if (err && (err.name === 'InvalidStateError' || /activation|gesture/i.test(err.message || ''))) {
      // Chromium wants a click before capturing the screen/system audio: retry on the next interaction
      c.error = 'Click anywhere in Unison to start capturing system audio.';
      const retry = () => {
        window.removeEventListener('pointerdown', retry, true);
        window.removeEventListener('keydown', retry, true);
        if (ctx.source !== 'local' && !c.stream) startSystemCapture();
      };
      window.addEventListener('pointerdown', retry, true);
      window.addEventListener('keydown', retry, true);
      quiet = true;
    }
    if (!quiet) {
      toast(c.error, { kind: 'warn', timeout: 9000, action: { label: 'Fix it', run: () => navigate('settings') } });
    }
  } finally {
    c.starting = false;
    ctx.emit('capture');
  }
}

async function stopSystemCapture() {
  const c = ctx.capture;
  if (c.node) {
    try {
      c.node.disconnect();
    } catch (_) {}
  }
  stopStream(c.stream);
  c.stream = null;
  c.node = null;
  c.error = null;
  ctx.emit('capture');
}
ctx.restartCapture = async () => {
  await stopSystemCapture();
  if (ctx.source !== 'local') await startSystemCapture();
};

// ------------------------------------------------------------------------------------------ transport
const EMPTY = { active: false, title: '', artist: '', album: '', duration: 0, position: 0, at: 0, playing: false, shuffle: false, repeat: 'off' };
ctx.nowState = () => {
  const c = ctx.controller;
  if (!c || !c.state) return { ...EMPTY, source: ctx.source, noControl: ctx.source !== 'local' };
  return c.state();
};

ctx.position = () => {
  const s = ctx.nowState();
  if (!s.active) return 0;
  if (ctx.source === 'local') return ctx.local.audio.currentTime || 0;
  let p = s.position + (s.playing ? (performance.now() - s.at) / 1000 : 0);
  if (s.duration) p = Math.min(p, s.duration);
  return p;
};

const guard = (fn) => async (...a) => {
  const c = ctx.controller;
  if (!c) {
    toast(isMac && ctx.source === 'system' ? 'On Mac, control other apps directly — Unison still spreads their sound to all speakers.' : 'Nothing to control for this source yet.', { kind: 'info' });
    return;
  }
  try {
    await fn(c, ...a);
  } catch (err) {
    toast(err.message || String(err), { kind: 'warn', timeout: 7000 });
  }
};
ctx.toggle = guard(async (c) => {
  if (ctx.source === 'local' && !ctx.local.track) {
    await ctx.playLocal(null);
    return;
  }
  await ctx.engine.resume();
  await c.toggle();
});
ctx.next = guard((c) => c.next());
ctx.prev = guard((c) => c.prev());
ctx.seek = guard((c, sec) => c.seek(sec));
ctx.setShuffle = guard(async (c, on) => {
  await c.setShuffle(on);
  if (ctx.source === 'local') bridge.settings.set({ local: { shuffle: on } });
});
ctx.setRepeat = guard(async (c, mode) => {
  await c.setRepeat(mode);
  if (ctx.source === 'local') bridge.settings.set({ local: { repeat: mode } });
});

ctx.setVolume = (v) => {
  v = Math.max(0, Math.min(1, v));
  ctx.engine.setMasterVolume(v);
  ctx._muted = false;
  ctx.settings.masterVolume = v;
  saveVolume(v);
  $$('input.volume').forEach((el) => {
    if (Math.abs(el.value - v * 100) > 0.5) {
      el.value = Math.round(v * 100);
      syncRange(el);
    }
  });
  updateVolIcons();
};
const saveVolume = debounce((v) => bridge.settings.set({ masterVolume: v }), 400);
ctx.toggleMute = () => {
  if (ctx._muted) {
    ctx.engine.setMasterVolume(ctx.settings.masterVolume ?? 0.8);
    ctx._muted = false;
  } else {
    ctx.engine.setMasterVolume(0);
    ctx._muted = true;
  }
  updateVolIcons();
};
function updateVolIcons() {
  const v = ctx._muted ? 0 : ctx.settings.masterVolume ?? 0.8;
  $$('[data-act=mute]').forEach((b) => {
    b.innerHTML = v === 0 ? icons.mute : v < 0.45 ? icons.volumeLow : icons.volume;
    b.classList.toggle('muted', !!ctx._muted);
  });
}

ctx.playLocal = async (tracks, index = 0) => {
  if (!tracks || !tracks.length) {
    tracks = ctx.library.tracks.length ? ctx.library.tracks : [await testTune()];
    index = 0;
  }
  if (ctx.source !== 'local') await setSource('local');
  await ctx.engine.resume();
  ctx.local.playList(tracks, index);
};
ctx.playTestTune = async () => {
  const t = await testTune();
  await ctx.playLocal([t], 0);
};

// ------------------------------------------------------------------------------------------ library
async function loadLibrary() {
  try {
    const lib = await bridge.library.list();
    ctx.library.tracks = lib.tracks || [];
    ctx.library.folders = lib.folders || [];
    ctx.library.byId = new Map(ctx.library.tracks.map((t) => [t.id, t]));
  } catch (err) {
    console.error(err);
  }
  ctx.emit('library');
}
ctx.loadLibrary = loadLibrary;

ctx.coverUrl = (t, size = 320) => {
  if (!t) return generatedCover('unison', size, 265);
  if (t.builtIn) return generatedCover('Unison Test Tune', size, 262);
  if (t.cover && isDesktop) return `app://unison/cover/${t.cover}`;
  return generatedCover(`${t.album || t.title}|${t.albumArtist || t.artist}`, size);
};

ctx.artFor = (st) => {
  if (!st || !st.active) return null;
  if (st.source === 'local') {
    const t = ctx.local.track;
    return ctx.coverUrl(t);
  }
  return st.art || generatedCover(`${st.album || st.title}|${st.artist}`, 400);
};

// ------------------------------------------------------------------------------------------ now-playing reactions
let lastKey = null;
let lastPlaying = null;
function onNowChanged() {
  const st = ctx.nowState();
  const art = ctx.artFor(st);
  const key = `${st.source}|${st.title}|${st.artist}|${art ? art.length + art.slice(-32) : ''}`;
  if (key !== lastKey) {
    lastKey = key;
    ctx.artUrl = art;
    updatePalette(art);
    updateMediaSession(st, art);
  }
  if (st.playing !== lastPlaying) {
    lastPlaying = st.playing;
    bridge.power.playing(st.playing);
    document.documentElement.classList.toggle('is-playing', !!st.playing);
  }
  updatePlayerUI(st);
}

async function updatePalette(art) {
  const pal = art ? await paletteFromImage(art) : defaultPalette();
  ctx.palette = pal;
  ctx.bg && ctx.bg.setPalette(pal);
  const r = document.documentElement.style;
  r.setProperty('--accent', toCss(pal[0]));
  r.setProperty('--accent-2', toCss(pal[1]));
  r.setProperty('--accent-3', toCss(pal[2]));
  r.setProperty('--accent-a', toCss(pal[0], 0.35));
  r.setProperty('--accent-2a', toCss(pal[1], 0.35));
  ctx.emit('palette', pal);
}

function updateMediaSession(st, art) {
  if (!('mediaSession' in navigator)) return;
  if (ctx.source !== 'local' || !st.active) {
    navigator.mediaSession.metadata = null;
    return;
  }
  try {
    navigator.mediaSession.metadata = new MediaMetadata({ title: st.title, artist: st.artist, album: st.album, artwork: art ? [{ src: art, sizes: '512x512' }] : [] });
    const ms = navigator.mediaSession;
    ms.setActionHandler('play', () => ctx.local.play());
    ms.setActionHandler('pause', () => ctx.local.pause());
    ms.setActionHandler('nexttrack', () => ctx.local.next());
    ms.setActionHandler('previoustrack', () => ctx.local.prev());
    ms.setActionHandler('seekto', (d) => ctx.local.seek(d.seekTime));
  } catch (_) {}
}

function updatePlayerUI(st) {
  const title = st.active ? st.title : ctx.source === 'local' ? 'Nothing playing' : `${SOURCES[ctx.source].label}`;
  const artist = st.active
    ? [st.artist, st.app && st.app !== 'Spotify' && st.app !== 'Apple Music' ? `via ${st.app}` : ''].filter(Boolean).join(' · ')
    : ctx.source === 'local'
    ? 'Pick a song or a source'
    : 'Waiting for music…';
  const t = $('#pb-title');
  if (t) {
    t.textContent = title;
    $('#pb-artist').textContent = artist;
    const img = $('#pb-art');
    const art = ctx.artUrl || generatedCover('unison', 120);
    if (img.getAttribute('src') !== art) img.src = art;
    const spk = $('#pb-spk');
    if (spk) spk.textContent = ctx.engine ? ctx.engine.speakers.size : 0;
  }
  $$('.play-btn .pb-ico').forEach((el) => (el.innerHTML = st.playing ? icons.pause : icons.play));
  $$('.play-btn').forEach((el) => el.classList.toggle('playing', !!st.playing));
  $$('[data-t=shuffle]').forEach((el) => {
    el.classList.toggle('on', !!st.shuffle);
    el.disabled = st.canShuffle === false;
  });
  $$('[data-t=repeat]').forEach((el) => {
    el.classList.toggle('on', st.repeat !== 'off');
    el.innerHTML = st.repeat === 'one' ? icons.repeatOne : icons.repeat;
    el.disabled = st.canRepeat === false;
  });
  $$('input.progress').forEach((el) => (el.disabled = !st.active || st.canSeek === false));
  updateVolIcons();
  if (VIEWS[ctx.view].mod.onNow) VIEWS[ctx.view].mod.onNow(ctx, st);
}

// ------------------------------------------------------------------------------------------ frame loop
let lastProgUpdate = 0;
function frame(now) {
  requestAnimationFrame(frame);
  if (document.hidden) return;
  const f = ctx.features.update();
  const st = ctx.nowState();
  f.playing = st.playing || !!ctx.capture.stream;
  ctx.frameFeatures = f;
  if (ctx.bg) {
    const levels = [];
    for (const sp of ctx.engine.speakers.values()) levels.push(lvl(sp.level.rms));
    ctx.bg.setOrbs(levels);
    ctx.bg.render(f);
  }
  // party orbs pulse
  const orbs = $$('#party .orb');
  if (orbs.length) {
    for (const o of orbs) {
      const sp = ctx.engine.speakers.get(o.dataset.key);
      o.style.setProperty('--lvl', sp ? lvl(sp.level.rms).toFixed(3) : 0);
    }
  }
  if (now - lastProgUpdate > 120) {
    lastProgUpdate = now;
    const pos = ctx.position();
    const dur = st.duration || 0;
    $$('input.progress').forEach((el) => {
      if (el.dataset.drag) return;
      el.value = dur ? Math.round((pos / dur) * 1000) : 0;
      syncRange(el);
      const row = el.parentElement;
      const a = row.querySelector('[data-t=pos]');
      const b = row.querySelector('[data-t=dur]');
      if (a) a.textContent = fmtTime(pos);
      if (b) b.textContent = fmtTime(dur);
    });
  }
  document.documentElement.style.setProperty('--beat', f.beat.toFixed(3));
  document.documentElement.style.setProperty('--energy', f.energy.toFixed(3));
  const mod = VIEWS[ctx.view].mod;
  if (mod.tick) mod.tick(ctx, f, now);
}

// ------------------------------------------------------------------------------------------ input
function installKeys() {
  window.addEventListener('keydown', (e) => {
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      navigate(ctx.source === 'spotify' ? 'spotify' : 'library');
      setTimeout(() => {
        const s = $('.view input[type=search]');
        if (s) s.focus();
      }, 60);
      return;
    }
    if (mod && e.shiftKey && e.key.toLowerCase() === 'c') {
      e.preventDefault();
      speakersView.openCalibration(ctx);
      return;
    }
    if (typing && e.target.type !== 'range') return;
    if (e.key === ' ' && !typing) {
      e.preventDefault();
      ctx.toggle();
    } else if (e.key === 'ArrowRight' && !typing && e.altKey) {
      ctx.next();
    } else if (e.key === 'ArrowLeft' && !typing && e.altKey) {
      ctx.prev();
    } else if (e.key === 'ArrowRight' && !typing) {
      ctx.seek(ctx.position() + 10);
    } else if (e.key === 'ArrowLeft' && !typing) {
      ctx.seek(Math.max(0, ctx.position() - 10));
    } else if (e.key === 'ArrowUp' && !typing) {
      e.preventDefault();
      ctx.setVolume((ctx.settings.masterVolume ?? 0.8) + 0.05);
    } else if (e.key === 'ArrowDown' && !typing) {
      e.preventDefault();
      ctx.setVolume((ctx.settings.masterVolume ?? 0.8) - 0.05);
    } else if (e.key.toLowerCase() === 'm' && !typing && !mod) {
      ctx.toggleMute();
    }
  });
}

function installDrop() {
  let depth = 0;
  const root = document.documentElement;
  window.addEventListener('dragenter', (e) => {
    if (!e.dataTransfer || ![...e.dataTransfer.types].includes('Files')) return;
    depth++;
    root.classList.add('dropping');
  });
  window.addEventListener('dragleave', () => {
    depth = Math.max(0, depth - 1);
    if (!depth) root.classList.remove('dropping');
  });
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', async (e) => {
    e.preventDefault();
    depth = 0;
    root.classList.remove('dropping');
    const files = [...(e.dataTransfer.files || [])];
    if (!files.length) return;
    let res;
    if (isDesktop) {
      const paths = files.map((f) => bridge.library.pathForFile(f)).filter(Boolean);
      toast(`Adding ${paths.length} item${paths.length === 1 ? '' : 's'}…`, { timeout: 2000 });
      res = await bridge.library.addPaths(paths);
    } else {
      res = await bridge.library.addBrowserFiles(files.filter((f) => /^audio\//.test(f.type) || /\.(mp3|m4a|flac|wav|ogg|opus|aac)$/i.test(f.name)));
    }
    await loadLibrary();
    const added = res && res.added ? res.added.map((id) => ctx.library.byId.get(id)).filter(Boolean) : ctx.library.tracks.slice(-files.length);
    if (added.length) {
      toast(`Added ${added.length} song${added.length === 1 ? '' : 's'}`, { kind: 'ok', action: { label: 'Play', run: () => ctx.playLocal(added, 0) } });
    }
  });
}

// demo mode (browser only, ?demo): virtual speakers so the UI and engine can be explored
function installDemoSpeakers(mgr) {
  const fake = [
    { label: 'Headphones (JBL Flip 6 Stereo)', kind: 'bluetooth' },
    { label: 'Headphones (boAt Stone 1200 Stereo)', kind: 'bluetooth' },
    { label: 'Speakers (Sony SRS-XB33)', kind: 'bluetooth' },
    { label: 'Speakers (Realtek(R) Audio)', kind: 'builtin' },
    { label: 'Headset (JBL Flip 6 Hands-Free AG Audio)', kind: 'bluetooth' },
  ];
  const orig = mgr._refresh.bind(mgr);
  mgr._refresh = async function () {
    const { listDevices, prettyName, classify } = await import('./audio/devices.js');
    const real = await listDevices();
    real.outputs = fake.map((f, i) => {
      const pn = prettyName(f.label);
      return { id: 'none', label: f.label, name: pn.name, detail: pn.detail, kind: classify(f.label), handsFree: /hands-free/i.test(f.label), isDefault: i === 3, groupId: `demo${i}` };
    });
    real.defaultOutputLabel = fake[3].label;
    mgr.devices = real;
    const outs = real.outputs;
    mgr.byKey = new Map(outs.map((d) => [mgr.keyFor(d, outs), d]));
    for (const [key, cfg] of Object.entries(mgr.config)) if (cfg.active && mgr.byKey.has(key) && !mgr.engine.speakers.has(key)) await mgr._start(key);
    mgr._emit();
  };
  void orig;
  if (!Object.keys(mgr.config).length) {
    mgr.config = {
      'Headphones (JBL Flip 6 Stereo)': { active: true, enabled: true, volume: 1, channel: 'stereo', delay: 0.0612, trim: 0, measured: 0.2521, calibratedAt: Date.now() - 120000, name: 'JBL Flip 6', kind: 'bluetooth' },
      'Headphones (boAt Stone 1200 Stereo)': { active: true, enabled: true, volume: 0.85, channel: 'left', delay: 0, trim: 0, measured: 0.3133, calibratedAt: Date.now() - 120000, name: 'boAt Stone 1200', kind: 'bluetooth' },
      'Speakers (Sony SRS-XB33)': { active: true, enabled: true, volume: 0.9, channel: 'right', delay: 0.0238, trim: 0.002, measured: 0.2895, calibratedAt: Date.now() - 120000, name: 'Sony SRS-XB33', kind: 'bluetooth' },
    };
    ctx.settings.calibration = { at: Date.now() - 120000, lmax: 0.3133, base: 0.066, spreadBefore: 0.0612 };
  }
}

boot().catch((err) => {
  console.error(err);
  toast(`Startup error: ${err.message}`, { kind: 'error', timeout: 0 });
});

export { ctx };
