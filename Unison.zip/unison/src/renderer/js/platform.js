// Bridge to the desktop shell (Electron preload), or a browser stand-in for demo mode.

const DEFAULTS = {
  firstRun: true,
  captureMode: 'loopbackWithMute',
  captureDeviceLabel: '',
  micLabel: '',
  latencyMode: 'auto',
  engine: 'precision',
  sampleRate: 48000,
  masterVolume: 0.8,
  visuals: 'high',
  glass: true,
  reduceMotion: false,
  source: 'local',
  speakers: {},
  calibration: null,
  spotify: { clientId: '' },
  local: { shuffle: false, repeat: 'off', lastTrack: null },
  guideDone: {},
};

function guessPlatform() {
  const p = ((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '').toLowerCase();
  if (p.includes('mac')) return 'darwin';
  if (p.includes('win')) return 'win32';
  return 'linux';
}

function createBrowserBridge() {
  const KEY = 'unison-demo-settings';
  let settings;
  try {
    settings = { ...structuredClone(DEFAULTS), ...JSON.parse(localStorage.getItem(KEY) || '{}') };
  } catch (_) {
    settings = structuredClone(DEFAULTS);
  }
  const persist = () => {
    try {
      localStorage.setItem(KEY, JSON.stringify(settings));
    } catch (_) {}
  };
  const merge = (t, s) => {
    for (const [k, v] of Object.entries(s || {})) {
      if (v && typeof v === 'object' && !Array.isArray(v) && t[k] && typeof t[k] === 'object') merge(t[k], v);
      else t[k] = v;
    }
    return t;
  };
  const platform = guessPlatform();
  const notDesktop = async () => ({ ok: false, error: 'Available in the desktop app.' });
  const files = new Map();
  return {
    isDesktop: false,
    platform,
    info: async () => ({ platform, version: 'browser demo', hostname: 'browser', country: 'US', electron: null, chrome: navigator.userAgent }),
    settings: {
      get: async () => structuredClone(settings),
      set: async (patch) => {
        merge(settings, patch);
        persist();
        return structuredClone(settings);
      },
      replace: async (key, value) => {
        settings[key] = value;
        persist();
        return structuredClone(settings);
      },
    },
    shell: {
      open: async (url) => {
        window.open(url, '_blank', 'noopener');
        return true;
      },
      settings: async () => false,
    },
    mic: { ask: async () => true },
    power: { playing: async () => true },
    win: { onState: () => () => {} },
    library: {
      list: async () => ({ folders: [], tracks: [...files.values()] }),
      pickFolder: null,
      pickFiles: null,
      addBrowserFiles: async (fileList) => {
        for (const f of fileList) {
          const id = `f${Math.random().toString(36).slice(2, 10)}`;
          const base = f.name.replace(/\.[^.]+$/, '');
          const parts = base.split(/\s+-\s+/);
          files.set(id, {
            id,
            title: parts.length > 1 ? parts.slice(1).join(' - ') : base,
            artist: parts.length > 1 ? parts[0] : 'Unknown Artist',
            album: 'Dropped files',
            duration: 0,
            cover: null,
            src: URL.createObjectURL(f),
            addedAt: Date.now(),
          });
        }
        return { folders: [], tracks: [...files.values()] };
      },
      addPaths: async () => ({ folders: [], tracks: [...files.values()] }),
      removeFolder: async () => ({ folders: [], tracks: [...files.values()] }),
      rescan: async () => ({ folders: [], tracks: [...files.values()] }),
      onProgress: () => () => {},
      pathForFile: () => null,
    },
    spotify: {
      status: async () => ({ configured: false, connected: false, redirectUri: 'http://127.0.0.1:43821/callback', demo: true }),
      connect: async () => {
        throw new Error('Spotify sign-in works in the desktop app.');
      },
      cancel: async () => {},
      disconnect: async () => ({ configured: false, connected: false }),
      api: async () => ({ ok: false, status: 0, error: 'Available in the desktop app.' }),
    },
    art: { fetch: async () => null },
    apple: { call: notDesktop },
    winmedia: { call: notDesktop },
    itunes: { search: async () => [] },
    net: { online: async () => navigator.onLine },
  };
}

export const bridge = window.unison || createBrowserBridge();
export const isDesktop = !!(window.unison && window.unison.isDesktop);
export const platform = bridge.platform;
export const isMac = platform === 'darwin';
export const isWin = platform === 'win32';
export { DEFAULTS };
