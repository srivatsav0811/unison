// Speaker party manager: devices <-> engine outputs <-> saved per-speaker settings.
import { listDevices } from './audio/devices.js';

const DEFAULT_CFG = { active: true, enabled: true, volume: 1, channel: 'stereo', delay: 0, trim: 0 };

export class SpeakerManager extends EventTarget {
  constructor(engine, bridge, saved = {}) {
    super();
    this.engine = engine;
    this.bridge = bridge;
    this.config = JSON.parse(JSON.stringify(saved || {}));
    this.devices = { outputs: [], inputs: [] };
    this.byKey = new Map();
    this.status = new Map();
    this._saveT = null;
    this._refreshing = null;
  }

  keyFor(device, list) {
    const same = list.filter((d) => d.label === device.label);
    const base = device.label || device.id;
    return same.length > 1 ? `${base}#${same.indexOf(device) + 1}` : base;
  }

  refresh() {
    if (this._refreshing) return this._refreshing;
    this._refreshing = this._refresh().finally(() => {
      this._refreshing = null;
    });
    return this._refreshing;
  }

  async _refresh() {
    this.devices = await listDevices();
    const outs = this.devices.outputs;
    const before = new Set(this.byKey.keys());
    const firstLook = !this._seenOnce;
    this._seenOnce = true;
    this.byKey = new Map(outs.map((d) => [this.keyFor(d, outs), d]));
    // newly connected Bluetooth speakers we have never configured -> offer them
    const fresh = [...this.byKey].filter(([k, d]) => !before.has(k) && !this.config[k] && d.kind === 'bluetooth' && !d.handsFree);
    if (firstLook && !Object.keys(this.config).length && fresh.length) {
      // very first start: add every Bluetooth speaker that's already connected
      for (const [k, d] of fresh) this.config[k] = { ...DEFAULT_CFG, name: d.name, kind: d.kind };
      this.save();
      this.dispatchEvent(new CustomEvent('auto-added', { detail: fresh.map(([, d]) => d.name) }));
    } else if (!firstLook) {
      for (const [k, d] of fresh) this.dispatchEvent(new CustomEvent('new-device', { detail: { key: k, name: d.name } }));
    }
    for (const id of [...this.engine.speakers.keys()]) {
      const d = this.byKey.get(id);
      const sp = this.engine.speakers.get(id);
      if (!d || (sp && sp.deviceId !== d.id)) {
        await this.engine.removeSpeaker(id);
        this.status.set(id, { state: d ? 'restarting' : 'disconnected' });
      }
    }
    for (const [key, cfg] of Object.entries(this.config)) {
      if (cfg.active && this.byKey.has(key) && !this.engine.speakers.has(key)) await this._start(key);
    }
    this._emit();
  }

  async _start(key) {
    const d = this.byKey.get(key);
    const cfg = this.config[key];
    if (!d || !cfg) return;
    this.status.set(key, { state: 'starting' });
    this._emit();
    try {
      const sp = await this.engine.addSpeaker(key, d.id, cfg);
      sp.kind = d.kind;
      this.status.set(key, { state: 'on' });
    } catch (err) {
      this.status.set(key, { state: 'error', error: err.message || String(err) });
    }
    this._emit();
  }

  async activate(key) {
    const d = this.byKey.get(key);
    if (!d) return;
    const cfg = (this.config[key] = { ...DEFAULT_CFG, ...(this.config[key] || {}), active: true, name: d.name, kind: d.kind });
    this.save();
    if (!this.engine.speakers.has(key)) await this._start(key);
    return cfg;
  }

  async deactivate(key) {
    if (this.config[key]) this.config[key].active = false;
    this.save();
    await this.engine.removeSpeaker(key);
    this.status.delete(key);
    this._emit();
  }

  set(key, patch) {
    const cfg = (this.config[key] = { ...DEFAULT_CFG, ...(this.config[key] || {}), ...patch });
    this.engine.setSpeaker(key, patch);
    this.save();
    this._emit('tweak');
    return cfg;
  }

  applyCalibration(summary) {
    for (const [key, delay] of Object.entries(summary.delays || {})) {
      const r = summary.results[key];
      this.set(key, { delay, trim: 0, measured: r ? r.latency : null, calibratedAt: summary.at });
    }
  }

  activeKeys() {
    return [...this.engine.speakers.keys()];
  }

  /** view models for the UI */
  list() {
    const out = [];
    const seen = new Set();
    for (const [key, d] of this.byKey) {
      seen.add(key);
      const cfg = this.config[key] || {};
      const sp = this.engine.speakers.get(key);
      out.push({
        key,
        device: d,
        name: d.name,
        detail: d.detail,
        kind: d.kind,
        handsFree: d.handsFree,
        isDefault: d.isDefault,
        connected: true,
        active: !!sp,
        wanted: !!cfg.active,
        enabled: cfg.enabled !== false,
        volume: cfg.volume ?? 1,
        channel: cfg.channel || 'stereo',
        delay: cfg.delay || 0,
        trim: cfg.trim || 0,
        measured: cfg.measured ?? null,
        calibratedAt: cfg.calibratedAt || null,
        status: this.status.get(key) || null,
        sp,
      });
    }
    for (const [key, cfg] of Object.entries(this.config)) {
      if (seen.has(key) || !cfg.active) continue;
      out.push({
        key,
        name: cfg.name || key,
        detail: 'Not connected — turn it on or pair it again',
        kind: cfg.kind || 'bluetooth',
        connected: false,
        active: false,
        wanted: true,
        enabled: cfg.enabled !== false,
        volume: cfg.volume ?? 1,
        channel: cfg.channel || 'stereo',
        delay: cfg.delay || 0,
        trim: cfg.trim || 0,
        status: { state: 'disconnected' },
      });
    }
    const rank = (s) => (s.active ? 0 : s.wanted ? 1 : s.kind === 'bluetooth' ? 2 : s.kind === 'virtual' ? 5 : 3);
    return out.sort((a, b) => rank(a) - rank(b) || a.name.localeCompare(b.name));
  }

  forget(key) {
    delete this.config[key];
    this.save();
    this._emit();
  }

  save() {
    clearTimeout(this._saveT);
    this._saveT = setTimeout(() => this.bridge.settings.replace('speakers', this.config), 300);
  }

  _emit(kind = 'change') {
    this.dispatchEvent(new CustomEvent(kind));
    if (kind !== 'change') this.dispatchEvent(new CustomEvent('any'));
    else this.dispatchEvent(new CustomEvent('any'));
  }
}
