// Full-window WebGL2 scene: a raymarched liquid-glass core that breathes with the bass,
// a glowing orbit ring, one glass orb per active speaker (pulsing with that speaker's level)
// and an aurora sky tinted by the current album art. Falls back to CSS when WebGL2 is missing.

const VERT = `#version 300 es
in vec2 p; void main(){ gl_Position = vec4(p,0.,1.); }`;

const FRAG = (steps) => `#version 300 es
precision highp float;
out vec4 o;
uniform vec2 uRes; uniform float uTime, uBass, uMid, uHigh, uEnergy, uBeat, uPlay;
uniform vec3 uA, uB, uC; uniform vec2 uMouse;
uniform float uOrb[8]; uniform int uOrbN;
#define STEPS ${steps}

float hash(vec3 p){ p = fract(p*0.3183099+.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float hash2(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash2(i),hash2(i+vec2(1,0)),f.x), mix(hash2(i+vec2(0,1)),hash2(i+vec2(1,1)),f.x), f.y); }
float fbm(vec2 p){ float v=0., a=.5; for(int i=0;i<3;i++){ v+=a*noise(p); p=p*2.03+vec2(1.7,9.2); a*=.5; } return v; }
mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,-s,s,c); }
float smin(float a, float b, float k){ float h=clamp(.5+.5*(b-a)/k,0.,1.); return mix(b,a,h)-k*h*(1.-h); }

vec3 env(vec3 rd){
  float t = uTime*.04;
  vec3 col = mix(vec3(.0035,.0025,.009), vec3(.014,.007,.032), smoothstep(-.6,.8,rd.y));
  vec2 q = vec2(atan(rd.x,-rd.z)*1.3, rd.y*2.2);
  float n = fbm(vec2(q.x*1.2 + t, q.y*1.6 - t*.7) + fbm(q*1.7 - t)*1.2);
  float band = smoothstep(.38,.95,n) * smoothstep(-.35,.55,rd.y+.15);
  col += mix(uA, uB, clamp(n*1.4-.2,0.,1.)) * band * (.06 + uEnergy*.32 + uBeat*.07);
  col += uC * .09 * pow(max(0., dot(rd, normalize(vec3(-.7,.35,-1.)))), 7.);
  col += uA * .07 * pow(max(0., dot(rd, normalize(vec3(.8,-.25,-1.)))), 5.);
  col += uB * .04 * pow(max(0., dot(rd, normalize(vec3(0.,-.9,-.6)))), 3.);
  vec3 sp = rd*170.; vec3 id = floor(sp); float h = hash(id);
  if (h > .982) { float tw = .5+.5*sin(uTime*(1.5+h*3.)+h*90.);
    col += vec3(.75,.8,1.) * smoothstep(.42,.0,length(fract(sp)-.5)) * tw * (.18 + uHigh*.9); }
  return col;
}

// ---- scene
const float RING = 1.5;
vec3 ringP(vec3 p){ p.yz *= rot(1.28); p.xy *= rot(uTime*.05); return p; }

float blob(vec3 p){
  float t = uTime*.45;
  float r = .58 + uBass*.20 + uBeat*.05;
  float d = length(p - .26*vec3(sin(t), cos(t*1.3), sin(t*.7))) - r;
  d = smin(d, length(p - .30*vec3(cos(t*.8+2.), sin(t*1.1), cos(t*1.7))) - r*.78, .45);
  d = smin(d, length(p - .28*vec3(sin(t*1.5+4.), cos(t*.6+1.), sin(t*1.2))) - r*.70, .45);
  d += (.035 + uMid*.05) * sin(p.x*5.+uTime*1.3)*sin(p.y*5.3-uTime)*sin(p.z*4.7+uTime*.8);
  return d;
}

float orbs(vec3 p, out float lvl){
  vec3 q = ringP(p);
  float d = 1e3; lvl = 0.;
  for (int i=0;i<8;i++){
    if (i>=uOrbN) break;
    float a = 6.2831853*float(i)/float(uOrbN) + uTime*.12;
    vec3 c = vec3(cos(a)*RING, sin(a)*RING, 0.);
    float r = .11 + uOrb[i]*.16;
    float di = length(q-c) - r;
    if (di < d){ d = di; lvl = uOrb[i]; }
  }
  return d;
}

float ring(vec3 p){ vec3 q = ringP(p); vec2 t = vec2(length(q.xy)-RING, q.z); return length(t) - (.006 + uHigh*.012); }

float map(vec3 p, out int m, out float lvl){
  float b = blob(p); float o = orbs(p, lvl); m = 0; float d = b;
  if (o < d){ d = o; m = 1; }
  return d;
}

vec3 nrm(vec3 p){
  int m; float l; const vec2 e = vec2(1.,-1.)*.0015;
  return normalize(e.xyy*map(p+e.xyy,m,l) + e.yyx*map(p+e.yyx,m,l) + e.yxy*map(p+e.yxy,m,l) + e.xxx*map(p+e.xxx,m,l));
}

vec3 aces(vec3 x){ return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.); }

void main(){
  vec2 uv = (gl_FragCoord.xy - .5*uRes)/uRes.y;
  // camera sits to the right so the scene floats behind the record on the left
  vec3 ro = vec3(-.62 + uMouse.x*.45, uMouse.y*.3 + .05, 5.4);
  vec3 ta = vec3(-.62 + uMouse.x*.1, .0, 0.);
  vec3 fw = normalize(ta-ro), rt = normalize(cross(vec3(0,1,0),fw)), up = cross(fw,rt);
  vec3 rd = normalize(fw*1.9 + uv.x*rt + uv.y*up);

  vec3 col = env(rd);
  float glow = 0.;
  // bounding sphere
  float bb = dot(ro,rd); float cc = dot(ro,ro) - 2.25*2.25; float h = bb*bb - cc;
  if (h > 0.) {
    float t = max(0., -bb - sqrt(h)); float tmax = -bb + sqrt(h);
    int m = -1; float lvl = 0.; bool hit = false;
    for (int i=0;i<STEPS;i++){
      vec3 p = ro + rd*t;
      int mm; float l;
      float d = map(p, mm, l);
      float dr = ring(p);
      glow += .0018/(.0009 + dr*dr*6.);
      if (d < .0015){ hit = true; m = mm; lvl = l; break; }
      t += min(d, max(dr, .035))*.9;
      if (t > tmax) break;
    }
    if (hit){
      vec3 p = ro + rd*t; vec3 n = nrm(p);
      float fr = pow(1. - max(0., dot(n,-rd)), 3.);
      vec3 refl = env(reflect(rd,n));
      vec3 rr = refract(rd, n, 1./1.45), rg = refract(rd, n, 1./1.47), rb = refract(rd, n, 1./1.50);
      vec3 refr = vec3(env(rr).r, env(rg).g, env(rb).b);
      vec3 film = .5 + .5*cos(6.2831*(vec3(0.,.33,.67) + dot(n,rd)*1.6 + uTime*.05));
      vec3 tint = m == 0 ? mix(uA, uB, .5+.5*n.y) : uC;
      vec3 base = refr*mix(vec3(1.), tint, .55)*1.6 + film*tint*.05;
      col = mix(base, refl*1.6, .25 + fr*.7);
      vec3 L1 = normalize(vec3(-.5,.8,.6)), L2 = normalize(vec3(.7,.2,.5));
      col += vec3(1.)*pow(max(0.,dot(reflect(rd,n),L1)), 60.)*.75 + uC*pow(max(0.,dot(reflect(rd,n),L2)), 24.)*.3;
      col += tint * fr * .35;
      if (m == 0) col += tint * (1.-fr) * (.03 + uEnergy*.22 + uBeat*.1);
      else col += uC * (.06 + lvl*1.4) * (1.-fr*.6);
    }
  }
  col += mix(uA, uC, .5) * glow * (.12 + uHigh*.35 + uBeat*.35) * (.5 + .5*uPlay);
  col = aces(col*1.08);
  col *= 1. - .35*dot(uv*.9,uv*.9);
  col += (hash2(gl_FragCoord.xy + fract(uTime)*97.)-.5)*.018;
  o = vec4(pow(col, vec3(.4545)), 1.);
}`;

const QUALITY = {
  ultra: { scale: 1.0, steps: 72 },
  high: { scale: 0.72, steps: 56 },
  balanced: { scale: 0.55, steps: 42 },
  low: { scale: 0.4, steps: 30 },
};

export class Background {
  constructor(canvas) {
    this.canvas = canvas;
    this.quality = 'high';
    this.enabled = true;
    this.palette = { a: [0.55, 0.36, 0.96], b: [0.13, 0.83, 0.93], c: [0.96, 0.45, 0.71] };
    this.cur = JSON.parse(JSON.stringify(this.palette));
    this.mouse = [0, 0];
    this.mouseT = [0, 0];
    this.orbs = [];
    this.start = performance.now();
    this.scale = 0.72;
    this.frameTimes = [];
    this.gl = canvas.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: false });
    this.ok = !!this.gl;
    if (!this.ok) {
      document.documentElement.classList.add('no-webgl');
      return;
    }
    window.addEventListener('pointermove', (e) => {
      this.mouseT = [(e.clientX / window.innerWidth) * 2 - 1, -((e.clientY / window.innerHeight) * 2 - 1)];
    });
    this.setQuality('high');
  }

  setQuality(q) {
    if (!this.ok || q === this._q) return;
    this._q = q;
    if (q === 'off') {
      this.enabled = false;
      this.canvas.style.opacity = '0';
      document.documentElement.classList.add('bg-off');
      return;
    }
    document.documentElement.classList.remove('bg-off');
    this.canvas.style.opacity = '1';
    this.enabled = true;
    const Q = QUALITY[q] || QUALITY.high;
    this.quality = q;
    this.targetScale = Q.scale;
    // start light and grow to the target once we know frames are fast (avoids start-up jank)
    this.scale = Math.min(Q.scale, 0.5);
    this._compile(Q.steps);
    this.resize();
  }

  _compile(steps) {
    const gl = this.gl;
    const sh = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG(steps)));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    if (this.prog) gl.deleteProgram(this.prog);
    this.prog = prog;
    gl.useProgram(prog);
    if (!this.vbo) {
      this.vbo = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    }
    const loc = gl.getAttribLocation(prog, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    this.u = {};
    for (const n of ['uRes', 'uTime', 'uBass', 'uMid', 'uHigh', 'uEnergy', 'uBeat', 'uPlay', 'uA', 'uB', 'uC', 'uMouse', 'uOrb', 'uOrbN']) this.u[n] = gl.getUniformLocation(prog, n);
  }

  resize() {
    if (!this.ok) return;
    const w = Math.max(2, Math.round(window.innerWidth * this.scale));
    const h = Math.max(2, Math.round(window.innerHeight * this.scale));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
      this.gl.viewport(0, 0, w, h);
    }
  }

  setPalette(colors) {
    if (!colors || colors.length < 3) return;
    this.palette = { a: colors[0], b: colors[1], c: colors[2] };
  }

  setOrbs(levels) {
    this.orbs = levels.slice(0, 8);
  }

  /** f: { bass, mid, high, energy, beat, playing } */
  render(f) {
    if (!this.ok || !this.enabled) return;
    const t0 = performance.now();
    const gl = this.gl;
    const u = this.u;
    const k = 0.035;
    for (const key of ['a', 'b', 'c']) for (let i = 0; i < 3; i++) this.cur[key][i] += (this.palette[key][i] - this.cur[key][i]) * k;
    this.mouse[0] += (this.mouseT[0] - this.mouse[0]) * 0.05;
    this.mouse[1] += (this.mouseT[1] - this.mouse[1]) * 0.05;
    this.resize();
    gl.uniform2f(u.uRes, this.canvas.width, this.canvas.height);
    gl.uniform1f(u.uTime, (t0 - this.start) / 1000);
    gl.uniform1f(u.uBass, f.bass || 0);
    gl.uniform1f(u.uMid, f.mid || 0);
    gl.uniform1f(u.uHigh, f.high || 0);
    gl.uniform1f(u.uEnergy, f.energy || 0);
    gl.uniform1f(u.uBeat, f.beat || 0);
    gl.uniform1f(u.uPlay, f.playing ? 1 : 0.4);
    gl.uniform3fv(u.uA, this.cur.a);
    gl.uniform3fv(u.uB, this.cur.b);
    gl.uniform3fv(u.uC, this.cur.c);
    gl.uniform2f(u.uMouse, this.mouse[0], this.mouse[1]);
    const orbArr = new Float32Array(8);
    this.orbs.forEach((v, i) => (orbArr[i] = v));
    gl.uniform1fv(u.uOrb, orbArr);
    gl.uniform1i(u.uOrbN, this.orbs.length);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this._adaptResolution(performance.now() - t0);
  }

  // dynamic resolution: keep the UI smooth on integrated GPUs
  _adaptResolution() {
    const now = performance.now();
    if (this._last) {
      this.frameTimes.push(now - this._last);
      if (this.frameTimes.length > 45) this.frameTimes.shift();
    }
    this._last = now;
    if (this.frameTimes.length < 45 || now - (this._lastAdj || 0) < 1500) return;
    const avg = this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length;
    if (avg > 24 && this.scale > 0.3) {
      this.scale = Math.max(0.3, this.scale - 0.08);
      this._lastAdj = now;
      this.frameTimes = [];
    } else if (avg < 17.5 && this.scale < this.targetScale) {
      this.scale = Math.min(this.targetScale, this.scale + 0.05);
      this._lastAdj = now;
      this.frameTimes = [];
    }
  }
}
