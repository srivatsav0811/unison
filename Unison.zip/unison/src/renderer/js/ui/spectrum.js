// Radial spectrum ring drawn around the spinning record.
import { toCss } from './palette.js';

export class RadialSpectrum {
  constructor(canvas) {
    this.canvas = canvas;
    this.g = canvas.getContext('2d');
    this.bars = 96;
    this.vals = new Float32Array(this.bars);
    this.palette = [
      [0.55, 0.36, 0.96],
      [0.13, 0.83, 0.93],
      [0.96, 0.45, 0.71],
    ];
  }

  setPalette(p) {
    this.palette = p;
  }

  draw(bins, energy = 0, beat = 0) {
    const c = this.canvas;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = c.clientWidth;
    const h = c.clientHeight;
    if (!w || !h) return;
    if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) {
      c.width = Math.round(w * dpr);
      c.height = Math.round(h * dpr);
    }
    const g = this.g;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    const cx = w / 2;
    const cy = h / 2;
    const R = Math.min(w, h) * 0.335;
    const maxLen = Math.min(w, h) * 0.15;
    const n = this.bars;
    const half = n / 2;
    // log-spaced sampling of the lower ~70% of the spectrum
    const binCount = bins ? bins.length : 0;
    for (let i = 0; i < half; i++) {
      let v = 0;
      if (binCount) {
        const f0 = Math.pow(i / half, 1.9) * binCount * 0.62;
        const f1 = Math.pow((i + 1) / half, 1.9) * binCount * 0.62;
        let s = 0;
        let k = 0;
        for (let b = Math.floor(f0); b <= Math.ceil(f1); b++) {
          s += bins[Math.min(binCount - 1, b)];
          k++;
        }
        v = s / (k * 255);
        v = Math.pow(v, 1.6) * (1 + i / half);
      }
      this.vals[i] += (v - this.vals[i]) * (v > this.vals[i] ? 0.55 : 0.18);
    }
    g.globalCompositeOperation = 'lighter';
    const [a, b, cc] = this.palette;
    g.lineCap = 'round';
    for (let i = 0; i < n; i++) {
      const vi = i < half ? i : n - 1 - i;
      const v = this.vals[vi];
      const ang = (i / n) * Math.PI * 2 - Math.PI / 2;
      const len = 3 + v * maxLen * (1 + beat * 0.25);
      const x0 = cx + Math.cos(ang) * R;
      const y0 = cy + Math.sin(ang) * R;
      const x1 = cx + Math.cos(ang) * (R + len);
      const y1 = cy + Math.sin(ang) * (R + len);
      const t = vi / half;
      const col = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
      g.strokeStyle = toCss(col, 0.25);
      g.lineWidth = 7;
      g.beginPath();
      g.moveTo(x0, y0);
      g.lineTo(x1, y1);
      g.stroke();
      g.strokeStyle = toCss(col, 0.95);
      g.lineWidth = 2.4;
      g.beginPath();
      g.moveTo(x0, y0);
      g.lineTo(x1, y1);
      g.stroke();
    }
    // inner glow ring
    const rg = g.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.25);
    rg.addColorStop(0, toCss(cc, 0));
    rg.addColorStop(0.5, toCss(cc, 0.12 + energy * 0.35 + beat * 0.2));
    rg.addColorStop(1, toCss(cc, 0));
    g.fillStyle = rg;
    g.beginPath();
    g.arc(cx, cy, R * 1.25, 0, Math.PI * 2);
    g.fill();
    g.globalCompositeOperation = 'source-over';
  }
}
