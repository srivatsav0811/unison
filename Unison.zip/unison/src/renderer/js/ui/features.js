// Audio features for the visuals (bass/mid/high/energy/beat + spectrum), delayed so the
// visuals line up with what you HEAR from the (slow) Bluetooth speakers, not with the
// audio Unison is still preparing.

export class AudioFeatures {
  constructor(analyser, sampleRate) {
    this.analyser = analyser;
    this.sr = sampleRate;
    this.bins = new Uint8Array(analyser.frequencyBinCount);
    this.queue = [];
    this.delay = 0.15;
    this.avgBass = 0.1;
    this.beat = 0;
    this.out = { bins: new Uint8Array(analyser.frequencyBinCount), bass: 0, mid: 0, high: 0, energy: 0, beat: 0 };
    this.smooth = { bass: 0, mid: 0, high: 0, energy: 0 };
  }

  setDelay(sec) {
    this.delay = Math.max(0, Math.min(1.5, sec || 0));
  }

  band(bins, f0, f1) {
    const hz = this.sr / 2 / bins.length;
    const a = Math.max(0, Math.floor(f0 / hz));
    const b = Math.min(bins.length - 1, Math.ceil(f1 / hz));
    let s = 0;
    for (let i = a; i <= b; i++) s += bins[i];
    return s / ((b - a + 1) * 255);
  }

  update() {
    const now = performance.now();
    this.analyser.getByteFrequencyData(this.bins);
    this.queue.push({ t: now, bins: this.bins.slice() });
    // pick the frame captured `delay` seconds ago
    const target = now - this.delay * 1000;
    let frame = null;
    while (this.queue.length && this.queue[0].t <= target) frame = this.queue.shift();
    if (frame) this.out.bins = frame.bins;
    if (this.queue.length > 240) this.queue.splice(0, this.queue.length - 240);
    const b = this.out.bins;
    const bass = this.band(b, 25, 160);
    const mid = this.band(b, 160, 2000);
    const high = this.band(b, 2000, 12000);
    const k = 0.35;
    this.smooth.bass += (bass - this.smooth.bass) * k;
    this.smooth.mid += (mid - this.smooth.mid) * k;
    this.smooth.high += (high - this.smooth.high) * k;
    const energy = bass * 0.5 + mid * 0.35 + high * 0.15;
    this.smooth.energy += (energy - this.smooth.energy) * 0.12;
    // beat: bass flux above its running average
    this.avgBass = this.avgBass * 0.96 + bass * 0.04;
    if (bass > this.avgBass * 1.28 && bass > 0.2 && now - (this._lastBeat || 0) > 180) {
      this.beat = 1;
      this._lastBeat = now;
    }
    this.beat *= 0.9;
    this.out.bass = Math.pow(this.smooth.bass, 1.3);
    this.out.mid = this.smooth.mid;
    this.out.high = this.smooth.high;
    this.out.energy = this.smooth.energy;
    this.out.beat = this.beat;
    return this.out;
  }
}
