// Extract a 3-colour palette from album art so the whole UI and 3D scene take on its mood.

const DEFAULT = [
  [0.55, 0.36, 0.96],
  [0.13, 0.83, 0.93],
  [0.96, 0.45, 0.71],
];

export async function paletteFromImage(url) {
  if (!url) return DEFAULT;
  try {
    const img = await loadImage(url);
    const c = document.createElement('canvas');
    const N = 40;
    c.width = c.height = N;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0, N, N);
    const { data } = g.getImageData(0, 0, N, N);
    // bucket by hue, weight by saturation * mid-brightness
    const buckets = new Array(24).fill(0).map(() => ({ w: 0, r: 0, g: 0, b: 0 }));
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i] / 255;
      const gg = data[i + 1] / 255;
      const b = data[i + 2] / 255;
      const [h, s, l] = rgbToHsl(r, gg, b);
      const w = s * (1 - Math.abs(l - 0.5) * 1.6) + 0.02;
      if (w <= 0) continue;
      const k = Math.floor(h * 24) % 24;
      buckets[k].w += w;
      buckets[k].r += r * w;
      buckets[k].g += gg * w;
      buckets[k].b += b * w;
    }
    const ranked = buckets
      .map((bk, i) => ({ ...bk, i }))
      .filter((bk) => bk.w > 0)
      .sort((a, b) => b.w - a.w);
    const picks = [];
    for (const bk of ranked) {
      if (picks.every((p) => Math.min(Math.abs(p.i - bk.i), 24 - Math.abs(p.i - bk.i)) >= 3)) picks.push(bk);
      if (picks.length === 3) break;
    }
    const cols = picks.map((p) => vivid([p.r / p.w, p.g / p.w, p.b / p.w]));
    while (cols.length < 3) cols.push(DEFAULT[cols.length]);
    return cols;
  } catch (_) {
    return DEFAULT;
  }
}

export const defaultPalette = () => DEFAULT.map((c) => c.slice());

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

function rgbToHsl(r, g, b) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h;
  if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
  else if (max === g) h = (b - r) / d + 2;
  else h = (r - g) / d + 4;
  return [h / 6, s, l];
}

function hslToRgb(h, s, l) {
  const f = (n) => {
    const k = (n + h * 12) % 12;
    const a = s * Math.min(l, 1 - l);
    return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
  };
  return [f(0), f(8), f(4)];
}

// push colours toward saturated, mid-bright tones that glow nicely on the dark UI
function vivid([r, g, b]) {
  const [h, s, l] = rgbToHsl(r, g, b);
  return hslToRgb(h, Math.max(0.55, Math.min(1, s * 1.25)), Math.max(0.45, Math.min(0.66, l)));
}

export function toCss([r, g, b], a = 1) {
  return `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)}, ${a})`;
}
