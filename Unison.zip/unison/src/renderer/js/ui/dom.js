// Small DOM toolkit: safe templating, formatting, toasts, modals and 3D/glass interactions.
import { icons } from './icons.js';

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

class Raw {
  constructor(s) {
    this.s = s;
  }
  toString() {
    return this.s;
  }
}
export const raw = (s) => new Raw(s);

/** Tagged template: interpolations are escaped unless wrapped in raw() or are arrays of Raw. */
export function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => {
    out += s;
    if (i < vals.length) {
      const v = vals[i];
      if (v instanceof Raw) out += v.s;
      else if (Array.isArray(v)) out += v.map((x) => (x instanceof Raw ? x.s : esc(x))).join('');
      else if (v === false || v == null) out += '';
      else out += esc(v);
    }
  });
  return new Raw(out);
}

export function fmtTime(sec) {
  if (!Number.isFinite(sec) || sec < 0) sec = 0;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}

/** perceptual 0..1 level from an RMS value (for meters/visuals) */
export const lvl = (rms) => Math.min(1, Math.sqrt(Math.max(0, rms || 0)) * 1.9);

export const fmtMs = (sec, digits = 0) => `${(sec * 1000).toFixed(digits)} ms`;

export function timeAgo(ts) {
  if (!ts) return 'never';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
}

export function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

// ---------------------------------------------------------------- toasts
let toastHost;
export function toast(message, { kind = 'info', timeout = 4200, action } = {}) {
  if (!toastHost) {
    toastHost = document.createElement('div');
    toastHost.className = 'toasts';
    document.body.appendChild(toastHost);
  }
  const el = document.createElement('div');
  el.className = `toast glass toast-${kind}`;
  el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
  const icon = { info: icons.info, ok: icons.check, warn: icons.alert, error: icons.alert }[kind] || icons.info;
  el.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${esc(message)}</span>${
    action ? `<button class="btn btn-sm btn-ghost toast-act">${esc(action.label)}</button>` : ''
  }<button class="icon-btn toast-x" aria-label="Dismiss">${icons.x}</button>`;
  const close = () => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 350);
  };
  el.querySelector('.toast-x').onclick = close;
  if (action) {
    el.querySelector('.toast-act').onclick = () => {
      action.run();
      close();
    };
  }
  toastHost.appendChild(el);
  if (timeout) setTimeout(close, timeout);
  return close;
}

// ---------------------------------------------------------------- modal
export function modal({ title, body, className = '', onClose, dismissable = true }) {
  const wrap = document.createElement('div');
  wrap.className = 'modal-wrap';
  wrap.innerHTML = `<div class="modal glass ${className}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="modal-head"><h2>${esc(title)}</h2>${dismissable ? `<button class="icon-btn modal-x" aria-label="Close">${icons.x}</button>` : ''}</div>
    <div class="modal-body"></div></div>`;
  const bodyEl = wrap.querySelector('.modal-body');
  if (typeof body === 'string' || body instanceof Raw) bodyEl.innerHTML = String(body);
  else if (body instanceof Node) bodyEl.appendChild(body);
  const close = () => {
    wrap.classList.add('out');
    document.removeEventListener('keydown', onKey);
    setTimeout(() => wrap.remove(), 280);
    onClose && onClose();
  };
  const onKey = (e) => {
    if (e.key === 'Escape' && dismissable) close();
  };
  document.addEventListener('keydown', onKey);
  if (dismissable) {
    wrap.querySelector('.modal-x').onclick = close;
    wrap.addEventListener('pointerdown', (e) => {
      if (e.target === wrap) close();
    });
  }
  document.body.appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add('in'));
  return { el: wrap.querySelector('.modal'), body: bodyEl, close };
}

// ---------------------------------------------------------------- glass + 3D interactions
let reduceMotion = false;
export function setReduceMotion(v) {
  reduceMotion = v;
}

/** Specular highlight that follows the pointer on every .glass/.tile element (event delegation). */
export function installSpecular(root = document) {
  root.addEventListener(
    'pointermove',
    (e) => {
      const el = e.target.closest && e.target.closest('.glass, .tile, .btn, .spec');
      if (!el) return;
      const r = el.getBoundingClientRect();
      el.style.setProperty('--mx', `${e.clientX - r.left}px`);
      el.style.setProperty('--my', `${e.clientY - r.top}px`);
    },
    { passive: true }
  );
}

/** 3D tilt for elements with [data-tilt] (delegated). */
export function installTilt(root = document) {
  let active = null;
  root.addEventListener(
    'pointermove',
    (e) => {
      if (reduceMotion) return;
      const el = e.target.closest && e.target.closest('[data-tilt]');
      if (active && active !== el) reset(active);
      active = el;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      const max = parseFloat(el.dataset.tilt) || 10;
      el.style.setProperty('--rx', `${(-py * max).toFixed(2)}deg`);
      el.style.setProperty('--ry', `${(px * max).toFixed(2)}deg`);
      el.style.setProperty('--gx', `${(px + 0.5) * 100}%`);
      el.style.setProperty('--gy', `${(py + 0.5) * 100}%`);
      el.classList.add('tilting');
    },
    { passive: true }
  );
  root.addEventListener('pointerleave', () => active && reset(active), true);
  function reset(el) {
    el.style.setProperty('--rx', '0deg');
    el.style.setProperty('--ry', '0deg');
    el.classList.remove('tilting');
  }
}

/** Ripple on click for .btn / .icon-btn / .ripple */
export function installRipple(root = document) {
  root.addEventListener('pointerdown', (e) => {
    const el = e.target.closest && e.target.closest('.btn, .icon-btn, .ripple, .seg button, .nav-item');
    if (!el || reduceMotion) return;
    const r = el.getBoundingClientRect();
    const d = Math.max(r.width, r.height) * 2;
    const s = document.createElement('span');
    s.className = 'ripple-ink';
    s.style.width = s.style.height = `${d}px`;
    s.style.left = `${e.clientX - r.left - d / 2}px`;
    s.style.top = `${e.clientY - r.top - d / 2}px`;
    el.appendChild(s);
    setTimeout(() => s.remove(), 650);
  });
}

/** Keep an <input type=range> gradient fill in sync (--p custom property). */
export function syncRange(input) {
  const min = parseFloat(input.min || 0);
  const max = parseFloat(input.max || 100);
  const p = ((parseFloat(input.value) - min) / (max - min)) * 100;
  input.style.setProperty('--p', `${Math.max(0, Math.min(100, p))}%`);
}

export function installRangeFill(root = document) {
  root.addEventListener('input', (e) => {
    if (e.target.matches && e.target.matches('input[type=range]')) syncRange(e.target);
  });
}

/** Fallback cover art: generative gradient disc/wave on a canvas -> data URL, cached. */
const coverCache = new Map();
export function generatedCover(seedText, size = 320, fixedHue = null) {
  const key = `${seedText}|${size}|${fixedHue}`;
  if (coverCache.has(key)) return coverCache.get(key);
  let h = 2166136261;
  for (const ch of String(seedText)) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  const rnd = () => {
    h ^= h << 13;
    h ^= h >>> 17;
    h ^= h << 5;
    return ((h >>> 0) % 10000) / 10000;
  };
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  // pleasant hue families only (no muddy olive/brown)
  const families = [265, 285, 320, 200, 185, 340, 230, 15];
  const hue = fixedHue ?? families[Math.floor(rnd() * families.length)] + Math.floor(rnd() * 20 - 10);
  const hue2 = (hue + 50 + rnd() * 80) % 360;
  const grad = g.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, `hsl(${hue} 82% 58%)`);
  grad.addColorStop(1, `hsl(${hue2} 80% 36%)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, size, size);
  for (let i = 0; i < 5; i++) {
    const rg = g.createRadialGradient(rnd() * size, rnd() * size, 0, rnd() * size, rnd() * size, size * (0.3 + rnd() * 0.5));
    rg.addColorStop(0, `hsla(${(hue + rnd() * 90) % 360} 95% 70% / .55)`);
    rg.addColorStop(1, 'hsla(0 0% 0% / 0)');
    g.fillStyle = rg;
    g.fillRect(0, 0, size, size);
  }
  g.globalAlpha = 0.5;
  g.strokeStyle = 'rgba(255,255,255,.65)';
  g.lineWidth = size / 160;
  for (let k = 0; k < 7; k++) {
    g.beginPath();
    const amp = size * (0.03 + rnd() * 0.08);
    const y0 = size * (0.3 + k * 0.07);
    for (let x = 0; x <= size; x += 4) {
      const y = y0 + Math.sin(x / (size / (3 + k)) + k) * amp;
      x ? g.lineTo(x, y) : g.moveTo(x, y);
    }
    g.stroke();
  }
  const url = c.toDataURL('image/jpeg', 0.85);
  coverCache.set(key, url);
  return url;
}
