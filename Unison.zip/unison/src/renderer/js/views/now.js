// Now Playing: 3D sleeve + spinning record + radial spectrum, big transport, live speaker chips.
import { html, raw, $, $$, esc, syncRange, generatedCover, fmtMs, lvl } from '../ui/dom.js';
import { icons, kindIcon } from '../ui/icons.js';
import { RadialSpectrum } from '../ui/spectrum.js';

let spectrum = null;
let offs = [];
let upNextKey = null;

export function mount(el, ctx) {
  el.innerHTML = String(html`
    <div class="now" id="now">
      <div class="stage" id="stage">
        <div class="vinyl-wrap">
          <canvas class="ring" id="ring"></canvas>
          <div class="vinyl">
            <div class="grooves"></div>
            <img class="vinyl-label" id="vinyl-label" alt="" />
            <div class="spindle"></div>
          </div>
          <div class="vinyl-sheen"></div>
        </div>
        <div class="sleeve" data-tilt="16">
          <img class="sleeve-art" id="sleeve-art" alt="" />
          <div class="sleeve-gloss"></div>
          <div class="sleeve-edge"></div>
        </div>
        <div class="stage-floor"></div>
      </div>
      <div class="now-meta">
        <div class="source-chip" id="now-source"></div>
        <h1 class="now-title" id="now-title">Ready when you are</h1>
        <div class="now-sub" id="now-sub"></div>
        <div class="progress-row big">
          <span class="time" data-t="pos">0:00</span>
          <input type="range" class="range progress" min="0" max="1000" value="0" step="1" aria-label="Seek" />
          <span class="time" data-t="dur">0:00</span>
        </div>
        ${raw(ctx.transportHTML('lg'))}
        <div class="now-row">
          <div class="vol big">
            <button class="icon-btn" data-act="mute" title="Mute (M)">${raw(icons.volume)}</button>
            <input type="range" class="range volume" min="0" max="100" value="80" aria-label="Master volume" />
          </div>
        </div>
        <div class="playing-on">
          <div class="po-head"><span>Playing on</span><button class="link-btn" data-act="speakers">Manage ${raw(icons.external)}</button></div>
          <div class="chips" id="chips"></div>
        </div>
        <div class="up-next" id="up-next"></div>
        <div class="now-empty" id="now-empty"></div>
      </div>
    </div>`);
  ctx.bindTransport(el);
  spectrum = new RadialSpectrum($('#ring', el));
  spectrum.setPalette(ctx.palette);
  el.querySelector('[data-act=speakers]').onclick = () => ctx.navigate('speakers');
  offs = [
    ctx.on('speakers', () => renderChips(ctx)),
    ctx.on('speakers-tweak', () => renderChips(ctx)),
    ctx.on('palette', (p) => spectrum && spectrum.setPalette(p)),
    ctx.on('library', () => onNow(ctx, ctx.nowState())),
    ctx.on('capture', () => onNow(ctx, ctx.nowState())),
    ctx.on('spotify', () => onNow(ctx, ctx.nowState())),
  ];
  renderChips(ctx);
  upNextKey = null;
  onNow(ctx, ctx.nowState());
}

export function unmount() {
  offs.forEach((f) => f());
  offs = [];
  spectrum = null;
}

export function onNow(ctx, st) {
  const root = $('#now');
  if (!root) return;
  root.classList.toggle('playing', !!st.playing);
  root.classList.toggle('empty', !st.active);
  const art = ctx.artUrl || generatedCover('unison-idle', 480);
  for (const id of ['sleeve-art', 'vinyl-label']) {
    const img = $(`#${id}`);
    if (img && img.getAttribute('src') !== art) img.src = art;
  }
  const src = ctx.SOURCES[ctx.source];
  const capture = ctx.source !== 'local' ? (ctx.capture.stream ? 'live · spreading to all speakers' : ctx.capture.error ? 'audio not captured' : 'connecting…') : st.active ? 'offline library' : '';
  $('#now-source').innerHTML = `<span class="src-ico">${src.icon}</span><span>${esc(st.app && st.app !== src.label ? `${src.label} · ${st.app}` : src.label)}</span>${
    capture ? `<span class="sep"></span><span class="muted">${esc(capture)}</span>` : ''
  }`;
  $('#now-title').textContent = st.active ? st.title : idleTitle(ctx);
  $('#now-sub').innerHTML = st.active
    ? `<span>${esc(st.artist)}</span>${st.album ? `<span class="dotsep"></span><span class="muted">${esc(st.album)}</span>` : ''}`
    : `<span class="muted">${esc(idleSub(ctx))}</span>`;
  renderEmpty(ctx, st);
  renderUpNext(ctx, st);
}

function idleTitle(ctx) {
  if (ctx.source === 'spotify') return ctx.spotify.status.connected || ctx.isWin ? 'Waiting for Spotify' : 'Connect Spotify';
  if (ctx.source === 'apple') return 'Waiting for Apple Music';
  if (ctx.source === 'system') return 'Listening to this computer';
  return 'Ready when you are';
}

function idleSub(ctx) {
  if (ctx.source === 'spotify') return 'Start a song in Spotify or search for one here — Unison plays it on every speaker.';
  if (ctx.source === 'apple') return ctx.isMac ? 'Start a song in the Music app or pick one from the Apple Music tab.' : 'Start a song in the Apple Music app — Unison picks it up automatically.';
  if (ctx.source === 'system') return 'Anything this computer plays — YouTube, games, calls — goes to every speaker.';
  return 'Play a song from your library, the built-in test tune, or switch source above.';
}

function renderEmpty(ctx, st) {
  const el = $('#now-empty');
  if (!el) return;
  if (st.active) {
    el.innerHTML = '';
    return;
  }
  const btn = [];
  if (ctx.source === 'local') {
    btn.push(`<button class="btn btn-primary" data-e="tune">${icons.play}<span>Play test tune</span></button>`);
    if (ctx.library.tracks.length) btn.push(`<button class="btn" data-e="all">${icons.shuffle}<span>Shuffle my music</span></button>`);
    else btn.push(`<button class="btn" data-e="folder">${icons.folder}<span>Add a music folder</span></button>`);
  } else if (ctx.source === 'spotify') {
    btn.push(`<button class="btn btn-primary" data-e="spotify">${icons.search}<span>${ctx.spotify.status.connected ? 'Find something to play' : 'Connect Spotify'}</span></button>`);
    btn.push(`<button class="btn" data-e="open-spotify">${icons.external}<span>Open Spotify app</span></button>`);
  } else if (ctx.source === 'apple') {
    btn.push(`<button class="btn btn-primary" data-e="apple">${icons.apple}<span>Browse Apple Music</span></button>`);
  }
  if (ctx.capture.error && ctx.source !== 'local') btn.push(`<button class="btn btn-warn" data-e="fix">${icons.alert}<span>Fix audio capture</span></button>`);
  if (!ctx.engine.speakers.size) btn.push(`<button class="btn" data-e="speakers">${icons.speakers}<span>Add speakers</span></button>`);
  el.innerHTML = btn.join('');
  el.onclick = (e) => {
    const b = e.target.closest('[data-e]');
    if (!b) return;
    const a = b.dataset.e;
    if (a === 'tune') ctx.playTestTune();
    else if (a === 'all') {
      ctx.local.shuffle = true;
      ctx.playLocal(ctx.library.tracks, Math.floor(Math.random() * ctx.library.tracks.length));
    } else if (a === 'folder') ctx.navigate('library');
    else if (a === 'spotify') ctx.navigate('spotify');
    else if (a === 'open-spotify') ctx.bridge.shell.open('spotify:');
    else if (a === 'apple') ctx.navigate('apple');
    else if (a === 'fix') ctx.navigate('settings');
    else if (a === 'speakers') ctx.navigate('speakers');
  };
}

async function renderUpNext(ctx, st) {
  const el = $('#up-next');
  if (!el) return;
  let items = [];
  if (ctx.source === 'local' && st.active) {
    items = ctx.local.upNext(3).map((t) => ({ title: t.title, artist: t.artist, art: ctx.coverUrl(t, 96) }));
  } else if (ctx.source === 'spotify' && st.active && ctx.spotify.status.connected) {
    const key = st.uri;
    if (key !== upNextKey) {
      upNextKey = key;
      const q = await ctx.spotify.queue().catch(() => []);
      ctx._spQueue = q.slice(0, 3).map((t) => ({
        title: t.name,
        artist: t.artists ? t.artists.map((a) => a.name).join(', ') : '',
        artUrl: t.album && t.album.images && t.album.images.length ? t.album.images[t.album.images.length - 1].url : null,
      }));
      for (const it of ctx._spQueue) if (it.artUrl) it.art = await ctx.bridge.art.fetch(it.artUrl);
    }
    items = ctx._spQueue || [];
  }
  if (!$('#up-next')) return;
  el.innerHTML = items.length
    ? `<div class="po-head"><span>Up next</span></div><div class="un-list">${items
        .map(
          (t) =>
            `<div class="un-item"><img src="${esc(t.art || generatedCover(t.title, 96))}" alt=""/><div><div class="un-t">${esc(t.title)}</div><div class="un-a">${esc(
              t.artist
            )}</div></div></div>`
        )
        .join('')}</div>`
    : '';
}

function renderChips(ctx) {
  const el = $('#chips');
  if (!el) return;
  const list = ctx.speakers.list().filter((s) => s.active || s.wanted);
  if (!list.length) {
    el.innerHTML = `<button class="chip add" data-add>${icons.plus}<span>Add speakers</span></button>`;
    el.querySelector('[data-add]').onclick = () => ctx.navigate('speakers');
    return;
  }
  el.innerHTML = list
    .map((s) => {
      const d = (s.delay || 0) + (s.trim || 0);
      return `<button class="chip ${s.active ? '' : 'off'} ${s.enabled ? '' : 'muted'}" data-key="${esc(s.key)}" title="${esc(
        s.active ? (s.enabled ? 'Click to mute this speaker' : 'Click to unmute') : 'Not connected'
      )}"><span class="chip-lvl"></span><span class="chip-ico">${kindIcon(s.kind)}</span><span class="chip-name">${esc(s.name)}</span>${
        s.active && d > 0.0005 ? `<span class="chip-ms">+${fmtMs(d)}</span>` : ''
      }${s.channel !== 'stereo' ? `<span class="chip-ch">${s.channel[0].toUpperCase()}</span>` : ''}</button>`;
    })
    .join('');
  $$('.chip[data-key]', el).forEach(
    (b) =>
      (b.onclick = () => {
        const s = list.find((x) => x.key === b.dataset.key);
        if (s && s.active) ctx.speakers.set(s.key, { enabled: !s.enabled });
      })
  );
}

export function tick(ctx, f) {
  if (spectrum) spectrum.draw(f.bins, f.energy, f.beat);
  const chips = document.querySelectorAll('#chips .chip[data-key]');
  for (const c of chips) {
    const sp = ctx.engine.speakers.get(c.dataset.key);
    c.style.setProperty('--lvl', sp ? lvl(sp.level.rms).toFixed(3) : 0);
  }
  const vol = document.querySelector('#now input.volume');
  if (vol && !vol.dataset.synced) {
    vol.dataset.synced = '1';
    syncRange(vol);
  }
}
