// Speakers: build the party, per-speaker controls, latency engine panel, calibration & sync test.
import { html, raw, $, $$, esc, toast, modal, fmtMs, timeAgo, syncRange, lvl } from '../ui/dom.js';
import { icons, kindIcon } from '../ui/icons.js';
import { KIND_LABEL, pickCalibrationMic } from '../audio/devices.js';
import { LATENCY_MODES } from '../audio/engine.js';
import { makeChime, makeClicks } from '../audio/dsp.js';
import { openMic, calibrate, verifySync } from '../audio/calibrate.js';

let offs = [];
let lastStats = 0;

export function mount(el, ctx) {
  el.innerHTML = String(html`
    <div class="page-head">
      <div>
        <h1>Speakers</h1>
        <p class="lead">Pair speakers in your Bluetooth settings, add them here, then calibrate once — Unison lines them up to the millisecond.</p>
      </div>
      <div class="head-actions">
        <button class="btn btn-primary btn-glow" data-a="calibrate">${raw(icons.target)}<span>Calibrate sync</span></button>
        <button class="btn" data-a="synctest">${raw(icons.wave)}<span>Sync test</span></button>
        <button class="btn" data-a="bt">${raw(icons.bluetooth)}<span>Bluetooth settings</span></button>
        <button class="icon-btn" data-a="refresh" title="Refresh devices">${raw(icons.refresh)}</button>
      </div>
    </div>
    <div class="banners" id="spk-banners"></div>
    <div class="engine-panel glass" id="engine-panel"></div>
    <h2 class="section-title"><span>In the party</span><small id="party-count"></small></h2>
    <div class="spk-grid" id="spk-active"></div>
    <h2 class="section-title"><span>Available outputs</span><small>Everything connected to this computer</small></h2>
    <div class="spk-grid compact" id="spk-avail"></div>
  `);
  el.addEventListener('click', (e) => onClick(e, ctx));
  el.addEventListener('input', (e) => onInput(e, ctx));
  el.addEventListener('change', (e) => onChange(e, ctx));
  offs = [ctx.on('speakers', () => render(ctx)), ctx.on('engine', () => renderEngine(ctx)), ctx.on('capture', () => renderBanners(ctx)), ctx.on('settings', () => renderEngine(ctx))];
  render(ctx);
}

export function unmount() {
  offs.forEach((f) => f());
  offs = [];
}

function render(ctx) {
  renderBanners(ctx);
  renderEngine(ctx);
  const list = ctx.speakers.list();
  const party = list.filter((s) => s.active || s.wanted);
  const avail = list.filter((s) => !s.active && !s.wanted);
  $('#party-count').textContent = party.length ? `${party.filter((s) => s.active).length} playing` : '';
  $('#spk-active').innerHTML = party.length
    ? party.map((s) => partyCard(ctx, s)).join('')
    : `<div class="empty-card glass-lite"><div class="empty-orbit"><span></span><span></span><span></span></div><b>No speakers in the party yet</b><p>Turn your speakers on, pair them in Bluetooth settings, then press <em>Add</em> below.</p></div>`;
  $('#spk-avail').innerHTML = avail.length ? avail.map((s) => availCard(ctx, s)).join('') : `<p class="muted pad">All connected outputs are already in the party.</p>`;
  $$('#spk-active input[type=range]').forEach(syncRange);
}

function warningsFor(ctx, s) {
  const w = [];
  if (s.handsFree) w.push(['warn', 'Hands-free (call) mode: mono and low quality. Use the “Stereo” entry of this speaker instead.']);
  if (s.isDefault && ctx.isWin && ctx.source !== 'local' && ctx.settings.captureMode !== 'device' && s.active)
    w.push(['bad', 'This is the Windows default output. It is muted while Unison captures system audio — set your laptop speakers as default.']);
  if (s.status && s.status.state === 'error') w.push(['bad', s.status.error]);
  return w;
}

function partyCard(ctx, s) {
  const on = s.active;
  const eff = (s.delay || 0) + (s.trim || 0);
  const w = warningsFor(ctx, s);
  return `<article class="spk-card tile ${on ? '' : 'offline'} ${s.enabled ? '' : 'is-muted'}" data-key="${esc(s.key)}" data-tilt="5">
    <header>
      <span class="kind-ico k-${s.kind}">${kindIcon(s.kind)}</span>
      <div class="spk-names"><b>${esc(s.name)}</b><small title="${esc(s.detail || '')}">${esc(on ? KIND_LABEL[s.kind] || '' : s.status && s.status.state === 'disconnected' ? 'Not connected' : s.status ? s.status.state : '')}</small></div>
      <label class="switch" title="${on ? 'Remove from party' : 'Add to party'}"><input type="checkbox" data-f="active" ${s.wanted ? 'checked' : ''}/><span></span></label>
    </header>
    <div class="spk-body">
      <div class="meter-ring" style="--lvl:0">
        <svg viewBox="0 0 100 100"><circle class="mr-bg" cx="50" cy="50" r="42"/><circle class="mr-fg" cx="50" cy="50" r="42"/></svg>
        <div class="mr-center"><b>${on ? (eff > 0.0004 ? `+${(eff * 1000).toFixed(1)}` : '0') : '—'}</b><small>ms delay</small></div>
      </div>
      <div class="spk-controls">
        <label class="ctl"><span>Volume <em data-o="volume">${Math.round((s.volume ?? 1) * 100)}%</em></span><input type="range" class="range" data-f="volume" min="0" max="150" value="${Math.round((s.volume ?? 1) * 100)}" ${on ? '' : 'disabled'}/></label>
        <div class="ctl"><span>Channel</span><div class="seg sm" data-f="channel">${['left', 'stereo', 'right', 'mono']
          .map((c) => `<button data-v="${c}" class="${s.channel === c ? 'active' : ''}" ${on ? '' : 'disabled'}>${{ left: 'L', stereo: 'Stereo', right: 'R', mono: 'Mono' }[c]}</button>`)
          .join('')}</div></div>
        <label class="ctl"><span>Fine-tune <em data-o="trim">${s.trim >= 0 ? '+' : ''}${Math.round((s.trim || 0) * 1000)} ms</em></span><input type="range" class="range center" data-f="trim" min="-80" max="80" step="1" value="${Math.round((s.trim || 0) * 1000)}" ${on ? '' : 'disabled'}/></label>
      </div>
    </div>
    <footer>
      <button class="btn btn-sm" data-a="identify" ${on ? '' : 'disabled'}>${icons.bell}<span>Identify</span></button>
      <button class="btn btn-sm ${ctx.engine.soloId === s.key ? 'on' : ''}" data-a="solo" ${on ? '' : 'disabled'}>${icons.headphones}<span>Solo</span></button>
      <button class="btn btn-sm ${s.enabled ? '' : 'on'}" data-a="mute" ${on ? '' : 'disabled'}>${s.enabled ? icons.volume : icons.mute}<span>${s.enabled ? 'Mute' : 'Muted'}</span></button>
      <span class="spk-stats" data-stats>${on ? '' : s.status && s.status.state === 'disconnected' ? 'waiting for device…' : ''}</span>
      ${on ? '' : `<button class="btn btn-sm btn-ghost" data-a="forget">${icons.x}<span>Forget</span></button>`}
    </footer>
    ${w.map(([k, m]) => `<div class="card-warn ${k}">${icons.alert}<span>${esc(m)}</span></div>`).join('')}
  </article>`;
}

function availCard(ctx, s) {
  const w = warningsFor(ctx, s);
  return `<article class="spk-card tile small" data-key="${esc(s.key)}">
    <header>
      <span class="kind-ico k-${s.kind}">${kindIcon(s.kind)}</span>
      <div class="spk-names"><b>${esc(s.name)}</b><small title="${esc(s.detail || '')}">${esc(KIND_LABEL[s.kind] || '')}${s.isDefault ? ' · system default' : ''}</small></div>
      <button class="btn btn-sm ${s.handsFree ? 'btn-ghost' : 'btn-primary'}" data-a="add">${icons.plus}<span>Add</span></button>
    </header>
    ${w.map(([k, m]) => `<div class="card-warn ${k}">${icons.alert}<span>${esc(m)}</span></div>`).join('')}
  </article>`;
}

function renderBanners(ctx) {
  const el = $('#spk-banners');
  if (!el) return;
  const b = [];
  const devs = ctx.speakers.devices;
  if (devs.labelsHidden) b.push(['warn', 'Device names are hidden until Unison may use the microphone. Allow it to see your speakers by name.']);
  if (ctx.engine.mode !== 'precision') b.push(['info', 'Running the Compatibility engine. Switch to Precision in Settings for tighter sync and automatic drift correction.']);
  const bt = ctx.speakers.list().filter((s) => s.active && s.kind === 'bluetooth').length;
  if (bt >= 4) b.push(['info', `${bt} Bluetooth speakers on one adapter can stutter. If audio breaks up, move the laptop closer or add a second USB Bluetooth adapter.`]);
  if (!ctx.settings.calibration && ctx.engine.speakers.size > 1) b.push(['accent', 'Your speakers are not calibrated yet — press “Calibrate sync” so they stop echoing each other.']);
  el.innerHTML = b.map(([k, m]) => `<div class="banner ${k}">${k === 'info' || k === 'accent' ? icons.info : icons.alert}<span>${esc(m)}</span></div>`).join('');
}

function renderEngine(ctx) {
  const el = $('#engine-panel');
  if (!el) return;
  const e = ctx.engine;
  const cal = ctx.settings.calibration;
  const precision = e.mode === 'precision';
  el.innerHTML = `
    <div class="ep-stat"><label>Engine</label><b>${precision ? 'Precision' : 'Compatibility'}</b><small>${precision ? 'drift-corrected ring buffer' : 'stream fan-out'}</small></div>
    <div class="ep-stat"><label>Added buffer</label><b data-live="base">${precision ? fmtMs(e.base) : '—'}</b><small>${precision ? 'auto-tuned to your devices' : ''}</small></div>
    <div class="ep-stat"><label>Source → ears</label><b data-live="heard">~${fmtMs(e.heardLatency())}</b><small>${cal ? 'measured' : 'estimate'}</small></div>
    <div class="ep-stat"><label>Sync</label><b>${cal ? (cal.verify != null ? `±${(cal.verify * 1000).toFixed(1)} ms` : 'Calibrated') : 'Not calibrated'}</b><small>${cal ? timeAgo(cal.at) : 'press Calibrate'}</small></div>
    <div class="ep-latency"><label>Latency mode</label><div class="seg" data-f="latency">${Object.entries(LATENCY_MODES)
      .map(([k, v]) => `<button data-v="${k}" class="${e.latencyMode === k ? 'active' : ''}" ${precision ? '' : 'disabled'}>${v.label}</button>`)
      .join('')}</div><small>${
    { ultra: 'Smallest buffer. Best for video; may crackle on busy PCs.', auto: 'Smallest buffer that stays glitch-free (recommended).', balanced: 'A little extra headroom.', safe: 'Maximum stability for weak Bluetooth links.' }[e.latencyMode]
  }</small></div>`;
}

function keyOf(e) {
  const card = e.target.closest('[data-key]');
  return card ? card.dataset.key : null;
}

async function onClick(e, ctx) {
  const a = e.target.closest('[data-a]');
  const segBtn = e.target.closest('.seg [data-v]');
  if (segBtn && !segBtn.disabled) {
    const seg = segBtn.closest('.seg');
    if (seg.dataset.f === 'channel') {
      ctx.speakers.set(keyOf(e), { channel: segBtn.dataset.v });
      $$('button', seg).forEach((b) => b.classList.toggle('active', b === segBtn));
    } else if (seg.dataset.f === 'latency') {
      ctx.engine.setLatencyMode(segBtn.dataset.v);
      ctx.saveSettings({ latencyMode: segBtn.dataset.v });
      renderEngine(ctx);
    }
    return;
  }
  if (!a) return;
  const key = keyOf(e);
  switch (a.dataset.a) {
    case 'calibrate':
      openCalibration(ctx);
      break;
    case 'synctest':
      syncTest(ctx);
      break;
    case 'bt':
      if (!(await ctx.bridge.shell.settings('bluetooth'))) toast('Open your system Bluetooth settings to pair speakers.');
      break;
    case 'refresh':
      await ctx.speakers.refresh();
      toast('Device list refreshed', { kind: 'ok', timeout: 1500 });
      break;
    case 'add': {
      const s = ctx.speakers.list().find((x) => x.key === key);
      if (s && s.handsFree && !confirmHandsFree()) return;
      await ctx.speakers.activate(key);
      const st = ctx.speakers.status.get(key);
      if (st && st.state === 'error') toast(`Could not open ${s ? s.name : 'speaker'}: ${st.error}`, { kind: 'error' });
      else toast(`${s ? s.name : 'Speaker'} joined the party`, { kind: 'ok', timeout: 2000 });
      break;
    }
    case 'identify':
      identify(ctx, key);
      break;
    case 'solo':
      ctx.engine.solo(ctx.engine.soloId === key ? null : key);
      render(ctx);
      break;
    case 'mute': {
      const s = ctx.speakers.config[key] || {};
      ctx.speakers.set(key, { enabled: s.enabled === false });
      render(ctx);
      break;
    }
    case 'forget':
      ctx.speakers.forget(key);
      break;
    default:
  }
}

function confirmHandsFree() {
  toast('That is the hands-free (phone call) profile — sound will be mono and muffled. Add the “Stereo” entry instead.', { kind: 'warn', timeout: 8000 });
  return false;
}

function onInput(e, ctx) {
  const f = e.target.dataset.f;
  const key = keyOf(e);
  if (!f || !key) return;
  const card = e.target.closest('.spk-card');
  if (f === 'volume') {
    const v = e.target.value / 100;
    ctx.speakers.engine.setSpeaker(key, { volume: v });
    card.querySelector('[data-o=volume]').textContent = `${e.target.value}%`;
  } else if (f === 'trim') {
    const v = e.target.value / 1000;
    ctx.speakers.engine.setSpeaker(key, { trim: v });
    card.querySelector('[data-o=trim]').textContent = `${v >= 0 ? '+' : ''}${e.target.value} ms`;
    const cfg = ctx.speakers.config[key] || {};
    const eff = (cfg.delay || 0) + v;
    card.querySelector('.mr-center b').textContent = eff > 0.0004 ? `+${(eff * 1000).toFixed(1)}` : '0';
  }
}

function onChange(e, ctx) {
  const f = e.target.dataset.f;
  const key = keyOf(e);
  if (!f || !key) return;
  if (f === 'active') {
    if (e.target.checked) ctx.speakers.activate(key);
    else ctx.speakers.deactivate(key);
  } else if (f === 'volume') ctx.speakers.set(key, { volume: e.target.value / 100 });
  else if (f === 'trim') ctx.speakers.set(key, { trim: e.target.value / 1000 });
}

export function tick(ctx, f, now) {
  const cards = document.querySelectorAll('#spk-active .spk-card[data-key]');
  const doStats = now - lastStats > 600;
  if (doStats) lastStats = now;
  for (const c of cards) {
    const sp = ctx.engine.speakers.get(c.dataset.key);
    if (!sp) continue;
    c.querySelector('.meter-ring').style.setProperty('--lvl', lvl(sp.level.rms).toFixed(3));
    if (doStats) {
      const st = c.querySelector('[data-stats]');
      const out = sp.reportedLatency();
      const drift = sp.fit && ctx.engine.masterFit ? sp.fit.ppm() - ctx.engine.masterFit.ppm() : null;
      const parts = [`out ${fmtMs(out)}`];
      if (drift != null && ctx.engine.mode === 'precision') parts.push(Math.abs(drift) < 300 ? `drift ${drift >= 0 ? '+' : ''}${drift.toFixed(0)} ppm` : 'tracking clock…');
      if (sp.stats && sp.stats.under) parts.push('⚠ dropout');
      st.textContent = parts.join(' · ');
    }
  }
  if (doStats) {
    const b = document.querySelector('[data-live=base]');
    if (b && ctx.engine.mode === 'precision') b.textContent = fmtMs(ctx.engine.base);
    const h = document.querySelector('[data-live=heard]');
    if (h) h.textContent = `~${fmtMs(ctx.engine.heardLatency())}`;
  }
}

// ------------------------------------------------------------------------------------ actions
export function identify(ctx, key) {
  const e = ctx.engine;
  const prev = e.soloId;
  e.solo(key);
  e.playFx(makeChime(e.sampleRate), { gain: 0.8 });
  setTimeout(() => e.solo(prev === key ? key : prev), 1100);
}

export function syncTest(ctx) {
  const e = ctx.engine;
  if (!e.speakers.size) {
    toast('Add a speaker first.', { kind: 'warn' });
    return;
  }
  e.setProgramMuted(true);
  e.playFx(makeClicks(e.sampleRate, 8, 0.5), { gain: 0.9 });
  toast('Listen: each tick should sound like ONE crisp click. A “flam” or echo means a speaker needs calibration or fine-tuning.', { timeout: 6500 });
  setTimeout(() => e.setProgramMuted(false), 4400);
}

let calOpen = false;
export async function openCalibration(ctx) {
  if (calOpen) return;
  const e = ctx.engine;
  const keys = [...e.speakers.keys()].filter((k) => (ctx.speakers.config[k] || {}).enabled !== false);
  if (!keys.length) {
    toast('Add at least one speaker to the party first.', { kind: 'warn' });
    ctx.navigate('speakers');
    return;
  }
  calOpen = true;
  const names = Object.fromEntries(ctx.speakers.list().map((s) => [s.key, s.name]));
  const inputs = ctx.speakers.devices.inputs;
  const mic = pickCalibrationMic(inputs, ctx.settings.micLabel);
  const body = document.createElement('div');
  body.className = 'cal';
  body.innerHTML = `
    <div class="cal-intro">
      <div class="cal-visual"><span class="cv-ring r1"></span><span class="cv-ring r2"></span><span class="cv-ring r3"></span><span class="cv-mic">${icons.mic}</span></div>
      <ol class="steps">
        <li><b>Put this computer where people will listen</b> — the middle of the room is ideal.</li>
        <li><b>Set every speaker to a normal volume</b> and keep the room fairly quiet for a few seconds.</li>
        <li>Unison plays a short chirp on each speaker and measures when it arrives. About ${Math.ceil(keys.length * 3.6 + 2)} seconds.</li>
      </ol>
    </div>
    <div class="cal-mic">
      <label>Microphone</label>
      <select class="select" id="cal-mic">${inputs.map((d) => `<option value="${esc(d.id)}" ${mic && d.id === mic.id ? 'selected' : ''}>${esc(d.label || 'Microphone')}</option>`).join('')}${
    inputs.length ? '' : '<option value="">Default microphone</option>'
  }</select>
      <div class="mic-meter"><span id="cal-mic-lvl"></span></div>
    </div>
    <div class="cal-rows" id="cal-rows">${keys
      .map((k) => `<div class="cal-row" data-k="${esc(k)}"><span class="cal-dot"></span><b>${esc(names[k] || k)}</b><span class="cal-res muted">waiting</span></div>`)
      .join('')}</div>
    <div class="cal-summary" id="cal-summary"></div>
    <div class="modal-actions"><button class="btn" data-c="cancel">Close</button><button class="btn btn-primary btn-glow" data-c="start">${icons.target}<span>Start calibration</span></button></div>`;
  let stream = null;
  let running = false;
  let stop = false;
  let meterRaf = 0;
  const m = modal({
    title: 'Sync calibration',
    body,
    className: 'modal-cal',
    onClose: () => {
      stop = true;
      calOpen = false;
      cancelAnimationFrame(meterRaf);
      e.disconnectMic();
    },
  });
  const lvl = body.querySelector('#cal-mic-lvl');
  const meter = () => {
    lvl.style.width = `${Math.min(100, Math.sqrt(e.micLevel) * 260)}%`;
    meterRaf = requestAnimationFrame(meter);
  };
  const connect = async () => {
    try {
      await ctx.bridge.mic.ask();
      e.disconnectMic();
      stream = await openMic(body.querySelector('#cal-mic').value || undefined);
      e.connectMic(stream);
      cancelAnimationFrame(meterRaf);
      meter();
    } catch (err) {
      body.querySelector('#cal-summary').innerHTML = `<div class="banner bad">${icons.alert}<span>Microphone unavailable: ${esc(err.message || err.name)}. ${
        ctx.isMac ? 'Allow Unison in System Settings → Privacy & Security → Microphone.' : 'Turn on microphone access for desktop apps in Windows Settings → Privacy → Microphone.'
      }</span></div>`;
    }
  };
  body.querySelector('#cal-mic').onchange = (ev) => {
    const d = inputs.find((x) => x.id === ev.target.value);
    if (d) ctx.saveSettings({ micLabel: d.label });
    connect();
  };
  connect();
  body.querySelector('[data-c=cancel]').onclick = () => m.close();
  const startBtn = body.querySelector('[data-c=start]');
  startBtn.onclick = async () => {
    if (running) return;
    if (!stream) await connect();
    if (!stream) return;
    running = true;
    stop = false;
    startBtn.disabled = true;
    startBtn.querySelector('span').textContent = 'Measuring…';
    body.classList.add('running');
    $$('.cal-row', body).forEach((r) => {
      r.className = 'cal-row';
      r.querySelector('.cal-res').textContent = 'waiting';
    });
    body.querySelector('#cal-summary').innerHTML = '';
    try {
      const summary = await calibrate(e, keys, {
        micStream: stream,
        shouldStop: () => stop,
        onProgress: (p) => {
          const row = body.querySelector(`.cal-row[data-k="${CSS.escape(p.id)}"]`);
          if (!row) return;
          if (p.phase === 'measure') {
            row.className = 'cal-row measuring';
            row.querySelector('.cal-res').textContent = 'listening…';
          } else if (p.phase === 'result') {
            const r = p.result;
            row.className = `cal-row ${r.ok ? 'ok' : 'fail'}`;
            row.querySelector('.cal-res').innerHTML = r.ok
              ? `<span>${(r.latency * 1000).toFixed(1)} ms</span><small>signal ${Math.round(Math.min(99, r.snr))}×</small>`
              : `<span>${esc({ silent: 'not heard — turn it up / check it is on', noisy: 'too noisy — quieter room or louder speaker', unstable: 'unstable — Bluetooth link glitching', 'no-mic': 'no microphone input' }[r.reason] || 'failed')}</span>`;
          }
        },
      });
      e.endCalibration();
      const okKeys = Object.keys(summary.delays);
      if (!okKeys.length) {
        body.querySelector('#cal-summary').innerHTML = `<div class="banner bad">${icons.alert}<span>No speaker was heard clearly. Raise the speaker volume, move the computer closer and try again.</span></div>`;
      } else {
        ctx.speakers.applyCalibration(summary);
        await new Promise((r) => setTimeout(r, 900));
        let verify = null;
        if (okKeys.length > 1 && !stop) {
          body.querySelector('#cal-summary').innerHTML = `<div class="banner info">${icons.sync}<span>Checking the result…</span></div>`;
          verify = await verifySync(e, { micStream: stream });
        }
        const residual = verify ? (verify.secondaryRatio < 0.25 ? 0.001 : Math.abs(verify.secondaryOffset)) : null;
        const calRec = { at: summary.at, lmax: summary.lmax, base: summary.base, spreadBefore: summary.spreadBefore, verify: residual, count: okKeys.length };
        await ctx.saveSettings({ calibration: calRec });
        const failed = keys.length - okKeys.length;
        body.querySelector('#cal-summary').innerHTML = `<div class="cal-result">
          <div class="cr-big"><span class="cr-before">${(summary.spreadBefore * 1000).toFixed(0)} ms</span><span class="cr-arrow">→</span><span class="cr-after">${
          residual == null ? 'aligned' : residual <= 0.002 ? '≤ 1 ms' : `${(residual * 1000).toFixed(0)} ms`
        }</span></div>
          <p>${okKeys.length > 1 ? `Your speakers were up to <b>${(summary.spreadBefore * 1000).toFixed(0)} ms</b> apart. They now play together${residual != null && residual > 0.004 ? ' — run it once more for a tighter result' : ''}.` : 'Latency measured. Add more speakers to sync them together.'}${
          failed ? ` ${failed} speaker${failed > 1 ? 's were' : ' was'} not heard and kept the old setting.` : ''
        }</p></div>`;
        ctx.emit('speakers');
      }
    } catch (err) {
      e.endCalibration();
      if (err.message !== 'cancelled') body.querySelector('#cal-summary').innerHTML = `<div class="banner bad">${icons.alert}<span>${esc(err.message)}</span></div>`;
    } finally {
      running = false;
      body.classList.remove('running');
      startBtn.disabled = false;
      startBtn.querySelector('span').textContent = 'Calibrate again';
    }
  };
}
