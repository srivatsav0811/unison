// Spotify: connect (PKCE, your own free developer app), search, playlists, liked songs, devices.
import { html, raw, $, $$, esc, toast, fmtTime, debounce, generatedCover } from '../ui/dom.js';
import { icons } from '../ui/icons.js';

let offs = [];
let connecting = false;
let lastQuery = '';
let cache = { playlists: null, liked: null, recent: null, results: null };

export function mount(el, ctx) {
  el.innerHTML = `<div id="sp-root"></div>`;
  offs = [ctx.on('spotify', () => render(ctx)), ctx.on('online', () => render(ctx))];
  el.addEventListener('click', (e) => onClick(e, ctx));
  render(ctx);
}

export function unmount() {
  offs.forEach((f) => f());
  offs = [];
}

function render(ctx) {
  const root = $('#sp-root');
  if (!root) return;
  const st = ctx.spotify.status;
  if (!ctx.isDesktop) {
    root.innerHTML = head(ctx) + `<div class="glass panel pad-lg"><p>Spotify control needs the Unison desktop app (it signs in through your browser and talks to the Spotify app on your computer).</p></div>`;
    return;
  }
  if (!st.connected) {
    root.innerHTML = head(ctx) + setupCard(ctx);
    const inp = $('#sp-client');
    if (inp) inp.value = st.clientId || '';
    return;
  }
  root.innerHTML =
    head(ctx) +
    String(html`
      ${ctx.online ? '' : raw(`<div class="banner warn">${icons.wifiOff}<span>You're offline. Spotify needs the internet — your local Library still works.</span></div>`)}
      <div class="sp-top">
        <div class="search big"><span class="ico">${raw(icons.search)}</span><input type="search" id="sp-q" placeholder="What do you want to play?" value="${lastQuery}" /></div>
        <div class="sp-device glass-lite" id="sp-device"><span class="muted">Finding Spotify players…</span></div>
      </div>
      <div id="sp-results"></div>
      <div id="sp-home"></div>`);
  const q = $('#sp-q');
  q.addEventListener(
    'input',
    debounce(() => search(ctx, q.value), 350)
  );
  renderDevices(ctx);
  if (lastQuery) search(ctx, lastQuery);
  renderHome(ctx);
}

function head(ctx) {
  const st = ctx.spotify.status;
  const p = st.profile;
  return `<div class="page-head">
    <div><h1>Spotify</h1><p class="lead">${
      st.connected ? 'Search and pick songs here — the Spotify app on this computer plays them and Unison sends the sound to every speaker.' : 'Link your Spotify Premium account to search and control music from Unison.'
    }</p></div>
    <div class="head-actions">${
      st.connected
        ? `<span class="profile-chip glass-lite">${p && p.image ? `<img id="sp-avatar" alt=""/>` : `<span class="avatar">${esc((p && p.name ? p.name : 'S')[0])}</span>`}<span>${esc(
            p ? p.name : 'Connected'
          )}</span></span><button class="btn btn-ghost" data-a="disconnect">${icons.power}<span>Disconnect</span></button>`
        : ''
    }<button class="btn" data-a="open-app">${icons.external}<span>Open Spotify</span></button></div>
  </div>`;
}

function setupCard(ctx) {
  const st = ctx.spotify.status;
  return `<div class="setup glass">
    <div class="setup-steps">
      <h2>One-time setup <small>about 2 minutes</small></h2>
      <ol class="steps big">
        <li><b>Open the Spotify developer dashboard</b> and log in with your Premium account.<br/><button class="btn btn-sm" data-a="dashboard">${icons.external}<span>Open dashboard</span></button></li>
        <li><b>Create app.</b> Any name (e.g. “Unison”). As <em>Redirect URI</em> add exactly:
          <div class="copy-field"><code>${esc(st.redirectUri || 'http://127.0.0.1:43821/callback')}</code><button class="icon-btn sm" data-a="copy-uri" title="Copy">${icons.copy}</button></div>
          Tick <em>Web API</em>, accept the terms and save.</li>
        <li><b>Copy the Client ID</b> from the app's settings page and paste it here:
          <div class="row gap mt"><input class="input" id="sp-client" placeholder="Client ID (32 characters)" spellcheck="false" autocomplete="off"/>
          <button class="btn btn-primary btn-glow" data-a="connect" ${connecting ? 'disabled' : ''}>${icons.link}<span>${connecting ? 'Waiting for browser…' : 'Connect'}</span></button></div>
          ${connecting ? `<p class="muted small">Approve Unison in the browser tab that just opened. <button class="link-btn" data-a="cancel">Cancel</button></p>` : ''}
        </li>
      </ol>
    </div>
    <aside class="setup-aside glass-lite">
      <h3>${icons.info} How it works</h3>
      <p>The Spotify app on this computer does the streaming. Unison tells it what to play and captures its sound for your speakers.</p>
      <p>Your login stays on this computer — the token is encrypted by ${ctx.isMac ? 'macOS Keychain' : 'Windows'}; no password is ever seen by Unison.</p>
      <p class="muted small">Spotify limits personal developer apps to the owner plus up to 5 listed users (add them under <em>User Management</em>). That's plenty for your own party setup.</p>
      ${ctx.isWin ? `<p class="muted small">Even without connecting, choosing <b>Spotify</b> as the source gives you play/pause/skip through Windows media controls.</p>` : ''}
    </aside>
  </div>`;
}

async function renderDevices(ctx) {
  const el = $('#sp-device');
  if (!el) return;
  const list = await ctx.spotify.devices().catch(() => []);
  if (!$('#sp-device')) return;
  if (!list.length) {
    el.innerHTML = `<span class="warn-text">${icons.alert} No Spotify player running</span><button class="btn btn-sm" data-a="open-app">${icons.external}<span>Open Spotify</span></button><button class="icon-btn sm" data-a="devices" title="Refresh">${icons.refresh}</button>`;
    return;
  }
  const host = (ctx.info.hostname || '').toLowerCase();
  el.innerHTML = `<label>Plays on</label><select class="select sm" id="sp-dev">${list
    .map(
      (d) =>
        `<option value="${esc(d.id)}" ${d.is_active ? 'selected' : ''}>${esc(d.name)}${d.name.toLowerCase() === host ? ' (this computer)' : ''}${d.is_active ? ' • active' : ''}</option>`
    )
    .join('')}</select><button class="icon-btn sm" data-a="devices" title="Refresh">${icons.refresh}</button>`;
  const active = list.find((d) => d.is_active);
  if (active && active.name.toLowerCase() !== host && active.type !== 'Computer') {
    el.insertAdjacentHTML('beforeend', `<span class="warn-text small">Playing on another device — Unison can only spread sound played on this computer.</span>`);
  }
  $('#sp-dev').onchange = async (e) => {
    try {
      await ctx.spotify.transfer(e.target.value, true);
      toast('Playback moved', { kind: 'ok', timeout: 1500 });
    } catch (err) {
      toast(err.message, { kind: 'warn' });
    }
  };
}

async function fillArt(root, bridge) {
  const imgs = $$('img[data-art]', root);
  let i = 0;
  const worker = async () => {
    while (i < imgs.length) {
      const img = imgs[i++];
      const u = await bridge.art.fetch(img.dataset.art);
      if (u) img.src = u;
    }
  };
  await Promise.all([worker(), worker(), worker(), worker(), worker()]);
}

const imgOf = (images, small = false) => (images && images.length ? (small ? images[images.length - 1] : images[0]).url : '');

function trackRow(t, i, listId) {
  const art = imgOf(t.album && t.album.images, true);
  return `<div class="sp-track" data-list="${listId}" data-i="${i}">
    <span class="s-n"><span class="s-idx">${i + 1}</span><span class="s-play">${icons.play}</span></span>
    <img src="${esc(generatedCover(t.name, 64))}" ${art ? `data-art="${esc(art)}"` : ''} alt=""/>
    <span class="sp-t"><b>${esc(t.name)}</b><small>${esc((t.artists || []).map((a) => a.name).join(', '))}</small></span>
    <span class="sp-al">${esc(t.album ? t.album.name : '')}</span>
    <span class="s-dur">${fmtTime((t.duration_ms || 0) / 1000)}</span>
  </div>`;
}

function card(item, kind) {
  const art = imgOf(item.images);
  const sub = kind === 'playlist' ? (item.owner ? `By ${item.owner.display_name || item.owner.id}` : 'Playlist') : kind === 'album' ? (item.artists || []).map((a) => a.name).join(', ') : 'Artist';
  return `<button class="album-card tile ${kind === 'artist' ? 'round' : ''}" data-uri="${esc(item.uri)}" data-tilt="12">
    <span class="ac-art"><img src="${esc(generatedCover(item.name, 240))}" ${art ? `data-art="${esc(art)}"` : ''} alt=""/><span class="ac-gloss"></span><span class="ac-play">${icons.play}</span></span>
    <b>${esc(item.name)}</b><small>${esc(sub)}</small></button>`;
}

const lists = {};

async function search(ctx, q) {
  lastQuery = q;
  const box = $('#sp-results');
  const home = $('#sp-home');
  if (!box) return;
  if (!q.trim()) {
    box.innerHTML = '';
    if (home) home.style.display = '';
    return;
  }
  if (home) home.style.display = 'none';
  box.innerHTML = `<div class="loading-row"><span class="spinner"></span>Searching…</div>`;
  try {
    const r = await ctx.spotify.search(q);
    if (lastQuery !== q || !$('#sp-results')) return;
    const tracks = (r.tracks && r.tracks.items) || [];
    const pls = ((r.playlists && r.playlists.items) || []).filter(Boolean);
    const albums = ((r.albums && r.albums.items) || []).filter(Boolean);
    const artists = ((r.artists && r.artists.items) || []).filter(Boolean);
    lists.search = tracks;
    box.innerHTML = `
      ${tracks.length ? `<h2 class="section-title"><span>Songs</span></h2><div class="sp-list">${tracks.map((t, i) => trackRow(t, i, 'search')).join('')}</div>` : ''}
      ${artists.length ? `<h2 class="section-title"><span>Artists</span></h2><div class="album-grid sm">${artists.map((a) => card(a, 'artist')).join('')}</div>` : ''}
      ${albums.length ? `<h2 class="section-title"><span>Albums</span></h2><div class="album-grid sm">${albums.map((a) => card(a, 'album')).join('')}</div>` : ''}
      ${pls.length ? `<h2 class="section-title"><span>Playlists</span></h2><div class="album-grid sm">${pls.map((p) => card(p, 'playlist')).join('')}</div>` : ''}
      ${!tracks.length && !pls.length && !albums.length ? `<p class="muted pad">Nothing found for “${esc(q)}”.</p>` : ''}`;
    fillArt(box, ctx.bridge);
  } catch (err) {
    box.innerHTML = `<div class="banner warn">${icons.alert}<span>${esc(err.message)}</span></div>`;
  }
}

async function renderHome(ctx) {
  const el = $('#sp-home');
  if (!el) return;
  el.innerHTML = `<div class="loading-row"><span class="spinner"></span>Loading your music…</div>`;
  const [pl, liked, recent] = await Promise.all([
    cache.playlists || ctx.spotify.playlists().catch(() => []),
    cache.liked || ctx.spotify.liked().catch(() => []),
    cache.recent || ctx.spotify.recent().catch(() => []),
  ]);
  cache = { playlists: pl, liked, recent };
  setTimeout(() => (cache = { playlists: null, liked: null, recent: null }), 60000);
  if (!$('#sp-home')) return;
  lists.liked = liked;
  const seen = new Set();
  lists.recent = recent.filter((t) => (seen.has(t.id) ? false : seen.add(t.id))).slice(0, 10);
  el.innerHTML = `
    ${pl.length ? `<h2 class="section-title"><span>Your playlists</span></h2><div class="album-grid">${pl.map((p) => card(p, 'playlist')).join('')}</div>` : ''}
    ${
      lists.recent.length
        ? `<h2 class="section-title"><span>Recently played</span></h2><div class="sp-list">${lists.recent.map((t, i) => trackRow(t, i, 'recent')).join('')}</div>`
        : ''
    }
    ${liked.length ? `<h2 class="section-title"><span>Liked songs</span><button class="btn btn-sm" data-a="play-liked">${icons.play}<span>Play all</span></button></h2><div class="sp-list">${liked.map((t, i) => trackRow(t, i, 'liked')).join('')}</div>` : ''}
    ${!pl.length && !liked.length && !recent.length ? `<p class="muted pad">Search above to find something to play.</p>` : ''}`;
  fillArt(el, ctx.bridge);
  const av = $('#sp-avatar');
  const p = ctx.spotify.status.profile;
  if (av && p && p.image) ctx.bridge.art.fetch(p.image).then((u) => u && (av.src = u));
}

async function play(ctx, body) {
  try {
    if (ctx.source !== 'spotify') await ctx.setSource('spotify');
    await ctx.spotify.playItems(body);
  } catch (err) {
    toast(err.message, {
      kind: 'warn',
      timeout: 9000,
      action: err.reason === 'NO_ACTIVE_DEVICE' || err.status === 404 ? { label: 'Open Spotify', run: () => ctx.bridge.shell.open('spotify:') } : undefined,
    });
  }
}

async function onClick(e, ctx) {
  const a = e.target.closest('[data-a]');
  const tr = e.target.closest('.sp-track');
  const cardEl = e.target.closest('[data-uri]');
  if (a) {
    const act = a.dataset.a;
    if (act === 'dashboard') ctx.bridge.shell.open('https://developer.spotify.com/dashboard');
    else if (act === 'copy-uri') {
      await navigator.clipboard.writeText(ctx.spotify.status.redirectUri || 'http://127.0.0.1:43821/callback');
      toast('Redirect URI copied', { kind: 'ok', timeout: 1500 });
    } else if (act === 'connect') {
      const id = ($('#sp-client') || {}).value || '';
      connecting = true;
      render(ctx);
      try {
        await ctx.spotify.connect(id.trim());
        toast('Spotify connected', { kind: 'ok' });
      } catch (err) {
        toast(err.message, { kind: 'error', timeout: 9000 });
      } finally {
        connecting = false;
        render(ctx);
      }
    } else if (act === 'cancel') {
      ctx.spotify.cancel();
    } else if (act === 'disconnect') {
      await ctx.spotify.disconnect();
      cache = { playlists: null, liked: null, recent: null };
    } else if (act === 'open-app') ctx.bridge.shell.open('spotify:');
    else if (act === 'devices') renderDevices(ctx);
    else if (act === 'play-liked') play(ctx, { uris: lists.liked.map((t) => t.uri) });
    return;
  }
  if (tr) {
    const list = lists[tr.dataset.list] || [];
    const i = +tr.dataset.i;
    if (tr.dataset.list === 'search') play(ctx, { uris: [list[i].uri] });
    else play(ctx, { uris: list.map((t) => t.uri), offset: { position: i } });
    return;
  }
  if (cardEl) play(ctx, { context_uri: cardEl.dataset.uri });
}
