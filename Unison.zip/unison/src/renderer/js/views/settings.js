// Settings + the interactive setup guide.
import { html, raw, $, $$, esc, toast, modal } from '../ui/dom.js';
import { icons } from '../ui/icons.js';
import { LATENCY_MODES, precisionSupported } from '../audio/engine.js';
import { pickVirtualInput, pickCalibrationMic } from '../audio/devices.js';
import { openCalibration } from './speakers.js';

let offs = [];
let meterRaf = 0;

export function mount(el, ctx) {
  el.addEventListener('click', (e) => onClick(e, ctx));
  el.addEventListener('change', (e) => onChange(e, ctx));
  offs = [ctx.on('capture', () => renderCapture(ctx)), ctx.on('speakers', () => renderCapture(ctx)), ctx.on('spotify', () => renderSpotify(ctx))];
  const s = ctx.settings;
  el.innerHTML = String(html`
    <div class="page-head">
      <div><h1>Settings</h1><p class="lead">Audio routing, sync engine, looks — and the setup guide.</p></div>
      <div class="head-actions"><button class="btn btn-primary" data-a="guide">${raw(icons.guide)}<span>Setup guide</span></button></div>
    </div>
    <div class="settings-grid">
      <section class="glass panel span2" id="set-capture"></section>

      <section class="glass panel">
        <h2 class="panel-title">${raw(icons.sync)}<span>Sync &amp; latency</span></h2>
        <div class="field"><label>Engine</label>
          <div class="seg" data-set="engine">
            <button data-v="precision" class="${ctx.engine.mode === 'precision' ? 'active' : ''}" ${precisionSupported() ? '' : 'disabled'}>Precision</button>
            <button data-v="compat" class="${ctx.engine.mode === 'compat' ? 'active' : ''}">Compatibility</button>
          </div>
          <small>Precision uses a shared ring buffer with per-speaker clock tracking: tighter sync, automatic drift correction and the smallest safe buffer. Compatibility is a simpler fallback that can click now and then. Changing it restarts audio.</small>
        </div>
        <div class="field"><label>Latency mode</label>
          <div class="seg" data-set="latencyMode">${Object.entries(LATENCY_MODES).map(([k, v]) => html`<button data-v="${k}" class="${ctx.engine.latencyMode === k ? 'active' : ''}">${v.label}</button>`)}</div>
        </div>
        <div class="field"><label>Calibration microphone</label><select class="select" id="set-mic"></select><small>Use the computer's built-in mic. Avoid Bluetooth headset mics — they switch speakers into low-quality call mode.</small></div>
        <button class="btn" data-a="calibrate">${raw(icons.target)}<span>Calibrate sync now</span></button>
      </section>

      <section class="glass panel">
        <h2 class="panel-title">${raw(icons.sparkle)}<span>Look &amp; feel</span></h2>
        <div class="field"><label>3D visuals</label>
          <div class="seg" data-set="visuals">${['ultra', 'high', 'balanced', 'low', 'off'].map((q) => html`<button data-v="${q}" class="${(s.visuals || 'high') === q ? 'active' : ''}">${q[0].toUpperCase() + q.slice(1)}</button>`)}</div>
          <small>The scene automatically lowers its resolution if your graphics chip is busy.</small>
        </div>
        <label class="toggle-row"><span><b>Frosted glass</b><small>Blur behind panels (turn off on very old laptops)</small></span><span class="switch"><input type="checkbox" data-set="glass" ${s.glass !== false ? 'checked' : ''}/><span></span></span></label>
        <label class="toggle-row"><span><b>Reduce motion</b><small>Calmer animations, no 3D tilt</small></span><span class="switch"><input type="checkbox" data-set="reduceMotion" ${s.reduceMotion ? 'checked' : ''}/><span></span></span></label>
      </section>

      <section class="glass panel" id="set-spotify"></section>

      <section class="glass panel">
        <h2 class="panel-title">${raw(icons.keyboard)}<span>Shortcuts</span></h2>
        <dl class="keys">
          <dt><kbd>Space</kbd></dt><dd>Play / pause</dd>
          <dt><kbd>←</kbd> <kbd>→</kbd></dt><dd>Seek 10 s</dd>
          <dt><kbd>Alt</kbd>+<kbd>←</kbd> <kbd>→</kbd></dt><dd>Previous / next</dd>
          <dt><kbd>↑</kbd> <kbd>↓</kbd></dt><dd>Volume</dd>
          <dt><kbd>M</kbd></dt><dd>Mute</dd>
          <dt><kbd>${ctx.isMac ? '⌘' : 'Ctrl'}</kbd>+<kbd>K</kbd></dt><dd>Search</dd>
          <dt><kbd>${ctx.isMac ? '⌘' : 'Ctrl'}</kbd>+<kbd>Shift</kbd>+<kbd>C</kbd></dt><dd>Calibrate</dd>
        </dl>
      </section>

      <section class="glass panel">
        <h2 class="panel-title">${raw(icons.info)}<span>About</span></h2>
        <p><b>Unison</b> ${esc(ctx.info.version || '')} · ${esc(ctx.isMac ? 'macOS' : ctx.isWin ? 'Windows' : ctx.platform)}${ctx.info.electron ? ` · Electron ${esc(ctx.info.electron)}` : ''}</p>
        <p class="muted small">Audio: ${ctx.engine.sampleRate / 1000} kHz · ${ctx.engine.mode} engine · master ${ctx.engine.masterSinkless ? 'offline clock' : 'device clock'}</p>
        <p class="muted small">Works offline for your own music files. Spotify and the Apple Music catalogue need the internet.</p>
        <button class="btn btn-sm btn-ghost" data-a="reset">${raw(icons.refresh)}<span>Show welcome guide next start</span></button>
      </section>
    </div>`);
  renderCapture(ctx);
  renderSpotify(ctx);
  renderMics(ctx);
}

export function unmount() {
  offs.forEach((f) => f());
  offs = [];
  cancelAnimationFrame(meterRaf);
}

function renderMics(ctx) {
  const sel = $('#set-mic');
  if (!sel) return;
  const inputs = ctx.speakers.devices.inputs;
  const cur = pickCalibrationMic(inputs, ctx.settings.micLabel);
  sel.innerHTML = inputs.length
    ? inputs.map((d) => `<option value="${esc(d.label)}" ${cur && cur.id === d.id ? 'selected' : ''}>${esc(d.label || 'Microphone')}</option>`).join('')
    : '<option>Default microphone</option>';
}

function renderCapture(ctx) {
  const el = $('#set-capture');
  if (!el) return;
  const s = ctx.settings;
  const inputs = ctx.speakers.devices.inputs;
  const virt = pickVirtualInput(inputs, s.captureDeviceLabel);
  const c = ctx.capture;
  const status =
    ctx.source === 'local'
      ? `<span class="pill"><span class="dot"></span>Idle — capture starts when you pick Spotify, Apple Music or Any app as the source</span>`
      : c.stream
      ? `<span class="pill"><span class="dot on"></span>Capturing (${c.method === 'loopback' ? 'built-in loopback' : 'virtual device'})</span>`
      : `<span class="pill"><span class="dot bad"></span>${esc(c.error || 'Not capturing')}</span>`;
  const deviceSelect = `<select class="select" id="cap-dev">${
    inputs.length
      ? inputs.map((d) => `<option value="${esc(d.label)}" ${virt && virt.id === d.id ? 'selected' : ''}>${esc(d.label || 'Input')}${d.kind === 'virtual' ? '  ★' : ''}</option>`).join('')
      : '<option value="">No input devices</option>'
  }</select>`;
  let body;
  if (ctx.isMac || !ctx.isDesktop) {
    body = `<div class="cap-mac">
      <div class="field"><label>Capture device</label>${deviceSelect}
        <small>${virt ? `Found <b>${esc(virt.label)}</b> ✓` : 'No virtual audio device found yet.'}</small></div>
      <ol class="steps">
        <li>Install the free, open-source <b>BlackHole 2ch</b> driver. <button class="btn btn-sm" data-a="blackhole">${icons.download}<span>Get BlackHole</span></button></li>
        <li>In <b>System Settings → Sound → Output</b>, choose <b>BlackHole 2ch</b>. Now Spotify, Music and every other app play into Unison instead of the Mac speakers. <button class="btn btn-sm" data-a="sound">${icons.external}<span>Sound settings</span></button></li>
        <li>Pick <b>BlackHole 2ch</b> above, and add your Mac's own speakers in the Speakers page if you want them in the party too.</li>
      </ol>
      <p class="muted small">Tip: Unison's volume slider controls all speakers. The Mac keyboard volume keys don't work while BlackHole is the output — that's normal.</p>
    </div>`;
  } else {
    body = `<div class="cap-cards">
      <div class="radio-card ${s.captureMode !== 'device' ? 'active' : ''}">
        <label class="rc-head"><input type="radio" name="cap" value="builtin" ${s.captureMode !== 'device' ? 'checked' : ''}/>${icons.system}<b>Built-in capture</b><em>Recommended · no install</em></label>
        <span class="rc-body">Captures everything Windows plays and re-plays it in sync on your speakers.</span>
        <label class="toggle-row sm"><span><b>Silence this PC's default output while capturing</b><small>Stops the laptop speakers playing an early, out-of-sync copy</small></span><span class="switch"><input type="checkbox" id="cap-mute" ${s.captureMode !== 'loopback' ? 'checked' : ''}/><span></span></span></label>
        <span class="rc-note">${icons.info}<span>Keep your <b>laptop speakers</b> (not a Bluetooth speaker) as the Windows default output. <button class="link-btn" data-a="sound">Open Sound settings</button></span></span>
      </div>
      <div class="radio-card ${s.captureMode === 'device' ? 'active' : ''}">
        <label class="rc-head"><input type="radio" name="cap" value="device" ${s.captureMode === 'device' ? 'checked' : ''}/>${icons.virtual}<b>Virtual cable</b><em>Advanced</em></label>
        <span class="rc-body">Send only chosen apps (e.g. Spotify) through a free virtual cable such as VB-CABLE, captured here like a microphone.</span>
        <div class="field">${deviceSelect}</div>
        <span class="rc-note">${icons.info}<span>After installing, open <b>Settings → Sound → Volume mixer</b> and set Spotify's output to <b>CABLE Input</b>. <button class="link-btn" data-a="vbcable">Get VB-CABLE</button> · <button class="link-btn" data-a="appsvol">Volume mixer</button></span></span>
      </div>
    </div>`;
  }
  el.innerHTML = `<h2 class="panel-title">${icons.system}<span>Audio capture for Spotify, Apple Music &amp; other apps</span></h2>
    <div class="cap-status">${status}<div class="mic-meter wide"><span id="cap-lvl"></span></div><button class="btn btn-sm" data-a="recapture" ${ctx.source === 'local' ? 'disabled' : ''}>${icons.refresh}<span>Restart capture</span></button></div>
    ${body}`;
  cancelAnimationFrame(meterRaf);
  const lvl = $('#cap-lvl');
  const loop = () => {
    if (!$('#cap-lvl')) return;
    const f = ctx.frameFeatures;
    lvl.style.width = `${ctx.capture.stream && f ? Math.min(100, f.energy * 260) : 0}%`;
    meterRaf = requestAnimationFrame(loop);
  };
  loop();
}

function renderSpotify(ctx) {
  const el = $('#set-spotify');
  if (!el) return;
  const st = ctx.spotify.status;
  el.innerHTML = `<h2 class="panel-title">${icons.spotify}<span>Spotify</span></h2>
    <p>${st.connected ? `Connected as <b>${esc(st.profile ? st.profile.name : 'you')}</b>.` : st.configured ? 'Client ID saved, not connected.' : 'Not connected.'}</p>
    ${st.clientId ? `<p class="muted small">Client ID: <code>${esc(st.clientId.slice(0, 6))}…${esc(st.clientId.slice(-4))}</code></p>` : ''}
    <div class="row gap">${
      st.connected ? `<button class="btn btn-ghost" data-a="sp-disconnect">${icons.power}<span>Disconnect</span></button>` : `<button class="btn" data-a="sp-setup">${icons.link}<span>Set up Spotify</span></button>`
    }</div>`;
}

async function onClick(e, ctx) {
  const seg = e.target.closest('.seg[data-set] button');
  if (seg && !seg.disabled) {
    const key = seg.closest('.seg').dataset.set;
    const v = seg.dataset.v;
    $$('button', seg.parentElement).forEach((b) => b.classList.toggle('active', b === seg));
    if (key === 'visuals') {
      await ctx.saveSettings({ visuals: v });
      ctx.applyLook();
    } else if (key === 'latencyMode') {
      ctx.engine.setLatencyMode(v);
      await ctx.saveSettings({ latencyMode: v });
    } else if (key === 'engine') {
      if (v !== ctx.engine.mode) {
        await ctx.saveSettings({ engine: v });
        toast('Restarting audio with the new engine…', { timeout: 1500 });
        setTimeout(() => location.reload(), 700);
      }
    }
    return;
  }
  const a = e.target.closest('[data-a]');
  if (!a) return;
  switch (a.dataset.a) {
    case 'guide':
      openGuide(ctx);
      break;
    case 'calibrate':
      openCalibration(ctx);
      break;
    case 'sound':
      e.preventDefault();
      ctx.bridge.shell.settings('sound');
      break;
    case 'appsvol':
      e.preventDefault();
      ctx.bridge.shell.settings('apps-volume');
      break;
    case 'blackhole':
      ctx.bridge.shell.open('https://existential.audio/blackhole/');
      break;
    case 'vbcable':
      e.preventDefault();
      ctx.bridge.shell.open('https://vb-audio.com/Cable/');
      break;
    case 'recapture':
      await ctx.restartCapture();
      break;
    case 'sp-disconnect':
      await ctx.spotify.disconnect();
      break;
    case 'sp-setup':
      ctx.navigate('spotify');
      break;
    case 'reset':
      await ctx.saveSettings({ firstRun: true });
      toast('The welcome guide will show next time you start Unison.', { kind: 'ok' });
      break;
    default:
  }
}

async function onChange(e, ctx) {
  const t = e.target;
  if (t.name === 'cap') {
    const mode = t.value === 'device' ? 'device' : $('#cap-mute') && !$('#cap-mute').checked ? 'loopback' : 'loopbackWithMute';
    await ctx.saveSettings({ captureMode: mode });
    renderCapture(ctx);
    await ctx.restartCapture();
  } else if (t.id === 'cap-mute') {
    if (ctx.settings.captureMode === 'device') return;
    await ctx.saveSettings({ captureMode: t.checked ? 'loopbackWithMute' : 'loopback' });
    await ctx.restartCapture();
  } else if (t.id === 'cap-dev') {
    await ctx.saveSettings({ captureDeviceLabel: t.value });
    await ctx.restartCapture();
  } else if (t.id === 'set-mic') {
    await ctx.saveSettings({ micLabel: t.value });
  } else if (t.dataset.set === 'glass' || t.dataset.set === 'reduceMotion') {
    await ctx.saveSettings({ [t.dataset.set]: t.checked });
    ctx.applyLook();
  }
}

// ------------------------------------------------------------------------------ guide
export function openGuide(ctx) {
  const steps = [
    {
      title: 'Pair your speakers',
      art: 'pair',
      body: `<p>Switch each speaker on and put it in pairing mode, then pair it in your ${ctx.isMac ? 'Mac' : 'Windows'} Bluetooth settings. Every paired speaker becomes its own audio output.</p>
        <ul class="ticks"><li>One Bluetooth adapter handles about <b>2–4 speakers</b>; a cheap USB Bluetooth dongle adds more.</li>
        <li>Wired, USB and HDMI outputs work too — mix them freely.</li>
        ${ctx.isWin ? '<li>Keep your <b>laptop speakers as the Windows default output</b>, not a Bluetooth speaker.</li>' : ''}</ul>`,
      action: { label: 'Open Bluetooth settings', icon: icons.bluetooth, run: () => ctx.bridge.shell.settings('bluetooth') },
    },
    {
      title: 'Add them to the party',
      art: 'party',
      body: `<p>Open <b>Speakers</b> and press <b>Add</b> on each speaker. Use <em>Identify</em> to hear which is which, set volumes, or make two speakers a left/right stereo pair.</p>`,
      action: { label: 'Go to Speakers', icon: icons.speakers, run: (close) => (close(), ctx.navigate('speakers')) },
    },
    {
      title: 'Calibrate once',
      art: 'sync',
      body: `<p>Every Bluetooth speaker has its own delay (often 100–300 ms), which is why several speakers usually sound like an echo. Unison plays a short chirp on each one, listens with your computer's microphone and lines them all up — usually within a millisecond.</p>
        <p class="muted small">Put the computer where people will listen. Redo it if you move speakers around.</p>`,
      action: { label: 'Calibrate now', icon: icons.target, run: (close) => (close(), openCalibration(ctx)) },
    },
    {
      title: 'Pick your music',
      art: 'music',
      body: `<ul class="ticks">
        <li><b>My Music</b> — songs on this computer. Works fully <b>offline</b>.</li>
        <li><b>Spotify</b> — connect once, then search and play from Unison${ctx.isWin ? ' (play/pause works even without connecting)' : ''}.</li>
        <li><b>Apple Music</b> — ${ctx.isMac ? 'search your library and playlists from Unison' : 'play in the Apple Music app and control it from here'}.</li>
        <li><b>Any app</b> — YouTube, games, anything your computer plays.</li></ul>
        ${ctx.isMac ? '<p class="muted small">On a Mac, apps like Spotify reach Unison through the free BlackHole driver — see Settings → Audio capture.</p>' : ''}`,
      action: { label: 'Play the test tune', icon: icons.play, run: () => ctx.playTestTune() },
    },
  ];
  let i = 0;
  const body = document.createElement('div');
  body.className = 'guide';
  const m = modal({ title: 'Welcome to Unison', body, className: 'modal-guide', onClose: () => ctx.saveSettings({ firstRun: false }) });
  const draw = () => {
    const s = steps[i];
    body.innerHTML = `
      <div class="guide-progress">${steps.map((_, k) => `<span class="${k <= i ? 'on' : ''}"></span>`).join('')}</div>
      <div class="guide-step">
        <div class="guide-art art-${s.art}"><span class="ga-a"></span><span class="ga-b"></span><span class="ga-c"></span><span class="ga-core">${
      { pair: icons.bluetooth, party: icons.speakers, sync: icons.sync, music: icons.music }[s.art]
    }</span></div>
        <div class="guide-text"><small>Step ${i + 1} of ${steps.length}</small><h3>${s.title}</h3>${s.body}
          <button class="btn" data-g="act">${s.action.icon}<span>${s.action.label}</span></button></div>
      </div>
      <div class="modal-actions"><button class="btn btn-ghost" data-g="back" ${i === 0 ? 'disabled' : ''}>Back</button><button class="btn btn-primary btn-glow" data-g="next">${
      i === steps.length - 1 ? "Let's go" : 'Next'
    }</button></div>`;
  };
  body.addEventListener('click', (e) => {
    const b = e.target.closest('[data-g]');
    if (!b) return;
    if (b.dataset.g === 'next') {
      if (i === steps.length - 1) m.close();
      else {
        i++;
        draw();
      }
    } else if (b.dataset.g === 'back' && i > 0) {
      i--;
      draw();
    } else if (b.dataset.g === 'act') steps[i].action.run(m.close);
  });
  draw();
}
