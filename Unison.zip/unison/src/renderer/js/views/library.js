// Library: offline music on this computer — songs, albums, artists, folders.
import { html, raw, $, $$, esc, toast, fmtTime, debounce } from '../ui/dom.js';
import { icons } from '../ui/icons.js';

const ROW_H = 58;
let offs = [];
let state = { tab: 'songs', q: '', sort: 'artist', album: null, artist: null, albumLimit: 120 };
let filtered = [];

const norm = (s) =>
  String(s || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase();

export function mount(el, ctx) {
  el.innerHTML = String(html`
    <div class="page-head">
      <div>
        <h1>Library</h1>
        <p class="lead" id="lib-stats">Your own music files — plays fully offline.</p>
      </div>
      <div class="head-actions">
        <div class="search"><span class="ico">${raw(icons.search)}</span><input type="search" id="lib-q" placeholder="Search songs, artists, albums" value="${state.q}" /></div>
        <button class="btn btn-primary" data-a="folder">${raw(icons.folder)}<span>Add folder</span></button>
        <button class="btn" data-a="files">${raw(icons.plus)}<span>Add songs</span></button>
        <button class="icon-btn" data-a="rescan" title="Rescan folders">${raw(icons.refresh)}</button>
      </div>
    </div>
    <div class="scan" id="lib-scan"></div>
    <div class="lib-bar">
      <div class="seg tabs" id="lib-tabs">
        ${['songs', 'albums', 'artists', 'folders'].map((t) => html`<button data-tab="${t}" class="${state.tab === t ? 'active' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`)}
      </div>
      <div class="lib-tools" id="lib-tools"></div>
    </div>
    <div class="lib-body" id="lib-body"></div>
    <input type="file" id="lib-file" accept="audio/*,.flac,.m4a,.opus" multiple hidden />
  `);
  el.addEventListener('click', (e) => onClick(e, ctx));
  $('#lib-q', el).addEventListener(
    'input',
    debounce((e) => {
      state.q = e.target.value;
      state.album = null;
      renderBody(ctx);
    }, 120)
  );
  $('#lib-file', el).addEventListener('change', async (e) => {
    const files = [...e.target.files];
    if (!files.length) return;
    await ctx.bridge.library.addBrowserFiles(files);
    await ctx.loadLibrary();
    toast(`Added ${files.length} song${files.length === 1 ? '' : 's'}`, { kind: 'ok' });
  });
  offs = [ctx.on('library', () => renderAll(ctx)), ctx.on('library-progress', (p) => renderScan(p)), ctx.on('now', () => markPlaying(ctx))];
  renderAll(ctx);
}

export function unmount() {
  offs.forEach((f) => f());
  offs = [];
}

function renderAll(ctx) {
  const t = ctx.library.tracks;
  const albums = new Set(t.map((x) => `${x.albumArtist || x.artist}|${x.album}`)).size;
  const total = t.reduce((a, x) => a + (x.duration || 0), 0);
  $('#lib-stats').textContent = t.length
    ? `${t.length.toLocaleString()} songs · ${albums.toLocaleString()} albums · ${Math.round(total / 3600)} h of music — plays fully offline.`
    : 'Your own music files — plays fully offline.';
  renderScan(ctx.library.scanning);
  renderBody(ctx);
}

function renderScan(p) {
  const el = $('#lib-scan');
  if (!el) return;
  if (!p || p.done) {
    el.innerHTML = '';
    return;
  }
  const pct = p.total ? Math.round((p.scanned / p.total) * 100) : 0;
  el.innerHTML = `<div class="scan-bar glass-lite"><span>${icons.refresh}</span><div><b>Scanning your music… ${p.scanned.toLocaleString()} / ${p.total.toLocaleString()}</b><small>${esc(
    p.current || ''
  )}</small></div><div class="bar"><i style="width:${pct}%"></i></div></div>`;
}

function sortTracks(list, sort) {
  const a = list.slice();
  if (sort === 'title') a.sort((x, y) => norm(x.title).localeCompare(norm(y.title)));
  else if (sort === 'recent') a.sort((x, y) => (y.addedAt || 0) - (x.addedAt || 0));
  else
    a.sort(
      (x, y) =>
        norm(x.albumArtist || x.artist).localeCompare(norm(y.albumArtist || y.artist)) ||
        norm(x.album).localeCompare(norm(y.album)) ||
        (x.track || 999) - (y.track || 999) ||
        norm(x.title).localeCompare(norm(y.title))
    );
  return a;
}

function applyFilter(ctx) {
  let list = ctx.library.tracks;
  const q = norm(state.q).trim();
  if (q) {
    const words = q.split(/\s+/);
    list = list.filter((t) => {
      const hay = norm(`${t.title} ${t.artist} ${t.album} ${t.albumArtist || ''}`);
      return words.every((w) => hay.includes(w));
    });
  }
  if (state.artist) list = list.filter((t) => (t.albumArtist || t.artist) === state.artist || t.artist === state.artist);
  return sortTracks(list, state.sort);
}

function renderBody(ctx) {
  const body = $('#lib-body');
  if (!body) return;
  $$('#lib-tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === state.tab));
  const tools = $('#lib-tools');
  const lib = ctx.library.tracks;
  if (!lib.length && !ctx.library.scanning) {
    tools.innerHTML = '';
    body.className = 'lib-body';
    body.innerHTML = emptyState(ctx);
    return;
  }
  filtered = applyFilter(ctx);
  if (state.album) return renderAlbum(ctx, body);
  if (state.tab === 'songs') {
    tools.innerHTML = `${state.artist ? `<button class="chip" data-a="clear-artist">${icons.x}<span>${esc(state.artist)}</span></button>` : ''}
      <button class="btn btn-sm" data-a="play-all">${icons.play}<span>Play</span></button>
      <button class="btn btn-sm" data-a="shuffle-all">${icons.shuffle}<span>Shuffle</span></button>
      <select class="select sm" id="lib-sort">${[
        ['artist', 'Artist / album'],
        ['title', 'Title'],
        ['recent', 'Recently added'],
      ]
        .map(([v, l]) => `<option value="${v}" ${state.sort === v ? 'selected' : ''}>${l}</option>`)
        .join('')}</select>`;
    $('#lib-sort').onchange = (e) => {
      state.sort = e.target.value;
      renderBody(ctx);
    };
    renderSongs(ctx, body);
  } else if (state.tab === 'albums') {
    tools.innerHTML = '';
    renderAlbums(ctx, body);
  } else if (state.tab === 'artists') {
    tools.innerHTML = '';
    renderArtists(ctx, body);
  } else {
    tools.innerHTML = '';
    renderFolders(ctx, body);
  }
}

function emptyState(ctx) {
  return `<div class="lib-empty">
    <div class="drop-art"><div class="vinyl mini spin"><div class="grooves"></div></div><div class="drop-glow"></div></div>
    <h2>Bring your music</h2>
    <p>Drop a music folder or songs anywhere on this window, or pick a folder. MP3, AAC/M4A, FLAC, OGG, Opus and WAV are supported — everything plays offline.</p>
    <div class="row gap">
      ${ctx.isDesktop ? `<button class="btn btn-primary btn-glow" data-a="folder">${icons.folder}<span>Choose music folder</span></button>` : ''}
      <button class="btn" data-a="files">${icons.plus}<span>Add songs</span></button>
      <button class="btn" data-a="tune">${icons.play}<span>Play the test tune</span></button>
    </div>
  </div>`;
}

// ------------------------------------------------------------------ songs (virtualised)
function renderSongs(ctx, body) {
  body.className = 'lib-body songs';
  if (!filtered.length) {
    body.innerHTML = `<p class="muted pad">No songs match “${esc(state.q)}”.</p>`;
    return;
  }
  body.innerHTML = `<div class="song-head"><span>#</span><span>Title</span><span>Album</span><span>${icons.clock}</span></div>
    <div class="vlist" id="vlist"><div class="vspace" style="height:${filtered.length * ROW_H}px"></div><div class="vrows" id="vrows"></div></div>`;
  const vl = $('#vlist');
  const draw = () => {
    const rows = $('#vrows');
    if (!rows || !vl.isConnected) {
      ro.disconnect();
      return;
    }
    const top = vl.scrollTop;
    const h = vl.clientHeight || 600;
    const start = Math.max(0, Math.floor(top / ROW_H) - 8);
    const end = Math.min(filtered.length, Math.ceil((top + h) / ROW_H) + 8);
    const cur = ctx.source === 'local' && ctx.local.track ? ctx.local.track.id : null;
    let out = '';
    for (let i = start; i < end; i++) {
      const t = filtered[i];
      out += `<div class="song ${t.id === cur ? 'current' : ''}" data-i="${i}" style="transform:translateY(${i * ROW_H}px)">
        <span class="s-n"><span class="s-idx">${i + 1}</span><span class="s-play">${icons.play}</span><span class="s-eq"><i></i><i></i><i></i></span></span>
        <span class="s-main"><img loading="lazy" src="${esc(ctx.coverUrl(t, 96))}" alt=""/><span><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span></span>
        <span class="s-album">${esc(t.album)}</span>
        <span class="s-dur">${t.duration ? fmtTime(t.duration) : ''}<span class="s-acts"><button class="icon-btn sm" data-a="next" title="Play next">${icons.queue}</button><button class="icon-btn sm" data-a="queue" title="Add to queue">${icons.plus}</button></span></span>
      </div>`;
    }
    rows.innerHTML = out;
  };
  const ro = new ResizeObserver(() => draw());
  vl.addEventListener('scroll', () => requestAnimationFrame(draw), { passive: true });
  ro.observe(vl);
  draw();
}

function markPlaying(ctx) {
  const cur = ctx.source === 'local' && ctx.local.track ? ctx.local.track.id : null;
  $$('#vrows .song').forEach((r) => {
    const t = filtered[+r.dataset.i];
    r.classList.toggle('current', !!t && t.id === cur);
  });
}

// ------------------------------------------------------------------ albums
function albumsOf(list) {
  const m = new Map();
  for (const t of list) {
    const key = `${t.albumArtist || t.artist}|${t.album}`;
    if (!m.has(key)) m.set(key, { key, album: t.album, artist: t.albumArtist || t.artist, tracks: [], year: t.year, cover: t });
    const a = m.get(key);
    a.tracks.push(t);
    if (!a.cover.cover && t.cover) a.cover = t;
  }
  return [...m.values()].sort((a, b) => norm(a.artist).localeCompare(norm(b.artist)) || norm(a.album).localeCompare(norm(b.album)));
}

function renderAlbums(ctx, body) {
  body.className = 'lib-body scroll';
  const albums = albumsOf(filtered);
  const shown = albums.slice(0, state.albumLimit);
  body.innerHTML = `<div class="album-grid">${shown
    .map(
      (a, i) => `<button class="album-card tile" data-album="${esc(a.key)}" data-tilt="12" style="--i:${i % 12}">
      <span class="ac-art"><img loading="lazy" src="${esc(ctx.coverUrl(a.cover, 320))}" alt=""/><span class="ac-gloss"></span><span class="ac-play" data-a="play-album">${icons.play}</span></span>
      <b>${esc(a.album)}</b><small>${esc(a.artist)}${a.year ? ` · ${esc(a.year)}` : ''}</small></button>`
    )
    .join('')}</div>${albums.length > shown.length ? `<div class="center pad"><button class="btn" data-a="more-albums">Show more (${albums.length - shown.length})</button></div>` : ''}`;
}

function renderAlbum(ctx, body) {
  const a = albumsOf(ctx.library.tracks).find((x) => x.key === state.album);
  if (!a) {
    state.album = null;
    renderBody(ctx);
    return;
  }
  $('#lib-tools').innerHTML = '';
  body.className = 'lib-body scroll';
  const tracks = sortTracks(a.tracks, 'artist');
  const total = tracks.reduce((s, t) => s + (t.duration || 0), 0);
  body.innerHTML = `<div class="album-detail">
    <button class="link-btn back" data-a="back">← All albums</button>
    <div class="ad-head">
      <div class="ad-art" data-tilt="14"><img src="${esc(ctx.coverUrl(a.cover, 480))}" alt=""/><span class="ac-gloss"></span></div>
      <div class="ad-meta"><small>Album</small><h2>${esc(a.album)}</h2><p>${esc(a.artist)}${a.year ? ` · ${esc(a.year)}` : ''} · ${tracks.length} songs · ${fmtTime(total)}</p>
        <div class="row gap"><button class="btn btn-primary btn-glow" data-a="play-this">${icons.play}<span>Play</span></button><button class="btn" data-a="shuffle-this">${icons.shuffle}<span>Shuffle</span></button></div>
      </div>
    </div>
    <div class="ad-tracks">${tracks
      .map(
        (t, i) => `<div class="ad-row" data-i="${i}"><span class="s-n">${t.track || i + 1}</span><b>${esc(t.title)}</b><small>${esc(t.artist !== a.artist ? t.artist : '')}</small><span class="s-dur">${
          t.duration ? fmtTime(t.duration) : ''
        }</span></div>`
      )
      .join('')}</div></div>`;
  body._tracks = tracks;
}

// ------------------------------------------------------------------ artists & folders
function renderArtists(ctx, body) {
  body.className = 'lib-body scroll';
  const m = new Map();
  for (const t of filtered) {
    const k = t.albumArtist || t.artist;
    if (!m.has(k)) m.set(k, { name: k, n: 0, albums: new Set(), cover: t });
    const a = m.get(k);
    a.n++;
    a.albums.add(t.album);
    if (!a.cover.cover && t.cover) a.cover = t;
  }
  const list = [...m.values()].sort((a, b) => norm(a.name).localeCompare(norm(b.name)));
  body.innerHTML = `<div class="artist-grid">${list
    .slice(0, 500)
    .map(
      (a) => `<button class="artist tile" data-artist="${esc(a.name)}"><img loading="lazy" src="${esc(ctx.coverUrl(a.cover, 160))}" alt=""/><b>${esc(a.name)}</b><small>${a.albums.size} album${
        a.albums.size === 1 ? '' : 's'
      } · ${a.n} songs</small></button>`
    )
    .join('')}</div>`;
}

function renderFolders(ctx, body) {
  body.className = 'lib-body scroll';
  const f = ctx.library.folders;
  body.innerHTML = `<div class="folder-list">${
    f.length
      ? f
          .map((p) => {
            const n = ctx.library.tracks.filter((t) => t.folder === p).length;
            return `<div class="folder glass-lite">${icons.folder}<div><b>${esc(p.split(/[\\/]/).pop() || p)}</b><small>${esc(p)} · ${n} songs</small></div><button class="btn btn-sm btn-ghost" data-a="rmfolder" data-folder="${esc(
              p
            )}">${icons.x}<span>Remove</span></button></div>`;
          })
          .join('')
      : '<p class="muted pad">No folders yet. Songs added one by one or by drag-and-drop are listed under Songs.</p>'
  }</div>`;
}

// ------------------------------------------------------------------ events
async function onClick(e, ctx) {
  const tab = e.target.closest('[data-tab]');
  if (tab) {
    state.tab = tab.dataset.tab;
    state.album = null;
    renderBody(ctx);
    return;
  }
  const a = e.target.closest('[data-a]');
  const song = e.target.closest('.song');
  const albumCard = e.target.closest('[data-album]');
  const artist = e.target.closest('[data-artist]');
  const adRow = e.target.closest('.ad-row');
  if (a) {
    const act = a.dataset.a;
    if (act === 'folder') {
      if (!ctx.bridge.library.pickFolder) {
        toast('Folder picking works in the desktop app. In the browser, add songs or drop files.');
        return;
      }
      const res = await ctx.bridge.library.pickFolder();
      if (res) {
        await ctx.loadLibrary();
        toast('Folder added', { kind: 'ok', timeout: 1800 });
      }
    } else if (act === 'files') {
      if (ctx.bridge.library.pickFiles) {
        const res = await ctx.bridge.library.pickFiles();
        if (res) await ctx.loadLibrary();
      } else $('#lib-file').click();
    } else if (act === 'rescan') {
      await ctx.bridge.library.rescan();
      await ctx.loadLibrary();
    } else if (act === 'tune') ctx.playTestTune();
    else if (act === 'play-all') ctx.playLocal(filtered, 0);
    else if (act === 'shuffle-all') {
      await ctx.local.setShuffle(true);
      ctx.playLocal(filtered, Math.floor(Math.random() * filtered.length));
    } else if (act === 'clear-artist') {
      state.artist = null;
      renderBody(ctx);
    } else if (act === 'more-albums') {
      state.albumLimit += 240;
      renderBody(ctx);
    } else if (act === 'back') {
      state.album = null;
      renderBody(ctx);
    } else if (act === 'play-this' || act === 'shuffle-this') {
      const tr = $('#lib-body')._tracks || [];
      ctx.local.setShuffle(act === 'shuffle-this');
      ctx.playLocal(tr, act === 'shuffle-this' ? Math.floor(Math.random() * tr.length) : 0);
    } else if (act === 'play-album' && albumCard) {
      e.stopPropagation();
      const al = albumsOf(ctx.library.tracks).find((x) => x.key === albumCard.dataset.album);
      if (al) ctx.playLocal(sortTracks(al.tracks, 'artist'), 0);
    } else if (act === 'rmfolder') {
      await ctx.bridge.library.removeFolder(a.dataset.folder);
      await ctx.loadLibrary();
    } else if ((act === 'next' || act === 'queue') && song) {
      const t = filtered[+song.dataset.i];
      if (act === 'next') ctx.local.playNext(t);
      else ctx.local.addToQueue(t);
      if (ctx.source !== 'local') ctx.setSource('local');
      toast(act === 'next' ? `“${t.title}” plays next` : `Added “${t.title}” to the queue`, { kind: 'ok', timeout: 1600 });
    }
    return;
  }
  if (song) {
    ctx.playLocal(filtered, +song.dataset.i);
    return;
  }
  if (albumCard) {
    state.album = albumCard.dataset.album;
    renderBody(ctx);
    $('#lib-body').scrollTop = 0;
    return;
  }
  if (artist) {
    state.artist = artist.dataset.artist;
    state.tab = 'songs';
    renderBody(ctx);
    return;
  }
  if (adRow) {
    const tr = $('#lib-body')._tracks || [];
    ctx.playLocal(tr, +adRow.dataset.i);
  }
}
