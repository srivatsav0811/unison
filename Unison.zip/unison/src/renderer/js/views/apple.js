// Apple Music: macOS — full control of the Music app (library search, playlists).
// Windows — now playing + transport of the Apple Music app via Windows media controls.
// Both — Apple Music catalogue search (free, no account needed).
import { html, raw, $, $$, esc, toast, fmtTime, debounce, generatedCover } from '../ui/dom.js';
import { icons } from '../ui/icons.js';

let offs = [];
let libQ = '';
let catQ = '';

export function mount(el, ctx) {
  el.innerHTML = String(html`
    <div class="page-head">
      <div>
        <h1>Apple Music</h1>
        <p class="lead">${ctx.isMac
          ? 'Search your Music library and playlists — the Music app plays them and Unison sends the sound to every speaker.'
          : 'Play music in the Apple Music app — Unison shows it here, controls it, and sends it to every speaker.'}</p>
      </div>
      <div class="head-actions">
        <button class="btn ${ctx.source === 'apple' ? 'on' : 'btn-primary'}" data-a="use">${raw(icons.apple)}<span>${ctx.source === 'apple' ? 'Current source' : 'Use as source'}</span></button>
        <button class="btn" data-a="open">${raw(icons.external)}<span>Open Apple Music</span></button>
      </div>
    </div>
    <div id="am-status"></div>
    ${ctx.isMac
      ? raw(`<div class="am-grid">
        <section class="glass panel"><h2 class="panel-title">${icons.search}<span>Your library</span></h2>
          <div class="search"><span class="ico">${icons.search}</span><input type="search" id="am-lib-q" placeholder="Songs, artists or albums in Music" value="${esc(libQ)}"/></div>
          <div id="am-lib" class="sp-list compact"></div></section>
        <section class="glass panel"><h2 class="panel-title">${icons.list}<span>Playlists</span></h2><div id="am-pl" class="pl-list"></div></section>
      </div>`)
      : raw(`<section class="glass panel" id="am-win"></section>`)}
    <section class="glass panel">
      <h2 class="panel-title">${raw(icons.sparkle)}<span>Discover in the Apple Music catalogue</span></h2>
      <div class="search"><span class="ico">${raw(icons.search)}</span><input type="search" id="am-cat-q" placeholder="Search the whole Apple Music catalogue" value="${catQ}" /></div>
      <div id="am-cat" class="sp-list"></div>
      <p class="muted small">${ctx.isMac ? 'Opens the song in the Music app — press play there (or add it to your library to play it from here).' : 'Opens the song in Apple Music — press play there and Unison takes it from there.'}</p>
    </section>`);
  el.addEventListener('click', (e) => onClick(e, ctx));
  const cat = $('#am-cat-q', el);
  cat.addEventListener('input', debounce(() => catalog(ctx, cat.value), 400));
  if (ctx.isMac) {
    const lq = $('#am-lib-q', el);
    lq.addEventListener('input', debounce(() => libSearch(ctx, lq.value), 350));
    loadPlaylists(ctx);
    if (libQ) libSearch(ctx, libQ);
  } else {
    offs.push(ctx.on('now', () => renderWin(ctx)));
    renderWin(ctx);
    ensureWinPoll(ctx);
  }
  if (catQ) catalog(ctx, catQ);
  offs.push(ctx.on('source', () => ctx.view === 'apple' && ctx.navigate('apple')));
}

export function unmount(ctx) {
  offs.forEach((f) => f());
  offs = [];
  if (ctx && ctx._amPoll && ctx.source !== 'apple') ctx._amPoll.stop();
}

function remote(ctx) {
  ctx._remotes = ctx._remotes || {};
  return ctx._remotes;
}

function ensureWinPoll(ctx) {
  if (!ctx.isWin || !ctx.isDesktop) return;
  // make sure the Apple Music session is being watched even if another source is active
  import('../sources/remote.js').then(({ WinMediaController }) => {
    const R = remote(ctx);
    R.winApple = R.winApple || new WinMediaController(ctx.bridge, 'AppleMusic', 'Apple Music');
    ctx._amPoll = R.winApple;
    if (!R.winApple._viewHooked) {
      R.winApple._viewHooked = true;
      R.winApple.addEventListener('change', () => ctx.view === 'apple' && renderWin(ctx));
    }
    if (!R.winApple.timer) R.winApple.start();
  });
}

function renderWin(ctx) {
  const el = $('#am-win');
  if (!el) return;
  const c = remote(ctx).winApple;
  const st = c ? c.state() : { active: false };
  if (!ctx.isDesktop) {
    el.innerHTML = `<p>Apple Music control is available in the desktop app.</p>`;
    return;
  }
  if (c && c.error && !st.active) {
    el.innerHTML = `<div class="banner warn">${icons.alert}<span>Windows media controls aren't answering (${esc(c.error.error || '')}). They need Windows 10 (1809) or newer.</span></div>`;
    return;
  }
  el.innerHTML = st.active
    ? `<div class="am-now">
        <img src="${esc(st.art || generatedCover(st.title, 240))}" alt=""/>
        <div><small class="muted">Now in Apple Music</small><h2>${esc(st.title)}</h2><p>${esc(st.artist)}${st.album ? ` · ${esc(st.album)}` : ''}</p>
        <div class="row gap"><button class="btn btn-sm" data-a="w-prev">${icons.prev}</button><button class="btn btn-sm btn-primary" data-a="w-toggle">${st.playing ? icons.pause : icons.play}<span>${
          st.playing ? 'Pause' : 'Play'
        }</span></button><button class="btn btn-sm" data-a="w-next">${icons.next}</button></div></div></div>`
    : `<div class="am-now empty"><div class="vinyl mini"><div class="grooves"></div></div><div><h2>Apple Music isn't playing</h2><p class="muted">Open the Apple Music app from the Microsoft Store and start a song. Unison picks it up within a second.</p></div></div>`;
}

async function libSearch(ctx, q) {
  libQ = q;
  const el = $('#am-lib');
  if (!el) return;
  if (!q.trim()) {
    el.innerHTML = `<p class="muted pad">Type to search the songs in your Music library (including downloaded Apple Music songs — they play offline).</p>`;
    return;
  }
  el.innerHTML = `<div class="loading-row"><span class="spinner"></span>Searching Music…</div>`;
  try {
    const res = await ctx._appleCall('search', q);
    if (libQ !== q || !$('#am-lib')) return;
    el._items = res;
    el.innerHTML = res.length
      ? res
          .slice(0, 100)
          .map(
            (t, i) => `<div class="sp-track" data-am="${i}"><span class="s-n"><span class="s-idx">${i + 1}</span><span class="s-play">${icons.play}</span></span>
            <span class="sp-t"><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span><span class="sp-al">${esc(t.album)}</span><span class="s-dur">${fmtTime(t.duration)}</span></div>`
          )
          .join('')
      : `<p class="muted pad">No songs in your library match “${esc(q)}”.</p>`;
  } catch (err) {
    el.innerHTML = appleError(ctx, err);
  }
}

async function loadPlaylists(ctx) {
  const el = $('#am-pl');
  if (!el) return;
  el.innerHTML = `<div class="loading-row"><span class="spinner"></span>Loading playlists…</div>`;
  try {
    const pls = await ctx._appleCall('playlists');
    if (!$('#am-pl')) return;
    el.innerHTML = pls.length
      ? pls
          .map(
            (p) => `<button class="pl-item tile" data-pl="${esc(p.id)}"><img src="${esc(generatedCover(p.name, 96))}" alt=""/><b>${esc(p.name)}</b><span class="s-play">${icons.play}</span></button>`
          )
          .join('')
      : `<p class="muted pad">No playlists yet.</p>`;
  } catch (err) {
    el.innerHTML = appleError(ctx, err);
  }
}

function appleError(ctx, err) {
  if (err.code === 'automation_denied')
    return `<div class="banner warn">${icons.alert}<span>${esc(err.message)}</span><button class="btn btn-sm" data-a="automation">Open settings</button></div>`;
  return `<div class="banner warn">${icons.alert}<span>${esc(err.message || 'Music did not respond.')}</span></div>`;
}

async function catalog(ctx, q) {
  catQ = q;
  const el = $('#am-cat');
  if (!el) return;
  if (!q.trim()) {
    el.innerHTML = '';
    return;
  }
  el.innerHTML = `<div class="loading-row"><span class="spinner"></span>Searching Apple Music…</div>`;
  const res = await ctx.bridge.itunes.search(q, ctx.info.country);
  if (catQ !== q || !$('#am-cat')) return;
  if (!Array.isArray(res)) {
    el.innerHTML = `<div class="banner warn">${icons.wifiOff}<span>${ctx.isDesktop ? 'You appear to be offline.' : 'Catalogue search works in the desktop app.'}</span></div>`;
    return;
  }
  el.innerHTML = res.length
    ? res
        .map(
          (t) => `<div class="sp-track cat" data-url="${esc(t.url)}"><img src="${esc(generatedCover(t.title, 64))}" data-art="${esc(t.art)}" alt=""/>
          <span class="sp-t"><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span><span class="sp-al">${esc(t.album)}</span><span class="s-dur">${fmtTime(t.duration)}</span>
          <button class="btn btn-sm" data-a="open-cat">${icons.external}<span>Open</span></button></div>`
        )
        .join('')
    : `<p class="muted pad">Nothing found.</p>`;
  for (const img of $$('img[data-art]', el)) ctx.bridge.art.fetch(img.dataset.art).then((u) => u && (img.src = u));
}

async function onClick(e, ctx) {
  const a = e.target.closest('[data-a]');
  const tr = e.target.closest('[data-am]');
  const pl = e.target.closest('[data-pl]');
  try {
    if (a) {
      const act = a.dataset.a;
      if (act === 'use') ctx.setSource('apple', { user: true });
      else if (act === 'open') ctx.bridge.shell.open(ctx.isMac ? 'music://' : 'https://music.apple.com/');
      else if (act === 'automation') ctx.bridge.shell.settings('automation');
      else if (act === 'open-cat') {
        const url = e.target.closest('[data-url]').dataset.url;
        ctx.bridge.shell.open(ctx.isMac ? url.replace(/^https:/, 'music:') : url);
        if (ctx.source !== 'apple') ctx.setSource('apple');
      } else if (act === 'w-toggle' || act === 'w-next' || act === 'w-prev') {
        const c = remote(ctx).winApple;
        if (!c) return;
        if (ctx.source !== 'apple') await ctx.setSource('apple');
        await c[{ 'w-toggle': 'toggle', 'w-next': 'next', 'w-prev': 'prev' }[act]]();
      }
      return;
    }
    if (tr) {
      const items = $('#am-lib')._items || [];
      const t = items[+tr.dataset.am];
      if (!t) return;
      if (ctx.source !== 'apple') await ctx.setSource('apple');
      await ctx._appleCall('playTrack', t.id);
      return;
    }
    if (pl) {
      if (ctx.source !== 'apple') await ctx.setSource('apple');
      await ctx._appleCall('playPlaylist', pl.dataset.pl);
      toast('Playing playlist', { kind: 'ok', timeout: 1500 });
    }
  } catch (err) {
    toast(err.message, { kind: 'warn' });
  }
}
