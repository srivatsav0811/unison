'use strict';
// app://unison/... — serves the UI, cover art and (range-seekable) local music files,
// with the cross-origin-isolation headers the low-latency audio engine needs.
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');

const COI_HEADERS = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'X-Content-Type-Options': 'nosniff',
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function parseRange(header, size) {
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(header || '').trim());
  if (!m || (m[1] === '' && m[2] === '')) return null;
  let start;
  let end;
  if (m[1] === '') {
    start = Math.max(0, size - parseInt(m[2], 10));
    end = size - 1;
  } else {
    start = parseInt(m[1], 10);
    end = m[2] === '' ? size - 1 : Math.min(size - 1, parseInt(m[2], 10));
  }
  return { start, end };
}

function createAppProtocolHandler({ rendererDir, library }) {
  const root = path.resolve(rendererDir);

  async function serveMedia(request, id) {
    const file = library.pathFor(id);
    if (!file) return new Response('not found', { status: 404 });
    const { size } = await fs.promises.stat(file);
    const type = library.mimeFor(id);
    const base = { 'Content-Type': type, 'Accept-Ranges': 'bytes', ...COI_HEADERS };
    const r = request.headers.get('range') ? parseRange(request.headers.get('range'), size) : null;
    if (request.headers.get('range')) {
      if (!r || r.start >= size || r.start > r.end) {
        return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}`, ...base } });
      }
      const stream = fs.createReadStream(file, { start: r.start, end: r.end });
      return new Response(Readable.toWeb(stream), {
        status: 206,
        headers: { ...base, 'Content-Range': `bytes ${r.start}-${r.end}/${size}`, 'Content-Length': String(r.end - r.start + 1) },
      });
    }
    return new Response(Readable.toWeb(fs.createReadStream(file)), { status: 200, headers: { ...base, 'Content-Length': String(size) } });
  }

  return async function handle(request) {
    const url = new URL(request.url);
    let p = decodeURIComponent(url.pathname);
    try {
      if (p.startsWith('/media/')) return await serveMedia(request, p.slice(7));
      if (p.startsWith('/cover/')) {
        const file = library.coverPath(p.slice(7));
        if (!file) return new Response('not found', { status: 404 });
        const data = await fs.promises.readFile(file);
        return new Response(data, {
          headers: { 'Content-Type': file.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'max-age=31536000', ...COI_HEADERS },
        });
      }
      if (p === '/' || p === '') p = '/index.html';
      const file = path.normalize(path.join(root, p));
      if (!file.startsWith(root + path.sep)) return new Response('forbidden', { status: 403 });
      const data = await fs.promises.readFile(file);
      return new Response(data, {
        headers: { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...COI_HEADERS },
      });
    } catch (err) {
      return new Response('not found', { status: 404 });
    }
  };
}

module.exports = { createAppProtocolHandler, parseRange, COI_HEADERS };
