'use strict';
// Dependency-free audio metadata reader: MP3 (ID3v1/v2 + duration), M4A/MP4/AAC/ALAC,
// FLAC, OGG Vorbis/Opus and WAV. Returns title/artist/album/track/year/duration/picture.
const fs = require('fs');
const path = require('path');

const MAX_TAG = 32 * 1024 * 1024;

async function readTags(filePath) {
  const fh = await fs.promises.open(filePath, 'r');
  try {
    const { size } = await fh.stat();
    const head = await readAt(fh, 0, Math.min(size, 64));
    const ext = path.extname(filePath).toLowerCase();
    let info = {};
    if (head.slice(0, 3).toString('latin1') === 'ID3' && ext === '.flac') {
      // rare: FLAC with an ID3v2 tag glued to the front
      const id3 = await readMp3(fh, size, head);
      const flac = await readFlac(fh, size, id3._audioStart || 0);
      info = { ...id3, ...flac, duration: flac.duration };
    } else if (head.slice(0, 3).toString('latin1') === 'ID3' || ext === '.mp3') {
      info = await readMp3(fh, size, head);
    } else if (head.slice(0, 4).toString('latin1') === 'fLaC') {
      info = await readFlac(fh, size, 0);
    } else if (head.slice(4, 8).toString('latin1') === 'ftyp') {
      info = await readMp4(fh, size);
    } else if (head.slice(0, 4).toString('latin1') === 'OggS') {
      info = await readOgg(fh, size);
    } else if (head.slice(0, 4).toString('latin1') === 'RIFF' && head.slice(8, 12).toString('latin1') === 'WAVE') {
      info = await readWav(fh, size);
    }
    delete info._audioStart;
    return finalize(info, filePath);
  } catch (err) {
    return finalize({}, filePath);
  } finally {
    await fh.close();
  }
}

function finalize(info, filePath) {
  const fromName = parseFilename(filePath);
  const clean = (s) => (typeof s === 'string' ? s.replace(/\u0000+$/g, '').trim() : s);
  return {
    title: clean(info.title) || fromName.title,
    artist: clean(info.artist) || clean(info.albumArtist) || fromName.artist || 'Unknown Artist',
    album: clean(info.album) || path.basename(path.dirname(filePath)) || 'Unknown Album',
    albumArtist: clean(info.albumArtist) || clean(info.artist) || fromName.artist || '',
    track: Number.isFinite(info.track) ? info.track : fromName.track,
    year: clean(info.year) ? String(clean(info.year)).slice(0, 4) : '',
    duration: Number.isFinite(info.duration) && info.duration > 0 ? info.duration : 0,
    picture: info.picture && info.picture.data && info.picture.data.length > 32 ? info.picture : null,
  };
}

function parseFilename(filePath) {
  let base = path.basename(filePath, path.extname(filePath)).replace(/_/g, ' ').trim();
  let track = null;
  const tm = /^(\d{1,3})[\s.\-_)]+(.+)$/.exec(base);
  if (tm) {
    track = parseInt(tm[1], 10);
    base = tm[2];
  }
  const parts = base.split(/\s+[-–—]\s+/);
  if (parts.length >= 2) return { artist: parts[0].trim(), title: parts.slice(1).join(' - ').trim(), track };
  return { artist: '', title: base, track };
}

async function readAt(fh, pos, len) {
  const buf = Buffer.alloc(Math.max(0, len));
  if (len <= 0) return buf;
  const { bytesRead } = await fh.read(buf, 0, len, pos);
  return bytesRead < len ? buf.subarray(0, bytesRead) : buf;
}

// ---------------------------------------------------------------- text decoding
function decodeText(buf, enc) {
  if (!buf || !buf.length) return '';
  let s;
  switch (enc) {
    case 1: // UTF-16 with BOM
      if (buf[0] === 0xfe && buf[1] === 0xff) s = utf16be(buf.subarray(2));
      else if (buf[0] === 0xff && buf[1] === 0xfe) s = buf.subarray(2).toString('utf16le');
      else s = buf.toString('utf16le');
      break;
    case 2:
      s = utf16be(buf);
      break;
    case 3:
      s = buf.toString('utf8');
      break;
    default:
      s = buf.toString('latin1');
  }
  return s.split('\u0000')[0];
}

function utf16be(buf) {
  const b = Buffer.from(buf.subarray(0, buf.length - (buf.length % 2)));
  b.swap16();
  return b.toString('utf16le');
}

function findTerminator(buf, start, enc) {
  if (enc === 1 || enc === 2) {
    for (let i = start; i + 1 < buf.length; i += 2) if (buf[i] === 0 && buf[i + 1] === 0) return i;
    return buf.length;
  }
  const i = buf.indexOf(0, start);
  return i === -1 ? buf.length : i;
}

const syncsafe = (b, o) => ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f);

function unsync(buf) {
  const out = Buffer.alloc(buf.length);
  let j = 0;
  for (let i = 0; i < buf.length; i++) {
    out[j++] = buf[i];
    if (buf[i] === 0xff && buf[i + 1] === 0x00) i++;
  }
  return out.subarray(0, j);
}

// ---------------------------------------------------------------- MP3 / ID3
async function readMp3(fh, size, head) {
  const info = {};
  let audioStart = 0;
  if (head.slice(0, 3).toString('latin1') === 'ID3') {
    const ver = head[3];
    const flags = head[5];
    const tagSize = syncsafe(head, 6);
    audioStart = 10 + tagSize + (flags & 0x10 ? 10 : 0);
    if (tagSize > 0 && tagSize < MAX_TAG) {
      let data = await readAt(fh, 10, tagSize);
      if (flags & 0x80 && ver < 4) data = unsync(data);
      parseId3Frames(data, ver, flags, info);
    }
    // Some files have more than one ID3 tag stacked; skip padding to the first sync word below.
  }
  if (!info.title || !info.artist) {
    if (size > 128) {
      const v1 = await readAt(fh, size - 128, 128);
      if (v1.slice(0, 3).toString('latin1') === 'TAG') {
        const t = (a, b) => v1.subarray(a, b).toString('latin1').replace(/\u0000.*$/, '').trim();
        info.title = info.title || t(3, 33);
        info.artist = info.artist || t(33, 63);
        info.album = info.album || t(63, 93);
        info.year = info.year || t(93, 97);
        if (v1[125] === 0 && v1[126] > 0 && !info.track) info.track = v1[126];
      }
    }
  }
  try {
    info.duration = await mp3Duration(fh, size, audioStart);
  } catch (_) {}
  info._audioStart = audioStart;
  return info;
}

function parseId3Frames(data, ver, flags, info) {
  let pos = 0;
  if (flags & 0x40) {
    // extended header
    if (ver === 3) pos = 4 + data.readUInt32BE(0);
    else if (ver === 4) pos = syncsafe(data, 0);
  }
  const idLen = ver === 2 ? 3 : 4;
  const hdrLen = ver === 2 ? 6 : 10;
  const pictures = [];
  while (pos + hdrLen <= data.length) {
    const id = data.subarray(pos, pos + idLen).toString('latin1');
    if (!/^[A-Z0-9]{3,4}$/.test(id)) break;
    let fsize;
    if (ver === 2) fsize = (data[pos + 3] << 16) | (data[pos + 4] << 8) | data[pos + 5];
    else if (ver === 4) fsize = syncsafe(data, pos + 4);
    else fsize = data.readUInt32BE(pos + 4);
    const fflags = ver === 2 ? 0 : data.readUInt16BE(pos + 8);
    pos += hdrLen;
    if (fsize <= 0 || pos + fsize > data.length) break;
    let body = data.subarray(pos, pos + fsize);
    pos += fsize;
    if (ver === 4) {
      if (fflags & 0x0001) body = body.subarray(4); // data length indicator
      if (fflags & 0x0002) body = unsync(body);
      if (fflags & 0x0008 || fflags & 0x0004) continue; // compressed / encrypted: skip
    } else if (ver === 3 && fflags & 0x00c0) {
      continue; // compressed / encrypted
    }
    const text = () => decodeText(body.subarray(1), body[0]);
    switch (id) {
      case 'TIT2':
      case 'TT2':
        info.title = text();
        break;
      case 'TPE1':
      case 'TP1':
        info.artist = text();
        break;
      case 'TALB':
      case 'TAL':
        info.album = text();
        break;
      case 'TPE2':
      case 'TP2':
        info.albumArtist = text();
        break;
      case 'TRCK':
      case 'TRK': {
        const n = parseInt(text(), 10);
        if (Number.isFinite(n)) info.track = n;
        break;
      }
      case 'TYER':
      case 'TYE':
      case 'TDRC':
        info.year = text();
        break;
      case 'APIC': {
        const enc = body[0];
        const mEnd = body.indexOf(0, 1);
        if (mEnd < 0) break;
        let mime = body.subarray(1, mEnd).toString('latin1') || 'image/jpeg';
        if (!mime.includes('/')) mime = 'image/' + mime.toLowerCase().replace('jpg', 'jpeg');
        const type = body[mEnd + 1];
        const dEnd = findTerminator(body, mEnd + 2, enc);
        const start = dEnd + (enc === 1 || enc === 2 ? 2 : 1);
        pictures.push({ type, mime, data: Buffer.from(body.subarray(start)) });
        break;
      }
      case 'PIC': {
        const enc = body[0];
        const fmt = body.subarray(1, 4).toString('latin1').toLowerCase();
        const type = body[4];
        const dEnd = findTerminator(body, 5, enc);
        const start = dEnd + (enc === 1 || enc === 2 ? 2 : 1);
        pictures.push({ type, mime: fmt === 'png' ? 'image/png' : 'image/jpeg', data: Buffer.from(body.subarray(start)) });
        break;
      }
      default:
    }
  }
  if (pictures.length) info.picture = pictures.find((p) => p.type === 3) || pictures[0];
}

const MP3_BITRATES = {
  // [versionKey][layer] -> kbps table
  V1L1: [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
  V1L2: [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
  V1L3: [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
  V2L1: [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
  V2L2: [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
};
const MP3_RATES = { 3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000] };

async function mp3Duration(fh, size, audioStart) {
  const buf = await readAt(fh, audioStart, Math.min(size - audioStart, 256 * 1024));
  for (let i = 0; i + 4 < buf.length; i++) {
    if (buf[i] !== 0xff || (buf[i + 1] & 0xe0) !== 0xe0) continue;
    const verBits = (buf[i + 1] >> 3) & 3; // 3=V1, 2=V2, 0=V2.5
    const layerBits = (buf[i + 1] >> 1) & 3; // 3=L1, 2=L2, 1=L3
    const brIdx = buf[i + 2] >> 4;
    const srIdx = (buf[i + 2] >> 2) & 3;
    if (verBits === 1 || layerBits === 0 || brIdx === 0 || brIdx === 15 || srIdx === 3) continue;
    const layer = 4 - layerBits;
    const v1 = verBits === 3;
    const key = v1 ? `V1L${layer}` : layer === 1 ? 'V2L1' : 'V2L2';
    const bitrate = MP3_BITRATES[key][brIdx] * 1000;
    const sampleRate = MP3_RATES[verBits][srIdx];
    const mono = (buf[i + 3] >> 6) === 3;
    const spf = layer === 1 ? 384 : layer === 3 && !v1 ? 576 : 1152;
    // sanity check: next frame header should follow
    const padding = (buf[i + 2] >> 1) & 1;
    const frameLen = layer === 1 ? Math.floor((12 * bitrate) / sampleRate + padding) * 4 : Math.floor((spf / 8) * bitrate / sampleRate) + padding;
    const nx = i + frameLen;
    if (nx + 1 < buf.length && !(buf[nx] === 0xff && (buf[nx + 1] & 0xe0) === 0xe0)) continue;
    const sideInfo = v1 ? (mono ? 17 : 32) : mono ? 9 : 17;
    const xo = i + 4 + sideInfo;
    const tag = buf.subarray(xo, xo + 4).toString('latin1');
    if ((tag === 'Xing' || tag === 'Info') && xo + 12 <= buf.length) {
      const fl = buf.readUInt32BE(xo + 4);
      if (fl & 1) {
        const frames = buf.readUInt32BE(xo + 8);
        if (frames > 0) return (frames * spf) / sampleRate;
      }
    }
    const vo = i + 4 + 32;
    if (buf.subarray(vo, vo + 4).toString('latin1') === 'VBRI' && vo + 18 <= buf.length) {
      const frames = buf.readUInt32BE(vo + 14);
      if (frames > 0) return (frames * spf) / sampleRate;
    }
    const audioBytes = size - (audioStart + i);
    return (audioBytes * 8) / bitrate;
  }
  return 0;
}

// ---------------------------------------------------------------- MP4 / M4A
async function readMp4(fh, size) {
  const info = {};
  let pos = 0;
  let moov = null;
  while (pos + 8 <= size) {
    const h = await readAt(fh, pos, 16);
    if (h.length < 8) break;
    let asize = h.readUInt32BE(0);
    const type = h.subarray(4, 8).toString('latin1');
    let hdr = 8;
    if (asize === 1) {
      asize = Number(h.readBigUInt64BE(8));
      hdr = 16;
    } else if (asize === 0) asize = size - pos;
    if (asize < hdr) break;
    if (type === 'moov') {
      if (asize > MAX_TAG * 2) break;
      moov = await readAt(fh, pos + hdr, asize - hdr);
      break;
    }
    pos += asize;
  }
  if (!moov) return info;
  const mvhd = findAtom(moov, ['mvhd']);
  if (mvhd) {
    const v = mvhd[0];
    if (v === 1 && mvhd.length >= 32) {
      const ts = mvhd.readUInt32BE(20);
      const dur = Number(mvhd.readBigUInt64BE(24));
      if (ts) info.duration = dur / ts;
    } else if (mvhd.length >= 20) {
      const ts = mvhd.readUInt32BE(12);
      const dur = mvhd.readUInt32BE(16);
      if (ts) info.duration = dur / ts;
    }
  }
  let meta = findAtom(moov, ['udta', 'meta']);
  if (!meta) return info;
  // 'meta' is a full box (4 bytes version/flags) in iTunes files, but not in QuickTime-style files.
  if (meta.subarray(4, 8).toString('latin1') !== 'hdlr') meta = meta.subarray(4);
  const ilst = findAtom(meta, ['ilst']);
  if (!ilst) return info;
  eachAtom(ilst, (type, body) => {
    const data = findAtom(body, ['data']);
    if (!data || data.length < 8) return;
    const dtype = data.readUInt32BE(0) & 0xffffff;
    const payload = data.subarray(8);
    const str = () => payload.toString('utf8');
    switch (type) {
      case '©nam':
        info.title = str();
        break;
      case '©ART':
        info.artist = str();
        break;
      case '©alb':
        info.album = str();
        break;
      case 'aART':
        info.albumArtist = str();
        break;
      case '©day':
        info.year = str();
        break;
      case 'trkn':
        if (payload.length >= 4) info.track = payload.readUInt16BE(2);
        break;
      case 'covr':
        info.picture = { type: 3, mime: dtype === 14 ? 'image/png' : 'image/jpeg', data: Buffer.from(payload) };
        break;
      default:
    }
  });
  return info;
}

function eachAtom(buf, fn) {
  let pos = 0;
  while (pos + 8 <= buf.length) {
    let size = buf.readUInt32BE(pos);
    const type = buf.subarray(pos + 4, pos + 8).toString('latin1');
    let hdr = 8;
    if (size === 1 && pos + 16 <= buf.length) {
      size = Number(buf.readBigUInt64BE(pos + 8));
      hdr = 16;
    } else if (size === 0) size = buf.length - pos;
    if (size < hdr || pos + size > buf.length) break;
    if (fn(type, buf.subarray(pos + hdr, pos + size)) === false) return;
    pos += size;
  }
}

function findAtom(buf, pathParts) {
  let cur = buf;
  for (const part of pathParts) {
    let found = null;
    eachAtom(cur, (type, body) => {
      if (type === part) {
        found = body;
        return false;
      }
      return undefined;
    });
    if (!found) return null;
    cur = found;
  }
  return cur;
}

// ---------------------------------------------------------------- FLAC
async function readFlac(fh, size, start) {
  const info = {};
  let pos = start;
  const magic = await readAt(fh, pos, 4);
  if (magic.toString('latin1') !== 'fLaC') return info;
  pos += 4;
  const pictures = [];
  for (let guard = 0; guard < 64 && pos + 4 <= size; guard++) {
    const h = await readAt(fh, pos, 4);
    const last = (h[0] & 0x80) !== 0;
    const type = h[0] & 0x7f;
    const len = (h[1] << 16) | (h[2] << 8) | h[3];
    pos += 4;
    if (type === 0 && len >= 18) {
      const b = await readAt(fh, pos, len);
      const sr = (b[10] << 12) | (b[11] << 4) | (b[12] >> 4);
      const total = (b[13] & 0x0f) * 2 ** 32 + b.readUInt32BE(14);
      if (sr > 0 && total > 0) info.duration = total / sr;
    } else if (type === 4 && len < MAX_TAG) {
      const b = await readAt(fh, pos, len);
      parseVorbisComments(b, 0, info, pictures);
    } else if (type === 6 && len < MAX_TAG) {
      const b = await readAt(fh, pos, len);
      const pic = parseFlacPicture(b);
      if (pic) pictures.push(pic);
    }
    pos += len;
    if (last) break;
  }
  if (pictures.length && !info.picture) info.picture = pictures.find((p) => p.type === 3) || pictures[0];
  return info;
}

function parseFlacPicture(b) {
  try {
    let o = 0;
    const type = b.readUInt32BE(o);
    o += 4;
    const ml = b.readUInt32BE(o);
    o += 4;
    const mime = b.subarray(o, o + ml).toString('latin1');
    o += ml;
    const dl = b.readUInt32BE(o);
    o += 4 + dl + 16;
    const len = b.readUInt32BE(o);
    o += 4;
    return { type, mime: mime || 'image/jpeg', data: Buffer.from(b.subarray(o, o + len)) };
  } catch (_) {
    return null;
  }
}

function parseVorbisComments(b, o, info, pictures) {
  try {
    const vlen = b.readUInt32LE(o);
    o += 4 + vlen;
    const count = b.readUInt32LE(o);
    o += 4;
    for (let i = 0; i < count && o + 4 <= b.length; i++) {
      const len = b.readUInt32LE(o);
      o += 4;
      const s = b.subarray(o, o + len).toString('utf8');
      o += len;
      const eq = s.indexOf('=');
      if (eq < 0) continue;
      const key = s.slice(0, eq).toUpperCase();
      const val = s.slice(eq + 1);
      if (key === 'TITLE' && !info.title) info.title = val;
      else if (key === 'ARTIST' && !info.artist) info.artist = val;
      else if (key === 'ALBUM' && !info.album) info.album = val;
      else if (key === 'ALBUMARTIST' && !info.albumArtist) info.albumArtist = val;
      else if (key === 'TRACKNUMBER' && !info.track) info.track = parseInt(val, 10) || undefined;
      else if ((key === 'DATE' || key === 'YEAR') && !info.year) info.year = val;
      else if (key === 'METADATA_BLOCK_PICTURE' && pictures) {
        const pic = parseFlacPicture(Buffer.from(val, 'base64'));
        if (pic) pictures.push(pic);
      }
    }
  } catch (_) {}
}

// ---------------------------------------------------------------- OGG Vorbis / Opus
async function readOgg(fh, size) {
  const info = {};
  const buf = await readAt(fh, 0, Math.min(size, 4 * 1024 * 1024));
  const packets = [];
  let pos = 0;
  let cur = [];
  while (pos + 27 <= buf.length && packets.length < 3) {
    if (buf.subarray(pos, pos + 4).toString('latin1') !== 'OggS') break;
    const nseg = buf[pos + 26];
    const table = buf.subarray(pos + 27, pos + 27 + nseg);
    let dpos = pos + 27 + nseg;
    for (let i = 0; i < nseg; i++) {
      const l = table[i];
      cur.push(buf.subarray(dpos, dpos + l));
      dpos += l;
      if (l < 255) {
        packets.push(Buffer.concat(cur));
        cur = [];
        if (packets.length >= 3) break;
      }
    }
    pos = dpos;
  }
  let sampleRate = 48000;
  let preSkip = 0;
  const pictures = [];
  if (packets[0]) {
    const p0 = packets[0];
    if (p0.subarray(1, 7).toString('latin1') === 'vorbis') sampleRate = p0.readUInt32LE(12);
    else if (p0.subarray(0, 8).toString('latin1') === 'OpusHead') preSkip = p0.readUInt16LE(10);
  }
  if (packets[1]) {
    const p1 = packets[1];
    if (p1.subarray(1, 7).toString('latin1') === 'vorbis') parseVorbisComments(p1, 7, info, pictures);
    else if (p1.subarray(0, 8).toString('latin1') === 'OpusTags') parseVorbisComments(p1, 8, info, pictures);
  }
  if (pictures.length) info.picture = pictures.find((p) => p.type === 3) || pictures[0];
  // duration: granule position of the last page
  const tailLen = Math.min(size, 65536);
  const tail = await readAt(fh, size - tailLen, tailLen);
  const idx = tail.lastIndexOf('OggS');
  if (idx >= 0 && idx + 14 <= tail.length) {
    const gran = Number(tail.readBigInt64LE(idx + 6));
    if (gran > 0) info.duration = (gran - preSkip) / sampleRate;
  }
  return info;
}

// ---------------------------------------------------------------- WAV
async function readWav(fh, size) {
  const info = {};
  let pos = 12;
  let byteRate = 0;
  while (pos + 8 <= size) {
    const h = await readAt(fh, pos, 8);
    const id = h.subarray(0, 4).toString('latin1');
    const len = h.readUInt32LE(4);
    if (id === 'fmt ') {
      const b = await readAt(fh, pos + 8, Math.min(len, 32));
      byteRate = b.readUInt32LE(8);
    } else if (id === 'data') {
      if (byteRate) info.duration = Math.min(len, size - pos - 8) / byteRate;
    } else if (id === 'LIST' && len < 1024 * 1024) {
      const b = await readAt(fh, pos + 8, len);
      if (b.subarray(0, 4).toString('latin1') === 'INFO') {
        let o = 4;
        while (o + 8 <= b.length) {
          const sid = b.subarray(o, o + 4).toString('latin1');
          const sl = b.readUInt32LE(o + 4);
          const val = b.subarray(o + 8, o + 8 + sl).toString('utf8').replace(/\u0000+$/, '');
          if (sid === 'INAM') info.title = val;
          else if (sid === 'IART') info.artist = val;
          else if (sid === 'IPRD') info.album = val;
          o += 8 + sl + (sl & 1);
        }
      }
    }
    pos += 8 + len + (len & 1);
  }
  return info;
}

module.exports = { readTags, parseFilename };
