'use strict';
// Windows: long-running PowerShell helper that speaks to the System Media Transport Controls.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

class WinMedia {
  constructor() {
    this.proc = null;
    this.ready = null;
    this.pending = new Map();
    this.seq = 0;
    this.buf = '';
    this.failures = 0;
    this.lastError = null;
  }

  _scriptPath() {
    // The script lives inside app.asar; PowerShell can't read from there, so copy it out.
    const src = path.join(__dirname, 'smtc.ps1');
    const dst = path.join(os.tmpdir(), 'unison-smtc-v1.ps1');
    const text = '﻿' + fs.readFileSync(src, 'utf8').replace(/^﻿/, ''); // BOM so PS 5.1 reads UTF-8
    try {
      if (!fs.existsSync(dst) || fs.readFileSync(dst, 'utf8') !== text) fs.writeFileSync(dst, text, 'utf8');
    } catch (_) {
      fs.writeFileSync(dst, text, 'utf8');
    }
    return dst;
  }

  start() {
    if (this.ready) return this.ready;
    if (process.platform !== 'win32') return Promise.reject(new Error('Windows only'));
    this.ready = new Promise((resolve, reject) => {
      let script;
      try {
        script = this._scriptPath();
      } catch (e) {
        reject(e);
        return;
      }
      const ps = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], {
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      this.proc = ps;
      let started = false;
      const bootTimer = setTimeout(() => {
        if (!started) {
          reject(new Error('Windows media controls took too long to start.'));
          this.stop();
        }
      }, 15000);
      ps.stdout.setEncoding('utf8');
      ps.stdout.on('data', (chunk) => {
        this.buf += chunk;
        let nl;
        while ((nl = this.buf.indexOf('\n')) >= 0) {
          const line = this.buf.slice(0, nl).trim();
          this.buf = this.buf.slice(nl + 1);
          if (!line) continue;
          let msg;
          try {
            msg = JSON.parse(line.replace(/^﻿/, ''));
          } catch (_) {
            continue;
          }
          if (!started && 'ready' in msg) {
            started = true;
            clearTimeout(bootTimer);
            if (msg.ready) {
              this.failures = 0;
              resolve(true);
            } else {
              this.lastError = msg.error;
              reject(new Error(`Windows media controls unavailable: ${msg.error}`));
            }
            continue;
          }
          const p = this.pending.get(msg.id);
          if (p) {
            this.pending.delete(msg.id);
            clearTimeout(p.timer);
            p.resolve(msg);
          }
        }
      });
      ps.stderr.on('data', (d) => {
        this.lastError = String(d).slice(0, 500);
      });
      ps.on('exit', () => {
        clearTimeout(bootTimer);
        if (!started) reject(new Error(this.lastError || 'PowerShell exited'));
        for (const [, p] of this.pending) {
          clearTimeout(p.timer);
          p.resolve({ ok: false, error: 'media helper stopped' });
        }
        this.pending.clear();
        this.proc = null;
        this.ready = null;
        this.failures++;
      });
      ps.on('error', (e) => {
        clearTimeout(bootTimer);
        reject(e);
      });
    });
    this.ready.catch(() => {
      this.ready = null;
    });
    return this.ready;
  }

  async call(req) {
    const allowed = ['state', 'art', 'sessions', 'playpause', 'play', 'pause', 'next', 'prev', 'seek', 'shuffle', 'repeat'];
    if (!req || !allowed.includes(req.cmd)) throw new Error('Unknown media command');
    if (this.failures > 4) return { ok: false, error: this.lastError || 'Windows media controls keep failing' };
    await this.start();
    const id = ++this.seq;
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        resolve({ ok: false, error: 'timeout' });
      }, 8000);
      this.pending.set(id, { resolve, timer });
      const clean = {
        id,
        cmd: req.cmd,
        prefer: typeof req.prefer === 'string' ? req.prefer.replace(/[^\w.\-!]/g, '') : '',
        // never report Unison itself (its own media session) as "the app that is playing"
        exclude: 'unison|electron.app|app.unison',
      };
      if (req.value !== undefined) clean.value = req.value;
      try {
        this.proc.stdin.write(JSON.stringify(clean) + '\n');
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        resolve({ ok: false, error: e.message });
      }
    });
  }

  stop() {
    try {
      if (this.proc) this.proc.kill();
    } catch (_) {}
    this.proc = null;
    this.ready = null;
  }
}

module.exports = { WinMedia };
