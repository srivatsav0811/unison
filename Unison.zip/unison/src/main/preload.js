'use strict';
// Safe bridge between the UI and the main process.
const { contextBridge, ipcRenderer, webUtils } = require('electron');

const invoke = (ch, ...args) => ipcRenderer.invoke(ch, ...args);
const on = (ch, fn) => {
  const h = (_e, payload) => fn(payload);
  ipcRenderer.on(ch, h);
  return () => ipcRenderer.removeListener(ch, h);
};

contextBridge.exposeInMainWorld('unison', {
  isDesktop: true,
  platform: process.platform,
  info: () => invoke('app:info'),
  settings: {
    get: () => invoke('settings:get'),
    set: (patch) => invoke('settings:set', patch),
    replace: (key, value) => invoke('settings:replaceKey', key, value),
  },
  shell: {
    open: (url) => invoke('shell:open', url),
    settings: (which) => invoke('shell:settings', which),
  },
  mic: { ask: () => invoke('mic:ask') },
  power: { playing: (b) => invoke('power:playing', !!b) },
  win: { onState: (fn) => on('win:state', fn) },
  library: {
    list: () => invoke('library:list'),
    pickFolder: () => invoke('library:pickFolder'),
    pickFiles: () => invoke('library:pickFiles'),
    addPaths: (paths) => invoke('library:addPaths', paths),
    removeFolder: (f) => invoke('library:removeFolder', f),
    rescan: () => invoke('library:rescan'),
    onProgress: (fn) => on('library:progress', fn),
    pathForFile: (file) => {
      try {
        return webUtils.getPathForFile(file);
      } catch (_) {
        return null;
      }
    },
  },
  spotify: {
    status: () => invoke('spotify:status'),
    connect: (clientId) => invoke('spotify:connect', clientId),
    cancel: () => invoke('spotify:cancel'),
    disconnect: () => invoke('spotify:disconnect'),
    api: (method, path, opts) => invoke('spotify:api', method, path, opts),
  },
  art: { fetch: (url) => invoke('art:fetch', url) },
  apple: { call: (cmd, arg) => invoke('apple:call', cmd, arg) },
  winmedia: { call: (req) => invoke('winmedia:call', req) },
  itunes: { search: (q, country) => invoke('itunes:search', q, country) },
  net: { online: () => invoke('net:online') },
});
