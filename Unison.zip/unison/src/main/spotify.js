'use strict';
// Spotify Web API bridge: Authorization Code + PKCE (no client secret), token refresh,
// a restricted API proxy for the renderer, and cached album-art fetching.
const http = require('http');
const crypto = require('crypto');

const REDIRECT_PORT = 43821;
const REDIRECT_URI = `http://127.0.0.1:${REDIRECT_PORT}/callback`;
const API = 'https://api.spotify.com/v1';
const SCOPES = [
  'user-read-playback-state',
  'user-modify-playback-state',
  'user-read-currently-playing',
  'user-read-recently-played',
  'playlist-read-private',
  'playlist-read-collaborative',
  'user-library-read',
  'user-read-private',
];

const b64url = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

class SpotifyBridge {
  constructor({ store, openExternal, fetchImpl, encrypt, decrypt }) {
    this.store = store;
    this.openExternal = openExternal;
    this.fetch = fetchImpl || globalThis.fetch;
    this.encrypt = encrypt || ((s) => ({ plain: s }));
    this.decrypt = decrypt || ((o) => (o && o.plain) || null);
    this.access = null; // { token, expiresAt }
    this.pending = null;
    this.artCache = new Map();
  }

  get clientId() {
    return (this.store.get('spotify.clientId') || '').trim();
  }

  get refreshToken() {
    const enc = this.store.get('spotify.refresh');
    try {
      return enc ? this.decrypt(enc) : null;
    } catch (_) {
      return null;
    }
  }

  set refreshToken(v) {
    this.store.set('spotify.refresh', v ? this.encrypt(v) : null);
  }

  status() {
    return {
      clientId: this.clientId,
      configured: !!this.clientId,
      connected: !!this.refreshToken,
      redirectUri: REDIRECT_URI,
      profile: this.store.get('spotify.profile') || null,
      scopes: SCOPES,
    };
  }

  async connect(clientId) {
    clientId = (clientId || this.clientId || '').trim();
    if (!/^[a-zA-Z0-9]{16,64}$/.test(clientId)) throw new Error('That does not look like a Spotify Client ID (32 letters/numbers from your Spotify developer dashboard).');
    this.store.set('spotify.clientId', clientId);
    if (this.pending) this.pending.cancel('Started a new sign-in.');

    const verifier = b64url(crypto.randomBytes(64));
    const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
    const state = b64url(crypto.randomBytes(16));

    const code = await new Promise((resolve, reject) => {
      const server = http.createServer((req, res) => {
        const u = new URL(req.url, REDIRECT_URI);
        if (u.pathname !== '/callback') {
          res.writeHead(404).end();
          return;
        }
        const err = u.searchParams.get('error');
        const ok = !err && u.searchParams.get('state') === state && u.searchParams.get('code');
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(callbackPage(ok ? null : err || 'state mismatch'));
        finish(ok ? null : new Error(err === 'access_denied' ? 'Spotify sign-in was cancelled.' : `Spotify sign-in failed (${err || 'state mismatch'}).`), u.searchParams.get('code'));
      });
      const timer = setTimeout(() => finish(new Error('Timed out waiting for Spotify sign-in.')), 5 * 60 * 1000);
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        setTimeout(() => server.close(), 500);
        this.pending = null;
        if (error) reject(error);
        else resolve(value);
      };
      this.pending = { cancel: (why) => finish(new Error(why)) };
      server.on('error', (e) =>
        finish(new Error(e.code === 'EADDRINUSE' ? `Port ${REDIRECT_PORT} is busy. Close other Unison windows and try again.` : e.message))
      );
      server.listen(REDIRECT_PORT, '127.0.0.1', () => {
        const q = new URLSearchParams({
          response_type: 'code',
          client_id: clientId,
          scope: SCOPES.join(' '),
          redirect_uri: REDIRECT_URI,
          code_challenge_method: 'S256',
          code_challenge: challenge,
          state,
        });
        this.openExternal(`https://accounts.spotify.com/authorize?${q}`);
      });
    });

    const tok = await this._tokenRequest({
      grant_type: 'authorization_code',
      code,
      redirect_uri: REDIRECT_URI,
      client_id: clientId,
      code_verifier: verifier,
    });
    this._acceptTokens(tok);
    try {
      const me = await this.api('GET', '/me');
      if (me.ok) {
        this.store.set('spotify.profile', {
          id: me.data.id,
          name: me.data.display_name || me.data.id,
          image: me.data.images && me.data.images[0] ? me.data.images[0].url : null,
        });
      }
    } catch (_) {}
    return this.status();
  }

  cancel() {
    if (this.pending) this.pending.cancel('Sign-in cancelled.');
  }

  disconnect() {
    this.refreshToken = null;
    this.access = null;
    this.store.set('spotify.profile', null);
    return this.status();
  }

  async _tokenRequest(params) {
    const res = await this.fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params).toString(),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error_description || data.error || `HTTP ${res.status}`;
      const e = new Error(`Spotify token error: ${msg}`);
      e.code = data.error;
      throw e;
    }
    return data;
  }

  _acceptTokens(tok) {
    this.access = { token: tok.access_token, expiresAt: Date.now() + (tok.expires_in || 3600) * 1000 };
    if (tok.refresh_token) this.refreshToken = tok.refresh_token;
  }

  async token(force = false) {
    if (!force && this.access && this.access.expiresAt - Date.now() > 60 * 1000) return this.access.token;
    const rt = this.refreshToken;
    if (!rt || !this.clientId) throw Object.assign(new Error('Spotify is not connected.'), { code: 'not_connected' });
    if (!this._refreshing) {
      this._refreshing = this._tokenRequest({ grant_type: 'refresh_token', refresh_token: rt, client_id: this.clientId })
        .then((tok) => {
          this._acceptTokens(tok);
          return this.access.token;
        })
        .catch((e) => {
          if (e.code === 'invalid_grant') this.refreshToken = null; // revoked: force reconnect
          throw e;
        })
        .finally(() => {
          this._refreshing = null;
        });
    }
    return this._refreshing;
  }

  /**
   * Restricted proxy to the Web API. Returns { ok, status, data, error }.
   */
  async api(method, p, { query, body } = {}, _retry = 0) {
    method = String(method || 'GET').toUpperCase();
    if (!['GET', 'PUT', 'POST', 'DELETE'].includes(method)) throw new Error('Bad method');
    let url;
    if (typeof p === 'string' && p.startsWith(API + '/')) url = new URL(p);
    else if (typeof p === 'string' && p.startsWith('/')) url = new URL(API + p);
    else throw new Error('Bad Spotify path');
    if (query) for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
    let token;
    try {
      token = await this.token();
    } catch (e) {
      return { ok: false, status: 401, error: e.message, code: e.code || 'not_connected' };
    }
    let res;
    try {
      res = await this.fetch(url.toString(), {
        method,
        headers: { Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch (e) {
      return { ok: false, status: 0, error: 'Network unavailable — Spotify needs an internet connection.', code: 'offline' };
    }
    if (res.status === 401 && _retry < 1) {
      try {
        await this.token(true);
      } catch (e) {
        return { ok: false, status: 401, error: e.message, code: 'not_connected' };
      }
      return this.api(method, p, { query, body }, _retry + 1);
    }
    if (res.status === 429 && _retry < 1) {
      const wait = Math.min(parseInt(res.headers.get('retry-after') || '2', 10) || 2, 8);
      await new Promise((r) => setTimeout(r, wait * 1000));
      return this.api(method, p, { query, body }, _retry + 1);
    }
    let data = null;
    const text = await res.text().catch(() => '');
    if (text) {
      try {
        data = JSON.parse(text);
      } catch (_) {
        data = text;
      }
    }
    if (!res.ok) {
      const err = data && data.error ? data.error : {};
      return {
        ok: false,
        status: res.status,
        error: (err.message || (typeof data === 'string' ? data : '') || `Spotify error ${res.status}`).toString(),
        reason: err.reason || null,
        data,
      };
    }
    return { ok: true, status: res.status, data };
  }

  /** Fetch cover art and return a data: URL (renderer CSP/COEP friendly). */
  async art(url) {
    if (typeof url !== 'string' || !/^https:\/\/([a-z0-9-]+\.)*(scdn\.co|spotifycdn\.com|mzstatic\.com|spotify\.com)\//i.test(url)) return null;
    if (this.artCache.has(url)) return this.artCache.get(url);
    try {
      const res = await this.fetch(url);
      if (!res.ok) return null;
      const type = res.headers.get('content-type') || 'image/jpeg';
      const buf = Buffer.from(await res.arrayBuffer());
      const dataUrl = `data:${type};base64,${buf.toString('base64')}`;
      this.artCache.set(url, dataUrl);
      if (this.artCache.size > 150) this.artCache.delete(this.artCache.keys().next().value);
      return dataUrl;
    } catch (_) {
      return null;
    }
  }
}

function callbackPage(error) {
  const title = error ? 'Spotify sign-in failed' : 'Unison is connected to Spotify';
  const body = error ? `Something went wrong (${String(error).replace(/[<>&]/g, '')}). Go back to Unison and try again.` : 'You can close this tab and go back to Unison.';
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(circle at 30% 20%,#3b1d7a,#07060f 60%);color:#f1eeff;font:16px system-ui,-apple-system,Segoe UI,sans-serif}
.card{padding:40px 48px;border-radius:28px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);backdrop-filter:blur(20px);text-align:center;max-width:420px}
h1{font-size:22px;margin:0 0 10px}p{opacity:.8;margin:0}.dot{width:56px;height:56px;border-radius:50%;margin:0 auto 18px;background:${error ? '#f43f5e' : 'linear-gradient(135deg,#8b5cf6,#22d3ee)'};box-shadow:0 0 40px ${error ? '#f43f5e88' : '#8b5cf688'}}</style>
</head><body><div class="card"><div class="dot"></div><h1>${title}</h1><p>${body}</p></div></body></html>`;
}

module.exports = { SpotifyBridge, REDIRECT_URI, REDIRECT_PORT, SCOPES };
