'use strict';
// Unison — main process.
const {
  app,
  BrowserWindow,
  ipcMain,
  protocol,
  session,
  shell,
  dialog,
  desktopCapturer,
  systemPreferences,
  safeStorage,
  nativeImage,
  powerSaveBlocker,
  Menu,
  net,
} = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { Store } = require('./store');
const { Library } = require('./library');
const { SpotifyBridge } = require('./spotify');
const { createAppProtocolHandler } = require('./protocol');

const IS_MAC = process.platform === 'darwin';
const IS_WIN = process.platform === 'win32';
const RENDERER = path.join(__dirname, '..', 'renderer');
const ORIGIN = 'app://unison';

// ---- Chromium switches -------------------------------------------------------------
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// SharedArrayBuffer powers the low-latency ring-buffer engine (we also send COOP/COEP).
app.commandLine.appendSwitch('enable-features', 'SharedArrayBuffer');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');

protocol.registerSchemesAsPrivileged([
  {
    scheme: 'app',
    privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true, codeCache: true },
  },
]);

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let win = null;
let store = null;
let library = null;
let spotify = null;
let apple = null;
let winMedia = null;
let powerBlockId = null;

const DEFAULTS = {
  firstRun: true,
  captureMode: IS_WIN ? 'loopbackWithMute' : 'device',
  captureDeviceLabel: '',
  micLabel: '',
  latencyMode: 'auto',
  engine: 'precision',
  sampleRate: 48000,
  masterVolume: 0.8,
  visuals: 'high',
  glass: true,
  reduceMotion: false,
  source: 'local',
  speakers: {},
  calibration: null,
  spotify: { clientId: '', refresh: null, profile: null },
  local: { shuffle: false, repeat: 'off', lastTrack: null, volume: 1 },
  guideDone: {},
  window: { width: 1380, height: 880 },
};

// ---- helpers -----------------------------------------------------------------------
function encryptSecret(s) {
  try {
    if (safeStorage.isEncryptionAvailable()) return { enc: safeStorage.encryptString(s).toString('base64') };
  } catch (_) {}
  return { plain: s };
}

function decryptSecret(o) {
  if (!o) return null;
  if (o.enc) return safeStorage.decryptString(Buffer.from(o.enc, 'base64'));
  return o.plain || null;
}

function resizeCover(buf) {
  const img = nativeImage.createFromBuffer(buf);
  if (img.isEmpty()) return null;
  const { width } = img.getSize();
  const out = width > 640 ? img.resize({ width: 640, quality: 'best' }) : img;
  return { data: out.toJPEG(88), ext: 'jpg' };
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

const EXTERNAL_OK = /^(https:|ms-settings:|x-apple\.systempreferences:|spotify:|music:|itmss?:)/i;

// ---- window ------------------------------------------------------------------------
function createWindow() {
  const saved = store.get('window') || {};
  win = new BrowserWindow({
    width: saved.width || 1380,
    height: saved.height || 880,
    x: saved.x,
    y: saved.y,
    minWidth: 1040,
    minHeight: 680,
    show: false,
    backgroundColor: '#07060f',
    title: 'Unison',
    icon: path.join(__dirname, '..', '..', 'build', 'icon.png'),
    titleBarStyle: 'hidden',
    ...(IS_MAC
      ? { trafficLightPosition: { x: 18, y: 18 } }
      : { titleBarOverlay: { color: '#00000000', symbolColor: '#e9e6ff', height: 46 } }),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      backgroundThrottling: false,
      spellcheck: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  if (saved.maximized) win.maximize();
  win.loadURL(`${ORIGIN}/index.html`);
  win.once('ready-to-show', () => win.show());

  const persistBounds = () => {
    if (!win || win.isDestroyed()) return;
    const maximized = win.isMaximized();
    const b = maximized ? store.get('window') : win.getBounds();
    store.set('window', { ...b, maximized });
  };
  win.on('resize', debounce(persistBounds, 400));
  win.on('move', debounce(persistBounds, 400));
  win.on('maximize', () => send('win:state', { maximized: true }));
  win.on('unmaximize', () => send('win:state', { maximized: false }));
  win.on('enter-full-screen', () => send('win:state', { fullscreen: true }));
  win.on('leave-full-screen', () => send('win:state', { fullscreen: false }));

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (EXTERNAL_OK.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith(ORIGIN)) {
      e.preventDefault();
      if (EXTERNAL_OK.test(url)) shell.openExternal(url);
    }
  });
  win.on('closed', () => {
    win = null;
  });
}

function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

function setupPermissions() {
  const ses = session.defaultSession;
  const allowed = new Set(['media', 'speaker-selection', 'display-capture', 'fullscreen', 'clipboard-sanitized-write', 'window-management']);
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    const fromApp = !details || !details.requestingUrl || details.requestingUrl.startsWith(ORIGIN);
    callback(fromApp && allowed.has(permission));
  });
  ses.setPermissionCheckHandler((wc, permission, origin) => {
    return (!origin || origin.startsWith(ORIGIN)) && allowed.has(permission);
  });
  // System-audio capture (Windows): no picker, grab the whole-system loopback.
  ses.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
      if (!sources.length) throw new Error('no screen source');
      const streams = { video: sources[0] };
      if (IS_WIN && request.audioRequested) {
        streams.audio = store.get('captureMode') === 'loopback' ? 'loopback' : 'loopbackWithMute';
      }
      callback(streams);
    } catch (err) {
      console.error('[capture]', err);
      callback({});
    }
  });
}

function buildMenu() {
  if (!IS_MAC) {
    Menu.setApplicationMenu(null);
    return;
  }
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      { role: 'appMenu' },
      { role: 'editMenu' },
      {
        label: 'View',
        submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }, { type: 'separator' }, { role: 'togglefullscreen' }],
      },
      { role: 'windowMenu' },
    ])
  );
}

// ---- IPC ---------------------------------------------------------------------------
function setupIpc() {
  const handle = (ch, fn) =>
    ipcMain.handle(ch, async (e, ...args) => {
      if (!e.senderFrame || !e.senderFrame.url.startsWith(ORIGIN)) throw new Error('blocked');
      return fn(...args);
    });

  handle('app:info', () => ({
    platform: process.platform,
    arch: process.arch,
    version: app.getVersion(),
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    hostname: os.hostname(),
    locale: app.getLocale(),
    country: (app.getLocaleCountryCode && app.getLocaleCountryCode()) || 'US',
    osRelease: os.release(),
  }));

  handle('settings:get', () => store.get());
  handle('settings:set', (patch) => {
    if (patch && typeof patch === 'object') {
      delete patch.spotify; // secrets are managed by the Spotify bridge only
      store.set(patch);
    }
    return store.get();
  });
  handle('settings:replaceKey', (key, value) => {
    if (typeof key !== 'string' || key.startsWith('spotify')) return store.get();
    store.set(key, value);
    return store.get();
  });

  handle('shell:open', (url) => {
    if (typeof url === 'string' && EXTERNAL_OK.test(url)) return shell.openExternal(url);
    return false;
  });
  handle('shell:settings', async (which) => {
    const winMap = {
      bluetooth: 'ms-settings:bluetooth',
      sound: 'ms-settings:sound',
      'apps-volume': 'ms-settings:apps-volume',
      mic: 'ms-settings:privacy-microphone',
    };
    const macMap = {
      bluetooth: 'x-apple.systempreferences:com.apple.BluetoothSettings',
      sound: 'x-apple.systempreferences:com.apple.Sound-Settings.extension',
      mic: 'x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone',
      automation: 'x-apple.systempreferences:com.apple.preference.security?Privacy_Automation',
    };
    if (IS_MAC && which === 'audio-midi') {
      return shell.openPath('/System/Applications/Utilities/Audio MIDI Setup.app');
    }
    const url = IS_WIN ? winMap[which] : IS_MAC ? macMap[which] : null;
    if (url) return shell.openExternal(url);
    return false;
  });

  handle('mic:ask', async () => {
    if (IS_MAC) return systemPreferences.askForMediaAccess('microphone');
    if (IS_WIN) {
      const s = systemPreferences.getMediaAccessStatus('microphone');
      return s !== 'denied';
    }
    return true;
  });

  handle('power:playing', (playing) => {
    if (playing && powerBlockId === null) powerBlockId = powerSaveBlocker.start('prevent-app-suspension');
    if (!playing && powerBlockId !== null) {
      powerSaveBlocker.stop(powerBlockId);
      powerBlockId = null;
    }
    return true;
  });

  // library
  handle('library:list', () => library.list());
  handle('library:pickFolder', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a music folder', properties: ['openDirectory', 'multiSelections'] });
    if (r.canceled || !r.filePaths.length) return null;
    let res = null;
    for (const f of r.filePaths) res = await library.addFolder(f);
    return res;
  });
  handle('library:pickFiles', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'Add songs',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Audio', extensions: ['mp3', 'm4a', 'aac', 'flac', 'ogg', 'opus', 'wav', 'webm', 'mp4'] }],
    });
    if (r.canceled || !r.filePaths.length) return null;
    return library.addPaths(r.filePaths);
  });
  handle('library:addPaths', (paths) => (Array.isArray(paths) ? library.addPaths(paths.filter((p) => typeof p === 'string')) : library.list()));
  handle('library:removeFolder', (folder) => library.removeFolder(String(folder)));
  handle('library:rescan', () => library.rescan());

  // spotify
  handle('spotify:status', () => spotify.status());
  handle('spotify:connect', (clientId) => spotify.connect(clientId));
  handle('spotify:cancel', () => spotify.cancel());
  handle('spotify:disconnect', () => spotify.disconnect());
  handle('spotify:api', (method, p, opts) => spotify.api(method, p, opts || {}));
  handle('art:fetch', (url) => spotify.art(url));

  // apple music (mac)
  handle('apple:call', async (cmd, arg) => {
    if (!IS_MAC) return { error: 'mac-only' };
    if (!apple) apple = new (require('./apple-mac').AppleMusicMac)();
    try {
      return { ok: true, data: await apple.call(cmd, arg) };
    } catch (e) {
      return { ok: false, error: e.message, code: e.code || null };
    }
  });

  // windows media controls (Apple Music for Windows, Spotify, browsers...)
  handle('winmedia:call', async (req) => {
    if (!IS_WIN) return { ok: false, error: 'windows-only' };
    if (!winMedia) winMedia = new (require('./media-win').WinMedia)();
    try {
      return await winMedia.call(req);
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // Apple Music catalogue search (free iTunes Search API, no account needed)
  handle('itunes:search', async (q, country) => {
    q = String(q || '').trim();
    if (!q) return [];
    const cc = /^[A-Z]{2}$/i.test(country || '') ? country : 'US';
    const url = `https://itunes.apple.com/search?${new URLSearchParams({ term: q, media: 'music', entity: 'song', limit: '30', country: cc })}`;
    try {
      const res = await net.fetch(url);
      const data = await res.json();
      return (data.results || []).map((r) => ({
        id: String(r.trackId),
        title: r.trackName,
        artist: r.artistName,
        album: r.collectionName,
        duration: (r.trackTimeMillis || 0) / 1000,
        art: (r.artworkUrl100 || '').replace('100x100bb', '600x600bb'),
        url: r.trackViewUrl,
      }));
    } catch (_) {
      return { error: 'offline' };
    }
  });

  handle('net:online', () => net.isOnline());
}

// ---- lifecycle ---------------------------------------------------------------------
app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

app.whenReady().then(() => {
  if (IS_WIN) app.setAppUserModelId('app.unison.multispeaker');
  const dataDir = app.getPath('userData');
  store = new Store(path.join(dataDir, 'settings.json'), DEFAULTS);
  library = new Library({ dataDir, resizeImage: resizeCover });
  library.onProgress((p) => send('library:progress', p));
  spotify = new SpotifyBridge({
    store,
    openExternal: (u) => shell.openExternal(u),
    fetchImpl: (...a) => net.fetch(...a),
    encrypt: encryptSecret,
    decrypt: decryptSecret,
  });

  protocol.handle('app', createAppProtocolHandler({ rendererDir: RENDERER, library }));
  setupPermissions();
  setupIpc();
  buildMenu();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('before-quit', () => {
  try {
    store && store.saveNow();
  } catch (_) {}
  try {
    winMedia && winMedia.stop();
  } catch (_) {}
});
