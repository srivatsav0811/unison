# Unison - Windows media bridge (Windows PowerShell 5.1)
# Talks to the Global System Media Transport Controls (the same thing the Windows
# volume flyout uses) so Unison can show and control Apple Music, Spotify, browsers...
# Protocol: one JSON request per line on stdin, one JSON response per line on stdout.

$ErrorActionPreference = 'Stop'
try { [Console]::InputEncoding = [System.Text.Encoding]::UTF8 } catch {}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Out-Json($obj) {
  [Console]::Out.WriteLine(($obj | ConvertTo-Json -Compress -Depth 5))
  [Console]::Out.Flush()
}

try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $null = [Windows.Media.MediaPlaybackAutoRepeatMode, Windows.Media, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $script:asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
      $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    })[0]

  function Await($op, [Type]$type) {
    $task = $script:asTask.MakeGenericMethod($type).Invoke($null, @($op))
    [void]$task.Wait(4000)
    if (-not $task.IsCompleted) { throw 'Windows media controls did not answer in time' }
    return $task.Result
  }

  $script:mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  Out-Json @{ ready = $true }
} catch {
  Out-Json @{ ready = $false; error = "$($_.Exception.Message)" }
  exit 1
}

function Pick-Session([string]$prefer, [string]$exclude) {
  $sessions = @($script:mgr.GetSessions())
  if ($prefer) {
    foreach ($s in $sessions) {
      if ($s.SourceAppUserModelId -like "*$prefer*") { return $s }
    }
    return $null
  }
  $cur = $script:mgr.GetCurrentSession()
  $isExcluded = { param($x) $exclude -and ($exclude.Split('|') | Where-Object { $_ -and $x.SourceAppUserModelId -like "*$_*" }) }
  if ($cur -and -not (& $isExcluded $cur)) { return $cur }
  foreach ($s in $sessions) {
    if (-not (& $isExcluded $s)) { return $s }
  }
  return $null
}

function Get-Art($props) {
  if (-not $props.Thumbnail) { return $null }
  $stream = Await ($props.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
  try {
    $size = [uint32]$stream.Size
    if ($size -eq 0 -or $size -gt 8000000) { return $null }
    $reader = [Windows.Storage.Streams.DataReader]::new($stream.GetInputStreamAt(0))
    $null = Await ($reader.LoadAsync($size)) ([uint32])
    $bytes = New-Object byte[] $size
    $reader.ReadBytes($bytes)
    return @{ data = [Convert]::ToBase64String($bytes); mime = "$($stream.ContentType)" }
  } finally {
    $stream.Dispose()
  }
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  if ($line.Trim().Length -eq 0) { continue }
  $id = $null
  try {
    $req = $line | ConvertFrom-Json
    $id = $req.id
    if ($req.cmd -eq 'sessions') {
      $list = @()
      foreach ($x in @($script:mgr.GetSessions())) { $list += "$($x.SourceAppUserModelId)" }
      $cur = $script:mgr.GetCurrentSession()
      Out-Json @{ id = $id; ok = $true; sessions = $list; current = $(if ($cur) { "$($cur.SourceAppUserModelId)" } else { $null }) }
      continue
    }
    $s = Pick-Session "$($req.prefer)" "$($req.exclude)"
    if (-not $s) { Out-Json @{ id = $id; ok = $true; active = $false }; continue }
    switch ("$($req.cmd)") {
      'state' {
        $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        $info = $s.GetPlaybackInfo()
        $tl = $s.GetTimelineProperties()
        $updated = 0
        try { $updated = $tl.LastUpdatedTime.ToUnixTimeMilliseconds() } catch {}
        Out-Json @{
          id = $id; ok = $true; active = $true
          app = "$($s.SourceAppUserModelId)"
          title = "$($p.Title)"; artist = "$($p.Artist)"; album = "$($p.AlbumTitle)"
          status = [int]$info.PlaybackStatus
          shuffle = [bool]$info.IsShuffleActive
          repeat = [int]$info.AutoRepeatMode
          position = [double]$tl.Position.TotalSeconds
          duration = [double]$tl.EndTime.TotalSeconds
          updated = $updated
          canSeek = [bool]$info.Controls.IsPlaybackPositionEnabled
          canNext = [bool]$info.Controls.IsNextEnabled
          canPrev = [bool]$info.Controls.IsPreviousEnabled
          canShuffle = [bool]$info.Controls.IsShuffleEnabled
          canRepeat = [bool]$info.Controls.IsRepeatEnabled
        }
      }
      'art' {
        $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        $a = Get-Art $p
        Out-Json @{ id = $id; ok = $true; art = $a }
      }
      'playpause' { Out-Json @{ id = $id; ok = (Await ($s.TryTogglePlayPauseAsync()) ([bool])) } }
      'play' { Out-Json @{ id = $id; ok = (Await ($s.TryPlayAsync()) ([bool])) } }
      'pause' { Out-Json @{ id = $id; ok = (Await ($s.TryPauseAsync()) ([bool])) } }
      'next' { Out-Json @{ id = $id; ok = (Await ($s.TrySkipNextAsync()) ([bool])) } }
      'prev' { Out-Json @{ id = $id; ok = (Await ($s.TrySkipPreviousAsync()) ([bool])) } }
      'seek' {
        $ticks = [long]([double]$req.value * 10000000)
        Out-Json @{ id = $id; ok = (Await ($s.TryChangePlaybackPositionAsync($ticks)) ([bool])) }
      }
      'shuffle' { Out-Json @{ id = $id; ok = (Await ($s.TryChangeShuffleActiveAsync([bool]$req.value)) ([bool])) } }
      'repeat' {
        $mode = [Windows.Media.MediaPlaybackAutoRepeatMode]([int]$req.value)
        Out-Json @{ id = $id; ok = (Await ($s.TryChangeAutoRepeatModeAsync($mode)) ([bool])) }
      }
      default { Out-Json @{ id = $id; ok = $false; error = 'unknown command' } }
    }
  } catch {
    Out-Json @{ id = $id; ok = $false; error = "$($_.Exception.Message)" }
  }
}
