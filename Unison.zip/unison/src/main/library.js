'use strict';
// Local music library: folder scanning, metadata + cover cache, persisted index.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { readTags } = require('./tags');

const AUDIO_EXT = new Set(['.mp3', '.m4a', '.mp4', '.aac', '.flac', '.ogg', '.oga', '.opus', '.wav', '.webm']);
const SKIP_DIRS = new Set(['$recycle.bin', 'system volume information', 'node_modules', '.git', 'appdata', '.trash', '.trashes']);
const MAX_FILES = 60000;

const MIME = {
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.mp4': 'audio/mp4',
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
  '.ogg': 'audio/ogg',
  '.oga': 'audio/ogg',
  '.opus': 'audio/ogg',
  '.wav': 'audio/wav',
  '.webm': 'audio/webm',
};

const sha1 = (s) => crypto.createHash('sha1').update(s).digest('hex');

class Library {
  /**
   * @param {object} opts
   * @param {string} opts.dataDir  where library.json and covers/ live
   * @param {(buf:Buffer, mime:string)=>({data:Buffer, ext:string}|null)} [opts.resizeImage]
   */
  constructor({ dataDir, resizeImage } = {}) {
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'library.json');
    this.coverDir = path.join(dataDir, 'covers');
    this.resizeImage = resizeImage || null;
    this.tracks = new Map();
    this.folders = [];
    this.scanning = false;
    this._listeners = new Set();
    this._saveTimer = null;
    this.load();
  }

  onProgress(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  _emit(p) {
    for (const fn of this._listeners) {
      try {
        fn(p);
      } catch (_) {}
    }
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.folders = Array.isArray(raw.folders) ? raw.folders : [];
      for (const t of raw.tracks || []) if (t && t.id && t.path) this.tracks.set(t.id, t);
    } catch (_) {}
  }

  save() {
    clearTimeout(this._saveTimer);
    this._saveTimer = setTimeout(() => {
      try {
        fs.mkdirSync(this.dataDir, { recursive: true });
        const tmp = this.file + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify({ version: 1, folders: this.folders, tracks: [...this.tracks.values()] }));
        fs.renameSync(tmp, this.file);
      } catch (err) {
        console.error('[library] save failed', err);
      }
    }, 300);
  }

  list() {
    return { folders: this.folders, tracks: [...this.tracks.values()].map(publicTrack) };
  }

  pathFor(id) {
    const t = this.tracks.get(id);
    return t ? t.path : null;
  }

  mimeFor(id) {
    const p = this.pathFor(id);
    return p ? MIME[path.extname(p).toLowerCase()] || 'application/octet-stream' : null;
  }

  coverPath(name) {
    if (!/^[a-f0-9]{40}\.(jpg|png)$/.test(name)) return null;
    return path.join(this.coverDir, name);
  }

  async addFolder(folder) {
    folder = path.resolve(folder);
    if (!this.folders.includes(folder)) this.folders.push(folder);
    this.save();
    await this.scan([folder]);
    return this.list();
  }

  removeFolder(folder) {
    folder = path.resolve(folder);
    this.folders = this.folders.filter((f) => f !== folder);
    for (const [id, t] of this.tracks) if (t.folder === folder) this.tracks.delete(id);
    this.save();
    return this.list();
  }

  /** Add individual files or folders (drag & drop). */
  async addPaths(paths) {
    const folders = [];
    const files = [];
    for (const p of paths) {
      try {
        const st = await fs.promises.stat(p);
        if (st.isDirectory()) folders.push(path.resolve(p));
        else if (AUDIO_EXT.has(path.extname(p).toLowerCase())) files.push(path.resolve(p));
      } catch (_) {}
    }
    for (const f of folders) if (!this.folders.includes(f)) this.folders.push(f);
    const added = [];
    await this.scan(folders, files, added);
    return { ...this.list(), added };
  }

  async rescan() {
    // drop tracks whose files vanished, then rescan all folders
    for (const [id, t] of this.tracks) {
      if (!fs.existsSync(t.path)) this.tracks.delete(id);
    }
    await this.scan(this.folders);
    return this.list();
  }

  async scan(folders = [], extraFiles = [], addedOut = []) {
    if (this.scanning) {
      // queue behind the current scan
      await new Promise((r) => {
        const off = this.onProgress((p) => {
          if (p.done) {
            off();
            r();
          }
        });
      });
    }
    this.scanning = true;
    try {
      const jobs = [];
      for (const folder of folders) {
        const files = await walk(folder);
        for (const f of files) jobs.push({ file: f, folder });
      }
      for (const f of extraFiles) jobs.push({ file: f, folder: path.dirname(f) });
      let done = 0;
      const total = jobs.length;
      this._emit({ scanned: 0, total, done: false });
      let idx = 0;
      const worker = async () => {
        while (idx < jobs.length) {
          const job = jobs[idx++];
          try {
            const t = await this._indexFile(job.file, job.folder);
            if (t) addedOut.push(t.id);
          } catch (_) {}
          done++;
          if (done % 10 === 0 || done === total) this._emit({ scanned: done, total, current: path.basename(job.file), done: false });
        }
      };
      await Promise.all(Array.from({ length: 6 }, worker));
      this.save();
      this._emit({ scanned: total, total, done: true });
    } finally {
      this.scanning = false;
    }
  }

  async _indexFile(file, folder) {
    const st = await fs.promises.stat(file);
    const id = sha1(path.resolve(file).toLowerCase()).slice(0, 20);
    const prev = this.tracks.get(id);
    if (prev && prev.mtime === st.mtimeMs && prev.size === st.size) return prev;
    const tags = await readTags(file);
    let cover = null;
    if (tags.picture) cover = await this._storeCover(tags, file);
    else {
      // folder.jpg / cover.jpg next to the file
      cover = await this._folderCover(path.dirname(file));
    }
    const t = {
      id,
      path: file,
      folder,
      title: tags.title,
      artist: tags.artist,
      album: tags.album,
      albumArtist: tags.albumArtist,
      track: tags.track,
      year: tags.year,
      duration: tags.duration,
      cover,
      mtime: st.mtimeMs,
      size: st.size,
      addedAt: prev ? prev.addedAt : Date.now(),
    };
    this.tracks.set(id, t);
    return t;
  }

  async _storeCover(tags, file) {
    const key = sha1(`${(tags.albumArtist || tags.artist || '').toLowerCase()}|${(tags.album || path.dirname(file)).toLowerCase()}`);
    for (const ext of ['jpg', 'png']) {
      const p = path.join(this.coverDir, `${key}.${ext}`);
      if (fs.existsSync(p)) return `${key}.${ext}`;
    }
    let data = tags.picture.data;
    let ext = /png/i.test(tags.picture.mime) ? 'png' : 'jpg';
    if (this.resizeImage) {
      try {
        const r = this.resizeImage(data, tags.picture.mime);
        if (r && r.data && r.data.length) {
          data = r.data;
          ext = r.ext;
        }
      } catch (_) {}
    }
    await fs.promises.mkdir(this.coverDir, { recursive: true });
    await fs.promises.writeFile(path.join(this.coverDir, `${key}.${ext}`), data);
    return `${key}.${ext}`;
  }

  async _folderCover(dir) {
    const names = ['cover.jpg', 'folder.jpg', 'front.jpg', 'cover.png', 'folder.png', 'album.jpg', 'Cover.jpg', 'Folder.jpg'];
    for (const n of names) {
      const p = path.join(dir, n);
      try {
        const data = await fs.promises.readFile(p);
        return await this._storeCover({ picture: { data, mime: n.endsWith('png') ? 'image/png' : 'image/jpeg' }, album: dir, artist: '' }, p);
      } catch (_) {}
    }
    return null;
  }
}

function publicTrack(t) {
  return {
    id: t.id,
    title: t.title,
    artist: t.artist,
    album: t.album,
    albumArtist: t.albumArtist,
    track: t.track,
    year: t.year,
    duration: t.duration,
    cover: t.cover,
    folder: t.folder,
    file: path.basename(t.path),
    addedAt: t.addedAt,
  };
}

async function walk(root, depth = 0, out = []) {
  if (depth > 14 || out.length >= MAX_FILES) return out;
  let entries;
  try {
    entries = await fs.promises.readdir(root, { withFileTypes: true });
  } catch (_) {
    return out;
  }
  for (const e of entries) {
    if (out.length >= MAX_FILES) break;
    const name = e.name;
    if (name.startsWith('.')) continue;
    const full = path.join(root, name);
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(name.toLowerCase())) continue;
      await walk(full, depth + 1, out);
    } else if (e.isFile() && AUDIO_EXT.has(path.extname(name).toLowerCase())) {
      out.push(full);
    }
  }
  return out;
}

module.exports = { Library, AUDIO_EXT, MIME };
