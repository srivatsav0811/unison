'use strict';
// macOS: control the Music app (Apple Music) through JavaScript for Automation / AppleScript.
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const JXA = String.raw`
function run(argv) {
  var cmd = argv[0], arg = argv.length > 1 ? argv[1] : '';
  var M = Application('Music');
  if (cmd === 'state') {
    if (!M.running()) return JSON.stringify({ running: false });
    var st = 'stopped', t = null, pos = 0, vol = 0, sh = false, rep = 'off';
    try { st = String(M.playerState()); } catch (e) {}
    try { vol = M.soundVolume(); sh = M.shuffleEnabled(); rep = String(M.songRepeat()); } catch (e) {}
    if (st !== 'stopped') {
      try {
        var ct = M.currentTrack;
        t = { id: ct.persistentID(), title: ct.name(), artist: ct.artist(), album: ct.album(), duration: ct.duration() };
      } catch (e) { t = null; }
      try { pos = M.playerPosition(); } catch (e) {}
    }
    return JSON.stringify({ running: true, state: st, track: t, position: pos, volume: vol, shuffle: sh, repeat: rep });
  }
  if (cmd === 'playpause') { M.playpause(); return 'ok'; }
  if (cmd === 'play') { M.play(); return 'ok'; }
  if (cmd === 'pause') { M.pause(); return 'ok'; }
  if (cmd === 'next') { M.nextTrack(); return 'ok'; }
  if (cmd === 'prev') { M.previousTrack(); return 'ok'; }
  if (cmd === 'restart') { M.backTrack(); return 'ok'; }
  if (cmd === 'seek') { M.playerPosition = parseFloat(arg) || 0; return 'ok'; }
  if (cmd === 'volume') { M.soundVolume = Math.max(0, Math.min(100, parseInt(arg, 10) || 0)); return 'ok'; }
  if (cmd === 'shuffle') { M.shuffleEnabled = (arg === 'true'); return 'ok'; }
  if (cmd === 'repeat') { M.songRepeat = (arg === 'one' || arg === 'all') ? arg : 'off'; return 'ok'; }
  if (cmd === 'search') {
    var lib = M.libraryPlaylists[0];
    var q = arg;
    var s = lib.tracks.whose({ _or: [ { name: { _contains: q } }, { artist: { _contains: q } }, { album: { _contains: q } } ] });
    var ids = s.persistentID(), names = s.name(), artists = s.artist(), albums = s.album(), durs = s.duration();
    var out = [];
    for (var i = 0; i < ids.length && i < 150; i++) out.push({ id: ids[i], title: names[i], artist: artists[i], album: albums[i], duration: durs[i] });
    return JSON.stringify(out);
  }
  if (cmd === 'playlists') {
    var pls = M.userPlaylists;
    var pids = pls.persistentID(), pnames = pls.name(), kinds = [];
    try { kinds = pls.specialKind(); } catch (e) {}
    var res = [];
    for (var j = 0; j < pids.length; j++) {
      var k = kinds[j] ? String(kinds[j]) : 'none';
      if (k !== 'none' && k !== 'Music' && k !== 'Genius') continue;
      res.push({ id: pids[j], name: pnames[j], kind: k });
    }
    return JSON.stringify(res);
  }
  if (cmd === 'playTrack') {
    var tr = M.libraryPlaylists[0].tracks.whose({ persistentID: arg });
    if (tr.length) { M.play(tr[0]); return 'ok'; }
    return 'missing';
  }
  if (cmd === 'playPlaylist') {
    var pl = M.userPlaylists.whose({ persistentID: arg });
    if (pl.length) { M.play(pl[0]); return 'ok'; }
    return 'missing';
  }
  return 'unknown';
}`;

const ART_SCRIPT = String.raw`
on run argv
  set outPath to item 1 of argv
  tell application "Music"
    if not running then return "none"
    if player state is stopped then return "none"
    try
      set a to artwork 1 of current track
      set d to raw data of a
    on error
      return "none"
    end try
  end tell
  set fh to open for access (POSIX file outPath) with write permission
  try
    set eof fh to 0
    write d to fh
  end try
  close access fh
  return "ok"
end run`;

function osa(args, timeout = 8000) {
  return new Promise((resolve, reject) => {
    execFile('osascript', args, { timeout, maxBuffer: 16 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        const msg = String(stderr || err.message || '');
        if (/-1743|not authori[sz]ed/i.test(msg)) {
          reject(
            Object.assign(new Error('Unison is not allowed to control Music. Open System Settings → Privacy & Security → Automation and switch on "Music" under Unison.'), {
              code: 'automation_denied',
            })
          );
        } else reject(new Error(msg.trim() || 'Music did not respond.'));
        return;
      }
      resolve(String(stdout).trim());
    });
  });
}

class AppleMusicMac {
  constructor() {
    this.artCache = new Map();
  }

  async call(cmd, arg) {
    const allowed = ['state', 'playpause', 'play', 'pause', 'next', 'prev', 'restart', 'seek', 'volume', 'shuffle', 'repeat', 'search', 'playlists', 'playTrack', 'playPlaylist', 'art'];
    if (!allowed.includes(cmd)) throw new Error('Unknown Music command');
    if (cmd === 'art') return this.art(arg);
    const out = await osa(['-l', 'JavaScript', '-e', JXA, cmd, arg == null ? '' : String(arg)], cmd === 'search' ? 20000 : 8000);
    if (cmd === 'state' || cmd === 'search' || cmd === 'playlists') {
      try {
        return JSON.parse(out);
      } catch (_) {
        return cmd === 'state' ? { running: false } : [];
      }
    }
    return out;
  }

  async art(trackId) {
    if (trackId && this.artCache.has(trackId)) return this.artCache.get(trackId);
    const file = path.join(os.tmpdir(), `unison-art-${process.pid}.bin`);
    try {
      const r = await osa(['-e', ART_SCRIPT, file], 8000);
      if (r !== 'ok') return null;
      const buf = await fs.promises.readFile(file);
      if (buf.length < 64) return null;
      const mime = buf[0] === 0x89 && buf[1] === 0x50 ? 'image/png' : 'image/jpeg';
      const url = `data:${mime};base64,${buf.toString('base64')}`;
      if (trackId) {
        this.artCache.set(trackId, url);
        if (this.artCache.size > 60) this.artCache.delete(this.artCache.keys().next().value);
      }
      return url;
    } catch (_) {
      return null;
    } finally {
      fs.promises.unlink(file).catch(() => {});
    }
  }
}

module.exports = { AppleMusicMac };
