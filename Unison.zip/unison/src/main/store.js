'use strict';
// Tiny JSON settings store with atomic, debounced writes.
const fs = require('fs');
const path = require('path');

class Store {
  constructor(file, defaults = {}) {
    this.file = file;
    this.defaults = defaults;
    this.data = structuredClone(defaults);
    this._timer = null;
    try {
      const raw = fs.readFileSync(file, 'utf8');
      const parsed = JSON.parse(raw);
      this.data = deepMerge(structuredClone(defaults), parsed);
    } catch (_) {
      // first run or corrupt file: keep defaults
    }
  }

  get(key) {
    if (!key) return this.data;
    return key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), this.data);
  }

  set(key, value) {
    if (typeof key === 'object') {
      this.data = deepMerge(this.data, key);
    } else {
      const parts = key.split('.');
      let o = this.data;
      for (let i = 0; i < parts.length - 1; i++) {
        if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {};
        o = o[parts[i]];
      }
      o[parts[parts.length - 1]] = value;
    }
    this.scheduleSave();
    return this.data;
  }

  scheduleSave() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.saveNow(), 250);
  }

  saveNow() {
    clearTimeout(this._timer);
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      console.error('[store] save failed', err);
    }
  }
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(target, src) {
  if (!isPlainObject(src)) return target;
  for (const [k, v] of Object.entries(src)) {
    if (isPlainObject(v) && isPlainObject(target[k])) target[k] = deepMerge(target[k], v);
    else target[k] = v;
  }
  return target;
}

module.exports = { Store, deepMerge };
