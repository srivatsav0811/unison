#!/bin/bash
# Double-click to build Unison.dmg on a Mac (Apple Silicon + Intel).
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { open "https://nodejs.org/en/download"; echo "Install Node.js LTS first."; exit 1; }
npm install --no-fund --no-audit && npx electron-builder --mac --arm64 --x64 && open dist
