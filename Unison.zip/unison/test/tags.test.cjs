// Metadata reader tests (MP3/ID3v2.3+2.4, M4A, FLAC, OGG, WAV, filename fallback).
const assert = require('assert/strict');
const path = require('path');
const { readTags, parseFilename } = require('../src/main/tags');
const { makeFixtures } = require('./fixtures.cjs');

(async () => {
  assert.deepEqual(parseFilename('/x/05 - Some Band - Great Song.mp3'), { artist: 'Some Band', title: 'Great Song', track: 5 });
  assert.deepEqual(parseFilename('C:/m/Track.flac'), { artist: '', title: 'Track', track: null });
  const dir = makeFixtures();
  if (!dir) {
    console.log('ffmpeg not found — skipping file-based tag tests');
    return;
  }
  const t = async (f) => readTags(path.join(dir, f));
  let r = await t('a.mp3');
  assert.equal(r.title, 'Héllo Wörld');
  assert.equal(r.artist, 'Test Ärtist');
  assert.equal(r.track, 4);
  assert.ok(Math.abs(r.duration - 7) < 0.1, 'mp3 duration ' + r.duration);
  r = await t('b_v24_cover.mp3');
  assert.equal(r.picture.mime, 'image/jpeg');
  r = await t('c_cover.m4a');
  assert.equal(r.album, 'M4A Album');
  assert.equal(r.track, 7);
  assert.ok(r.picture && r.picture.data[0] === 0xff);
  assert.ok(Math.abs(r.duration - 5.5) < 0.1);
  r = await t('d_cover.flac');
  assert.equal(r.title, 'FLAC T');
  assert.equal(r.duration, 6.25);
  assert.ok(r.picture);
  r = await t('e.ogg');
  assert.equal(r.artist, 'OGG A');
  assert.ok(Math.abs(r.duration - 4) < 0.05);
  r = await t('g.wav');
  assert.equal(r.title, 'Wav T');
  assert.ok(Math.abs(r.duration - 2) < 0.01);
  r = await t('05 - Some Band - Great Song.mp3');
  assert.equal(r.artist, 'Some Band');
  assert.equal(r.title, 'Great Song');
  console.log('tag reader tests passed');
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
