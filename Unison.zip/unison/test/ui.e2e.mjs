// Drives the UI in headless Chromium (browser demo mode) and saves screenshots.
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import fs from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('/opt/node-tools/node_modules/playwright');

const OUT = process.env.SHOTS || '/tmp/claude-0/shots';
fs.mkdirSync(OUT, { recursive: true });
const server = spawn(process.execPath, ['tools/serve-demo.js', '5192'], { stdio: 'pipe' });
await new Promise((r) => server.stdout.once('data', r));
const browser = await chromium.launch({
  args: ['--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}\n${e.stack}`));
await page.goto('http://127.0.0.1:5192/?demo#now');
await page.waitForFunction(() => document.documentElement.classList.contains('ready'), null, { timeout: 20000 });
await page.waitForTimeout(1500);
const shot = async (name) => { await page.screenshot({ path: `${OUT}/${name}.png` }); console.log('shot', name); };
await shot('01-now-idle');
await page.click('[data-e=tune]');
await page.waitForFunction(() => window.__unison.nowState().playing, null, { timeout: 30000 });
await page.waitForTimeout(6000);
console.log('features', await page.evaluate(() => { const f = window.__unison.frameFeatures; return JSON.stringify({ bass: f.bass, mid: f.mid, high: f.high, energy: f.energy, maxBin: Math.max(...f.bins) }); }));
await shot('02-now-playing');
for (const v of ['speakers', 'library', 'spotify', 'apple', 'settings']) {
  await page.click(`.nav-item[data-view=${v}]`);
  await page.waitForTimeout(1200);
  await shot(`03-${v}`);
}
await page.click('.nav-item[data-view=speakers]');
await page.waitForTimeout(600);
await page.click('[data-a=calibrate]');
await page.waitForTimeout(1200);
await shot('04-calibrate-modal');
await page.keyboard.press('Escape');
await page.waitForTimeout(500);
await page.evaluate(() => import('/js/views/settings.js').then((m) => m.openGuide(window.__unison)));
await page.waitForTimeout(900);
await shot('05-guide');
const info = await page.evaluate(() => ({ engine: window.__unison.engine.report(), speakers: window.__unison.engine.speakers.size, playing: window.__unison.nowState() }));
console.log(JSON.stringify(info, null, 1).slice(0, 1500));
console.log('ERRORS:', errors.length ? '\n' + errors.join('\n') : 'none');
await browser.close(); server.kill();
