import { makeChirp, matchedEnvelope, findArrival, ClockFit, fft } from '../src/renderer/js/audio/dsp.js';
import assert from 'node:assert/strict';

// FFT round trip
{
  const n = 1024, re = new Float64Array(n), im = new Float64Array(n);
  for (let i = 0; i < n; i++) re[i] = Math.sin(i * 0.1) + (i % 7) * 0.01;
  const orig = Float64Array.from(re);
  fft(re, im); fft(re, im, true);
  for (let i = 0; i < n; i++) assert.ok(Math.abs(re[i] - orig[i]) < 1e-9);
}

// arrival detection with noise, band-limiting and a louder late reflection
const sr = 48000;
const chirp = makeChirp(sr);
let worst = 0;
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff) * 2 - 1;
for (let trial = 0; trial < 40; trial++) {
  const len = sr * 1.2;
  const rec = new Float32Array(len);
  for (let i = 0; i < len; i++) rec[i] = 0.05 * rnd();
  const trueIdx = 2000 + trial * 911.37;             // fractional true arrival
  const gain = 0.08 + 0.02 * (trial % 5);            // weak direct sound (SNR ~ low)
  const refl = trueIdx + 300 + (trial % 7) * 40;     // reflection 6-12 ms later
  for (let i = 0; i < chirp.length; i++) {
    // fractional delay by linear interpolation
    const p = trueIdx + i; const k = Math.floor(p), f = p - k;
    rec[k] += gain * chirp[i] * (1 - f); rec[k + 1] += gain * chirp[i] * f;
    const q = Math.floor(refl + i); rec[q] += gain * 1.3 * chirp[i];
  }
  // crude low-pass (speaker/mic band-limit) + DC
  for (let i = 1; i < len; i++) rec[i] = 0.6 * rec[i] + 0.4 * rec[i - 1] + 0.001;
  const env = matchedEnvelope(rec, chirp);
  const a = findArrival(env, 0, len - chirp.length);
  const err = Math.abs(a.index - trueIdx) / sr * 1000;
  worst = Math.max(worst, err);
  assert.ok(err < 0.5, `trial ${trial}: err ${err.toFixed(3)} ms snr ${a.snr.toFixed(1)}`);
}
console.log(`arrival detection: worst error ${worst.toFixed(3)} ms over 40 noisy trials with louder reflections`);

// clock fit: 48 kHz clock running +60 ppm with 1 ms timestamp jitter
{
  const f = new ClockFit(48000);
  let t = 1000; let maxErr = 0;
  for (let i = 0; i < 200; i++) {
    t += 0.25;
    const jitter = rnd() * 0.001;
    const y = 48000 * (1 + 60e-6) * (t + jitter) + 12345;
    f.add(t, y);
    if (i > 60) maxErr = Math.max(maxErr, Math.abs(f.frameAt(t) - (48000 * (1 + 60e-6) * t + 12345)) / 48);
  }
  console.log(`clock fit: ${f.ppm().toFixed(1)} ppm (true 60), max position error ${maxErr.toFixed(3)} ms`);
  assert.ok(Math.abs(f.ppm() - 60) < 25);
  assert.ok(maxErr < 0.6);
}
console.log('dsp tests passed');
