// End-to-end test of the audio engine + calibration in headless Chromium with a simulated room.
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('/opt/node-tools/node_modules/playwright');

const server = spawn(process.execPath, ['tools/serve-demo.js', '5191'], { stdio: 'pipe' });
await new Promise((r) => server.stdout.once('data', r));
const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream'] });
const page = await browser.newPage();
page.on('console', (m) => { if (m.type() === 'error') console.log('[console]', m.text()); });
page.on('pageerror', (e) => console.log('[pageerror]', e.message));
await page.goto('http://127.0.0.1:5191/test/engine.html');
await page.waitForFunction(() => window.ready);
let failed = false;
for (const mode of (process.argv[2] ? [process.argv[2]] : ['precision', 'compat'])) {
  const sim = [0.150, 0.228, 0.311];
  const res = await page.evaluate((a) => window.runTest(a.mode, a.sim), { mode, sim });
  console.log(`\n=== ${mode} ===`); res.log.forEach((l) => console.log('  ' + l));
  const exp = { s0: sim[2] - sim[0], s1: sim[2] - sim[1], s2: 0 };
  const errs = Object.keys(exp).map((k) => Math.abs((res.delays[k] ?? 99) - exp[k]) * 1000);
  console.log(`  applied delay minus simulated latency gap (ms, includes the test harness' own stream hops): ${errs.map((e) => e.toFixed(2)).join(', ')}`);
  // Real criterion: after calibration one chirp through all speakers must arrive as ONE peak.
  // Mis-aligned speakers show up as secondary peaks at 35-100% of the main one.
  // (the compatibility engine relies on Chromium's MediaStream FIFOs, which may click; it's only a fallback)
  const ok = errs.every((e) => e < 40) && res.ver && res.ver.secondaryRatio < 0.2 && res.under === 0 && (res.glitchFree || mode === 'compat');
  console.log(`  ${ok ? 'PASS' : 'FAIL'}`);
  if (!ok) failed = true;
}
await browser.close(); server.kill();
process.exit(failed ? 1 : 0);
