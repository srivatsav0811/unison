// Simulates the Windows desktop bridge (Electron preload) to exercise desktop-only UI paths.
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import fs from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const OUT = process.env.SHOTS || '/tmp/claude-0/shots';
fs.mkdirSync(OUT, { recursive: true });
const server = spawn(process.execPath, ['tools/serve-demo.js', '5196'], { stdio: 'pipe' });
await new Promise((r) => server.stdout.once('data', r));
const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}\n${e.stack}`));
await page.addInitScript(() => {
  const calls = (window.__calls = []);
  let settings = { firstRun: false, captureMode: 'loopbackWithMute', latencyMode: 'auto', engine: 'precision', sampleRate: 48000, masterVolume: 0.75, visuals: 'low', glass: true, source: 'local', speakers: {}, spotify: { clientId: '' }, local: {} };
  const tracks = Array.from({ length: 60 }, (_, i) => ({ id: 't' + i, title: ['Midnight Drive', 'Neon Rain', 'Golden Hour', 'Echoes', 'Paper Planes', 'Monsoon'][i % 6] + (i > 5 ? ' ' + i : ''), artist: ['Aurora Lane', 'The Sonic Sea', 'Kavya', 'Low Tide'][i % 4], album: ['Night Sessions', 'Blue Hours', 'City Lights'][i % 3], albumArtist: ['Aurora Lane', 'The Sonic Sea', 'Kavya'][i % 3], duration: 180 + i * 3, cover: null, folder: 'C:\\Users\\vatsav\\Music', addedAt: i }));
  let pos = 42, t0 = Date.now();
  window.unison = {
    isDesktop: true, platform: 'win32',
    info: async () => ({ platform: 'win32', version: '1.0.0', hostname: 'VATSAV', country: 'IN', electron: '44.0.0' }),
    settings: { get: async () => structuredClone(settings), set: async (p) => { settings = { ...settings, ...p }; return structuredClone(settings); }, replace: async (k, v) => { settings[k] = v; return structuredClone(settings); } },
    shell: { open: async (u) => calls.push(['open', u]), settings: async (w) => calls.push(['settings', w]) },
    mic: { ask: async () => true }, power: { playing: async () => true }, win: { onState: () => () => {} },
    library: { list: async () => ({ folders: ['C:\\Users\\vatsav\\Music'], tracks }), pickFolder: async () => null, pickFiles: async () => null, addPaths: async () => ({ folders: [], tracks }), removeFolder: async () => ({}), rescan: async () => ({}), onProgress: () => () => {}, pathForFile: () => null },
    spotify: { status: async () => ({ configured: false, connected: false, redirectUri: 'http://127.0.0.1:43821/callback' }), connect: async () => { throw new Error('INVALID_CLIENT: Invalid client'); }, cancel: async () => {}, disconnect: async () => ({}), api: async () => ({ ok: false, status: 401, code: 'not_connected' }) },
    art: { fetch: async () => null },
    apple: { call: async () => ({ ok: false, error: 'mac-only' }) },
    winmedia: { call: async (req) => {
      calls.push(['winmedia', req.cmd, req.prefer]);
      if (req.cmd === 'state') return req.prefer === 'Spotify' ? { ok: true, active: false } : { ok: true, active: true, app: 'AppleInc.AppleMusicWin_nzyj5cx40ttqa!App', title: 'Blinding Lights', artist: 'The Weeknd', album: 'After Hours', status: 4, shuffle: false, repeat: 0, position: pos, duration: 200, updated: t0, canSeek: true, canNext: true, canPrev: true, canShuffle: true, canRepeat: true };
      if (req.cmd === 'art') return { ok: true, art: null };
      return { ok: true };
    } },
    itunes: { search: async (q) => [{ id: '1', title: q + ' (Live)', artist: 'Someone', album: 'Live at Home', duration: 201, art: 'https://is1-ssl.mzstatic.com/x/600x600bb.jpg', url: 'https://music.apple.com/in/album/x?i=1' }] },
    net: { online: async () => true },
  };
});
await page.goto('http://127.0.0.1:5196/?demo#now');
await page.waitForFunction(() => document.documentElement.classList.contains('ready'), null, { timeout: 20000 });
await page.waitForTimeout(1500);
const shot = async (n) => { await page.screenshot({ path: `${OUT}/${n}.png` }); console.log('shot', n); };
// Library with tracks
await page.click('.nav-item[data-view=library]'); await page.waitForTimeout(2500); await shot('w1-library');
await page.click('#lib-tabs [data-tab=albums]'); await page.waitForTimeout(2500); await shot('w2-albums');
await page.click('.nav-item[data-view=spotify]'); await page.waitForTimeout(2500); await shot('w3-spotify-setup');
await page.fill('#sp-client', '0123456789abcdef0123456789abcdef');
await page.click('[data-a=connect]'); await page.waitForTimeout(1500);
// switch to Apple Music source (Windows media controls)
await page.click('.source-switch [data-source=apple]'); await page.waitForTimeout(3000);
await page.click('.nav-item[data-view=now]'); await page.waitForTimeout(3000); await shot('w4-now-apple');
await page.click('.nav-item[data-view=apple]'); await page.waitForTimeout(2500); await shot('w5-apple-win');
await page.click('.nav-item[data-view=settings]'); await page.waitForTimeout(2500); await shot('w6-settings-win');
await page.click('.play-btn'); await page.waitForTimeout(800);
const calls = await page.evaluate(() => window.__calls.filter((c) => c[1] !== 'state').slice(-8));
console.log('bridge calls:', JSON.stringify(calls));
console.log('capture:', await page.evaluate(() => JSON.stringify({ err: window.__unison.capture.error, on: !!window.__unison.capture.stream })));
console.log('ERRORS:', errors.length ? '\n' + errors.join('\n') : 'none');
await browser.close(); server.kill();
