// Runs the test suites. `--unit` = fast Node-only tests (used in CI builds).
// Without flags it also runs the browser end-to-end tests when Playwright/Chromium are available.
const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const root = path.join(__dirname, '..');
const unit = ['test/dsp.test.mjs', 'test/tags.test.cjs', 'test/main.test.cjs'];
const e2e = ['test/engine.e2e.mjs', 'test/ui.e2e.mjs', 'test/ui-win.e2e.mjs'];
const onlyUnit = process.argv.includes('--unit');
let failed = 0;
const run = (f) => {
  console.log(`\n▶ ${f}`);
  const r = spawnSync(process.execPath, [f], { cwd: root, stdio: 'inherit' });
  if (r.status !== 0) {
    failed++;
    console.log(`✖ ${f} failed`);
  }
};
unit.forEach(run);
if (!onlyUnit) {
  const pw = '/opt/node-tools/node_modules/playwright';
  if (fs.existsSync(pw)) e2e.forEach(run);
  else console.log('\n(skipping browser end-to-end tests: Playwright not found)');
}
console.log(failed ? `\n${failed} suite(s) failed` : '\nall suites passed');
process.exit(failed ? 1 : 0);
