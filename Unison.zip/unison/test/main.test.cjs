// Main-process test with a fake `electron` module: protocol, IPC, library, Spotify PKCE flow.
const Module = require('module');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const assert = require('assert/strict');
const { makeFixtures } = require('./fixtures.cjs');
const FIX = makeFixtures();

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'unison-main-'));
const handlers = {};
let proto = null;
let display = null;
const opened = [];
let fetchImpl = async () => new Response('{}', { status: 200 });

class FakeWin {
  constructor() {
    this.webContents = { send() {}, setWindowOpenHandler() {}, on() {} };
  }
  loadURL(u) { this.url = u; }
  once() {}
  on() {}
  isDestroyed() { return false; }
  isMaximized() { return false; }
  getBounds() { return { x: 0, y: 0, width: 100, height: 100 }; }
  maximize() {}
  static getAllWindows() { return []; }
}
const electron = {
  app: {
    commandLine: { appendSwitch() {} },
    requestSingleInstanceLock: () => true,
    getPath: () => tmp,
    whenReady: () => Promise.resolve(),
    on() {},
    quit() {},
    getVersion: () => '1.0.0',
    getLocale: () => 'en-IN',
    getLocaleCountryCode: () => 'IN',
  },
  BrowserWindow: FakeWin,
  ipcMain: { handle: (ch, fn) => (handlers[ch] = fn) },
  protocol: { registerSchemesAsPrivileged() {}, handle: (s, fn) => (proto = fn) },
  session: { defaultSession: { setPermissionRequestHandler() {}, setPermissionCheckHandler() {}, setDisplayMediaRequestHandler: (fn) => (display = fn) } },
  shell: { openExternal: async (u) => opened.push(u), openPath: async () => '' },
  dialog: { showOpenDialog: async () => ({ canceled: true, filePaths: [] }) },
  desktopCapturer: { getSources: async () => [{ id: 'screen:0:0', name: 'Entire screen' }] },
  systemPreferences: { askForMediaAccess: async () => true, getMediaAccessStatus: () => 'granted' },
  safeStorage: { isEncryptionAvailable: () => true, encryptString: (s) => Buffer.from('ENC:' + s), decryptString: (b) => b.toString().slice(4) },
  nativeImage: { createFromBuffer: () => ({ isEmpty: () => true }) },
  powerSaveBlocker: { start: () => 1, stop() {} },
  Menu: { setApplicationMenu() {}, buildFromTemplate: () => ({}) },
  net: { fetch: (...a) => fetchImpl(...a), isOnline: () => true },
};
const origResolve = Module._resolveFilename;
Module._resolveFilename = function (req, ...rest) {
  if (req === 'electron') return 'electron';
  return origResolve.call(this, req, ...rest);
};
require.cache.electron = { id: 'electron', filename: 'electron', loaded: true, exports: electron };

const E = { senderFrame: { url: 'app://unison/index.html' } };
const call = (ch, ...a) => handlers[ch](E, ...a);

(async () => {
  require('../src/main/main.js');
  await new Promise((r) => setTimeout(r, 50));
  assert.ok(proto, 'protocol registered');

  // --- protocol: static files + security
  let r = await proto(new Request('app://unison/index.html'));
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('cross-origin-embedder-policy'), 'require-corp');
  assert.match(await r.text(), /<title>Unison<\/title>/);
  r = await proto(new Request('app://unison/js/audio/worklets.js'));
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type'), /javascript/);
  r = await proto(new Request('app://unison/%2e%2e/main/main.js'));
  assert.ok(r.status === 403 || r.status === 404, 'no path traversal: ' + r.status);
  console.log('protocol: static + traversal ok');

  // --- IPC guard
  await assert.rejects(() => handlers['settings:get']({ senderFrame: { url: 'https://evil.example/' } }));
  const s = await call('settings:get');
  assert.equal(s.engine, 'precision');
  await call('settings:set', { masterVolume: 0.5, spotify: { refresh: { plain: 'hack' } } });
  assert.equal((await call('settings:get')).masterVolume, 0.5);
  assert.equal((await call('settings:get')).spotify.refresh, null, 'renderer cannot write secrets');
  console.log('ipc: sender guard + settings ok');

  // --- library + ranged media
  if (!FIX) console.log('ffmpeg not found — skipping library tests');
  else {
  const lib = await call('library:addPaths', [FIX]);
  assert.ok(lib.tracks.length >= 9, 'scanned tracks: ' + lib.tracks.length);
  const flac = lib.tracks.find((t) => t.title === 'FLAC T' && t.file === 'd_cover.flac');
  assert.ok(flac && flac.cover, 'flac with cover');
  r = await proto(new Request(`app://unison/media/${flac.id}`, { headers: { Range: 'bytes=0-99' } }));
  assert.equal(r.status, 206);
  assert.equal(r.headers.get('content-range'), `bytes 0-99/${fs.statSync(path.join(FIX, 'd_cover.flac')).size}`);
  const body = Buffer.from(await r.arrayBuffer());
  assert.equal(body.length, 100);
  r = await proto(new Request(`app://unison/media/${flac.id}`, { headers: { Range: 'bytes=-10' } }));
  assert.equal(r.status, 206);
  assert.equal(Buffer.from(await r.arrayBuffer()).length, 10);
  r = await proto(new Request(`app://unison/media/${flac.id}`, { headers: { Range: 'bytes=999999999-' } }));
  assert.equal(r.status, 416);
  r = await proto(new Request('app://unison/media/nope'));
  assert.equal(r.status, 404);
  const withCover = lib.tracks.find((t) => t.cover);
  r = await proto(new Request(`app://unison/cover/${withCover.cover}`));
  assert.equal(r.status, 200);
  r = await proto(new Request('app://unison/cover/../../settings.json'));
  assert.equal(r.status, 404);
  console.log(`library: ${lib.tracks.length} tracks, range requests + covers ok`);
  }

  // --- display media handler (system audio)
  const got = await new Promise((res) => display({ audioRequested: true, videoRequested: true }, res));
  assert.equal(got.video.id, 'screen:0:0');
  console.log('display-media handler ok (audio loopback is added on Windows)');

  // --- Spotify PKCE flow against a fake Spotify
  let tokenCalls = 0;
  let playerCalls = 0;
  fetchImpl = async (url, init = {}) => {
    const u = String(url);
    if (u === 'https://accounts.spotify.com/api/token') {
      tokenCalls++;
      const p = new URLSearchParams(init.body);
      if (p.get('grant_type') === 'authorization_code') {
        assert.equal(p.get('code'), 'the-code');
        assert.ok(p.get('code_verifier').length >= 43);
        assert.equal(p.get('redirect_uri'), 'http://127.0.0.1:43821/callback');
        return Response.json({ access_token: 'A1', refresh_token: 'R1', expires_in: 3600 });
      }
      assert.equal(p.get('refresh_token'), 'R1');
      return Response.json({ access_token: 'A2', expires_in: 3600 });
    }
    if (u === 'https://api.spotify.com/v1/me') return Response.json({ id: 'u1', display_name: 'Vatsav', images: [] });
    if (u.startsWith('https://api.spotify.com/v1/me/player')) {
      playerCalls++;
      if (init.headers.Authorization === 'Bearer A1') return new Response(JSON.stringify({ error: { status: 401, message: 'expired' } }), { status: 401 });
      return Response.json({ is_playing: true, item: { name: 'Song' } });
    }
    return new Response('nope', { status: 404 });
  };
  const connectP = call('spotify:connect', 'abcdef0123456789abcdef0123456789');
  await new Promise((r) => setTimeout(r, 200));
  const authUrl = new URL(opened.find((u) => u.startsWith('https://accounts.spotify.com/authorize')));
  assert.equal(authUrl.searchParams.get('code_challenge_method'), 'S256');
  assert.equal(authUrl.searchParams.get('client_id'), 'abcdef0123456789abcdef0123456789');
  const state = authUrl.searchParams.get('state');
  const html = await new Promise((res, rej) =>
    http.get(`http://127.0.0.1:43821/callback?code=the-code&state=${state}`, (resp) => {
      let d = '';
      resp.on('data', (c) => (d += c));
      resp.on('end', () => res(d));
    }).on('error', rej)
  );
  assert.match(html, /connected to Spotify/);
  const st = await connectP;
  assert.equal(st.connected, true);
  assert.equal(st.profile.name, 'Vatsav');
  // first call uses A1 -> 401 -> refresh -> A2 -> 200
  const res = await call('spotify:api', 'GET', '/me/player', {});
  assert.equal(res.ok, true);
  assert.equal(res.data.item.name, 'Song');
  assert.equal(tokenCalls, 2);
  assert.equal(playerCalls, 2);
  await assert.rejects(() => call('spotify:api', 'GET', 'https://evil.example/x', {}));
  assert.equal(await call('art:fetch', 'https://evil.example/a.jpg'), null);
  console.log('spotify: PKCE sign-in, token refresh on 401 and URL allow-list ok');

  // --- iTunes search mapping
  fetchImpl = async () => Response.json({ results: [{ trackId: 7, trackName: 'T', artistName: 'A', collectionName: 'C', trackTimeMillis: 1000, artworkUrl100: 'https://x.mzstatic.com/a/100x100bb.jpg', trackViewUrl: 'https://music.apple.com/x' }] });
  const it = await call('itunes:search', 'hello', 'IN');
  assert.equal(it[0].art, 'https://x.mzstatic.com/a/600x600bb.jpg');
  console.log('itunes search ok');

  // store flush + encrypted secret on disk
  await new Promise((r) => setTimeout(r, 400));
  const onDisk = fs.readFileSync(path.join(tmp, 'settings.json'), 'utf8');
  assert.ok(!onDisk.includes('"R1"'), 'refresh token must not be stored in plain text');
  assert.ok(onDisk.includes('"enc"'));
  console.log('settings persisted, refresh token encrypted');
  console.log('main-process tests passed');
  process.exit(0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
