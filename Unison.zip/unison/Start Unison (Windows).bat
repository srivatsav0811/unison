@echo off
title Unison
cd /d "%~dp0"
if exist node_modules\electron\dist\electron.exe goto :run
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Unison needs Node.js to run from source ^(one-time, free^).
  echo  Opening the download page - install the "LTS" version, then double-click this file again.
  echo.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
echo  First start: downloading Electron ^(about 120 MB, needs internet once^)...
call npm install --no-fund --no-audit
if errorlevel 1 (
  echo  Install failed. Check your internet connection and try again.
  pause
  exit /b 1
)
:run
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0."
exit /b 0
