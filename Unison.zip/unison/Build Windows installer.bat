@echo off
title Build Unison installer
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo  Install Node.js LTS first: https://nodejs.org/en/download
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
echo  Installing build tools ^(needs internet^)...
call npm install --no-fund --no-audit
if errorlevel 1 goto :fail
echo  Building the Windows installer and portable app...
call npx electron-builder --win --x64
if errorlevel 1 goto :fail
echo.
echo  Done! Your installer is in the "dist" folder:
echo    - Unison-Setup-1.0.0.exe     ^(installs Unison with a desktop shortcut^)
echo    - Unison-Portable-1.0.0.exe  ^(runs without installing^)
start "" "%~dp0dist"
pause
exit /b 0
:fail
echo  Build failed - see the messages above.
pause
exit /b 1
