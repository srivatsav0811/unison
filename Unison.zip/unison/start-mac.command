#!/bin/bash
# Double-click to run Unison from source on macOS.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Unison needs Node.js (free). Opening the download page — install the LTS version, then run this again."
  open "https://nodejs.org/en/download"
  exit 1
fi
[ -d node_modules/electron ] || npm install --no-fund --no-audit || exit 1
npx electron .
