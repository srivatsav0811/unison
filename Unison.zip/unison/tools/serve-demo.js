// Serves the Unison UI in a normal browser (demo / development mode) with the
// cross-origin-isolation headers the precision audio engine needs.
//   node tools/serve-demo.js [port]
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', 'src', 'renderer');
const TEST = path.join(__dirname, '..', 'test', 'pages');
const port = parseInt(process.argv[2] || process.env.PORT || '5178', 10);
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
};

http
  .createServer((req, res) => {
    const u = new URL(req.url, 'http://localhost');
    let p = decodeURIComponent(u.pathname);
    let base = ROOT;
    if (p.startsWith('/test/')) {
      base = TEST;
      p = p.slice(5);
    }
    if (p === '/') p = '/index.html';
    const file = path.normalize(path.join(base, p));
    if (!file.startsWith(base)) {
      res.writeHead(403).end();
      return;
    }
    fs.readFile(file, (err, data) => {
      if (err) {
        res.writeHead(404).end('not found');
        return;
      }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
        'Cross-Origin-Opener-Policy': 'same-origin',
        'Cross-Origin-Embedder-Policy': 'require-corp',
        'Cross-Origin-Resource-Policy': 'same-origin',
        'Cache-Control': 'no-store',
      });
      res.end(data);
    });
  })
  .listen(port, '127.0.0.1', () => console.log(`Unison demo: http://127.0.0.1:${port}/`));
