# Unison

**One song, every speaker, in sync.** Unison is a desktop app for Windows and macOS. It plays your music on several Bluetooth speakers, soundboxes and soundbars at the same time, and it lines them up to the millisecond so they sound like one system instead of an echo. You can control Spotify and Apple Music from inside Unison, play your own music files fully offline, and set the volume and play/pause for everything from one glass-and-3D interface.

---

## What makes it different

Most free "multi-speaker" tools send the same audio to every output at once. Every Bluetooth speaker adds its own delay, often 100–300 ms, and the delays differ between speakers. You end up hearing an echo, and the echo gets worse as each speaker's clock slowly drifts.

Unison fixes this in three ways:

| | Typical free tools | Unison |
|---|---|---|
| Speaker delays | Ignored, so you hear an echo | **Measured acoustically** with your computer's mic, then compensated with sub-millisecond precision |
| Clock drift between speakers | Builds up over a song | **Tracked continuously and corrected** (sub-millisecond, inaudible) |
| Added buffering | Fixed and generous | **Auto-tuned** to the smallest buffer that stays glitch-free, measured live |

Bluetooth's own codec delay is built into each speaker and no software can remove it. What Unison can do is add no more delay than necessary and make every speaker play at the same moment.

---

## Install on Windows

You need **Node.js** only once, to build the app. After that, Unison runs fully offline.

1. Install **Node.js LTS** from <https://nodejs.org/en/download> (click Next through the installer).
2. Unzip the Unison folder anywhere, for example `Documents\Unison`.
3. Double-click **`Build Windows installer.bat`**. It downloads the build tools, which needs internet once and takes about 3–5 minutes, then opens the `dist` folder.
4. Run **`Unison-Setup-1.0.0.exe`**. This adds Unison to the Start menu and the desktop. `Unison-Portable-1.0.0.exe` runs without installing.

> **"Windows protected your PC"?** The app isn't code-signed (that costs money). Click **More info → Run anyway**.

**Just want to try it?** Double-click **`Start Unison (Windows).bat`**. The first start downloads Electron (~120 MB); after that it opens instantly.

## Install on macOS

On a Mac, double-click **`build-mac.command`** (after installing Node.js LTS). The finished `.dmg` files for Apple Silicon and Intel appear in `dist/`.

The first time you open Unison, **right-click the app → Open**. If macOS says the app is "damaged", run this in Terminal:
```
xattr -cr /Applications/Unison.app
```

## Build installers in the cloud (no Node.js on your computer)

1. Create a free GitHub account and a new **private** repository. Upload this folder to it.
2. Open the repository's **Actions** tab → **Build Unison** → **Run workflow**.
3. After about 10 minutes, download **Unison-Windows** and **Unison-macOS** from the run's *Artifacts* section.

---

## First-time setup (about 3 minutes)

Unison shows a short guide the first time you start it. You can reopen it anytime from Settings → Setup guide.

1. **Pair your speakers.** Put each speaker in pairing mode and pair it in Windows Settings → Bluetooth (on a Mac: System Settings → Bluetooth). Each paired speaker becomes its own audio output.
   - One Bluetooth adapter handles about **2–4 speakers**. A cheap USB Bluetooth 5.x dongle adds more.
   - Wired, USB and HDMI outputs work too, and you can mix them with Bluetooth speakers.
2. **Add them to the party.** Open **Speakers** and press **Add** on each one.
   - **Identify** plays a chime on that speaker only, so you can tell which is which.
   - **Channel** turns two speakers into a left/right stereo pair.
   - **Volume** is per speaker, and each speaker can go up to 150%.
3. **Calibrate once.** Put the laptop where people will listen, set the speakers to a normal volume and press **Calibrate sync**. Unison plays a short chirp on each speaker, measures when it arrives, and lines them up. It then checks the result, for example *"212 ms apart → ≤ 1 ms"*.
4. **Pick your music** with the switch at the top:
   - **My Music**: songs on this computer (MP3, M4A/AAC, FLAC, OGG, Opus, WAV). Fully offline. You can drop folders onto the window.
   - **Spotify**: search and play from Unison (see below).
   - **Apple Music**: control the Apple Music app (see below).
   - **Any app**: YouTube, games, anything your computer plays.

> **Windows tip:** keep your **laptop speakers as the Windows default output**, not a Bluetooth speaker. For Spotify, Apple Music and Any app, Unison captures what Windows plays. It then silences the default output so you don't hear an early, out-of-sync copy, and plays the sound in sync on your party speakers.

---

## Spotify

Spotify only lets apps control playback for **Premium** accounts. You have Premium, so you're set.

1. Open <https://developer.spotify.com/dashboard> and log in.
2. **Create app**. Use any name. As the *Redirect URI*, add exactly `http://127.0.0.1:43821/callback`. Tick *Web API*, then save.
3. Copy the **Client ID** from the app's settings page and paste it into Unison → **Spotify** → **Connect**. Approve in the browser tab that opens.

How it works: the Spotify desktop app on your computer does the streaming. Unison tells it what to play and captures its sound for your speakers. Keep the Spotify app installed and open.

In Unison you can search songs, albums, artists and playlists, play your playlists, liked songs and recently played, and use play/pause/skip/seek/shuffle/repeat. You can also move playback between Spotify devices.

*Spotify's rules for personal developer apps:* the app owner plus up to 5 people you add under *User Management* can use it. That's fine for personal use.

*On Windows,* choosing Spotify as the source gives you play/pause/skip even without connecting, through Windows media controls.

## Apple Music

- **Windows:** play music in the **Apple Music app** (from the Microsoft Store). Unison shows the song and artwork and controls play/pause/next/previous/seek through Windows media controls, and it plays the sound on all your speakers. Apple does not offer an API for picking songs, so you choose songs in the Apple Music app.
- **Mac:** Unison controls the Music app directly. You can search your library (including downloaded Apple Music songs, which play offline), start playlists, and use full transport controls. macOS asks once for permission to control Music.
- **Both:** *Discover* searches the whole Apple Music catalogue for free and opens songs in Apple Music.

## How audio from other apps gets into Unison

| | Windows | macOS |
|---|---|---|
| Default | **Built-in capture**, no install. Captures everything Windows plays and silences the default output while capturing. | Install the free **BlackHole 2ch** driver, set it as the Mac's sound output, and pick it in Unison → Settings → Audio capture. |
| Advanced | **Virtual cable** (free VB-CABLE). Route only chosen apps (e.g. Spotify) to *CABLE Input* in Windows' volume mixer. | Same as default. |

Your **My Music** library doesn't need any of this: Unison plays those files itself.

---

## Getting the tightest sync and the lowest latency

- **Calibrate at the listening spot.** Sound travels about 3 ms per metre, and Unison aligns the speakers for where the microphone is.
- **Latency mode** (Speakers page): *Auto* (recommended) keeps the smallest buffer that doesn't crackle. *Ultra* is the lowest, which is best for video. *Safe* is for weak Bluetooth links.
- Don't use a Bluetooth **headset** microphone for calibration. It switches speakers into low-quality call mode. Use the laptop's built-in mic.
- On Windows, each Bluetooth speaker can appear twice. Always add the **"Stereo"** entry, not "Hands-Free".
- Recalibrate if you move speakers, change their volume a lot, or add a new one.
- **Sync test** plays a series of ticks through every speaker. Each tick should sound like one crisp click. If you hear a "flam" (a doubled click), use **Fine-tune** on that speaker or recalibrate.

## Troubleshooting

| Problem | Fix |
|---|---|
| A speaker isn't listed | Make sure it's paired and connected in Bluetooth settings, then press ⟳ Refresh. |
| Audio crackles | Choose *Balanced* or *Safe* latency mode. Use fewer speakers per adapter, or move the laptop closer. |
| "Capture off" / no sound from Spotify | Settings → Audio capture → **Restart capture**. On Windows, check that the default output is your laptop speakers. |
| One speaker is silent while capturing | It's the Windows default output, which gets muted. Set the laptop speakers as default. |
| Calibration says "not heard" | Turn that speaker up, move the laptop closer, and make the room quieter. |
| Spotify says "no active player" | Open the Spotify app and press play once. Unison takes over from there. |
| Mac: "damaged app" | `xattr -cr /Applications/Unison.app` |

## Keyboard shortcuts

| Key | Action |
|---|---|
| `Space` | Play / pause |
| `←` / `→` | Seek 10 s |
| `Alt` + `←` / `→` | Previous / next |
| `↑` / `↓` | Volume |
| `M` | Mute |
| `Ctrl/⌘` + `K` | Search |
| `Ctrl/⌘` + `Shift` + `C` | Calibrate |

## Privacy

Everything runs on your computer. There are no accounts, no telemetry and no servers. Your Spotify login token is encrypted with Windows DPAPI or the macOS Keychain. The microphone is used only while the calibration window is open.

---

## How it works (for the curious)

```
 Spotify / Apple Music / any app ──► system capture ─┐
 Your music files (offline) ──────► <audio> ────────┤
                                                     ▼
                                  master AudioContext (no output of its own)
                                  │  mix · master volume · analyser (visuals)
                                  ▼
                        SharedArrayBuffer ring (5.4 s)   ◄── written by an AudioWorklet
               ┌──────────────────┼──────────────────┐
               ▼                  ▼                  ▼
        speaker ctx #1      speaker ctx #2      speaker ctx #3     (one AudioContext per
        reader worklet      reader worklet      reader worklet      output, bound with setSinkId)
        · clock mapping: getOutputTimestamp + regression, per device
        · per-speaker delay folded into the read position (sub-sample, cubic interpolation)
        · drift correction: ±0.15 % rate trim, crossfade for large jumps
        · gain, L/R/mono matrix, level meter
```

**Calibration.** Each speaker in turn plays three 50 ms chirps (1–7 kHz) through the real program path. The microphone is recorded in the master clock domain. A matched filter (FFT cross-correlation of the analytic signal) finds each chirp's arrival with sub-sample precision, taking the earliest strong peak so that room reflections are ignored. Every speaker is then delayed by *(slowest − its own)*. Finally, one chirp through all speakers at once checks that the arrivals merge into a single peak.

**Adaptive buffer.** Each reader reports its minimum headroom every 0.5 s. The shared base delay grows immediately on any underrun and shrinks slowly after 20 s of comfortable headroom.

## Development

```
npm install          # once
npm start            # run the app
npm test             # unit tests (+ browser end-to-end tests if Playwright is present)
npm run demo         # UI in a normal browser: http://127.0.0.1:5178/?demo
npm run dist:win     # build the Windows installer
npm run dist:mac     # build macOS .dmg (on a Mac)
```

Project layout:

```
src/main/        Electron main process: window, app:// protocol, IPC, library + tag reader,
                 Spotify (PKCE), Apple Music (AppleScript on Mac), Windows media controls (PowerShell)
src/renderer/    UI (no framework, no CDN — works offline)
  js/audio/      engine, AudioWorklets, calibration DSP, devices, system capture
  js/sources/    local player, Spotify, Apple Music / Windows media remote control, test tune
  js/ui/         WebGL scene, spectrum ring, palette extraction, glass/3D interactions
  js/views/      Now Playing, Speakers, Library, Spotify, Apple Music, Settings + guide
test/            DSP, tag reader, main process (fake Electron), engine + UI end-to-end tests
```

## Honest limits

- A **phone** can't be the hub. iOS and Android play Bluetooth audio on one speaker (sometimes two) at a time. Use a laptop or desktop.
- Unison can't make a Bluetooth speaker's own delay shorter. That's hardware. It makes every speaker play in sync with the slowest one, with as little extra delay as possible.
- Apple Music on Windows: you pick songs in the Apple Music app. Unison controls playback and shows what's playing.
- Spotify requires Premium and a free developer Client ID, and it needs internet. Your own music files and downloaded Apple Music songs on a Mac play offline.
